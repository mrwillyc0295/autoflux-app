import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  AlertCircle, 
  Zap, 
  DollarSign, 
  ArrowUpRight, 
  LineChart,
  ShieldCheck,
  BrainCircuit,
  Loader2,
  ChevronRight,
  Activity
} from 'lucide-react';
import { analyzePortfolio } from '../services/geminiService';
import { Car } from '../types';
import { cn } from '../lib/utils';
import { toast } from 'sonner';

interface BrokerAIModuleProps {
  cars: Car[];
}

interface AnalysisResult {
  portfolio_summary: {
    total_active_cars: number;
    portfolio_health_score: string;
    market_trend: string;
  };
  fastest_selling_assets: {
    make_model: string;
    liquidity_index: string;
    estimated_days_to_sell: number;
    why_is_hot: string;
  }[];
  trading_indicators: {
    make_model: string;
    current_status: string;
    suggested_strategy: string;
    profit_margin_potential: string;
  }[];
  actionable_alerts: string[];
}

export const BrokerAIModule: React.FC<BrokerAIModuleProps> = ({ cars }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const handleAnalyze = async () => {
    if (cars.length === 0) {
      toast.error("No hay vehículos en el inventario para analizar.");
      return;
    }
    
    setIsAnalyzing(true);
    try {
      const data = await analyzePortfolio(cars);
      setResult(data);
      toast.success("Análisis de Portafolio Completado");
    } catch (error) {
      console.error(error);
      toast.error("Error al conectar con el Broker de IA");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8">
      {/* Header / Intro */}
      {!result && !isAnalyzing && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-10 rounded-[2.5rem] border-blue-500/20 bg-blue-500/5 text-center relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl -mr-32 -mt-32 group-hover:bg-blue-600/20 transition-all duration-700" />
          
          <div className="flex flex-col items-center gap-6 relative z-10">
            <div className="w-20 h-20 bg-blue-600 rounded-[1.5rem] flex items-center justify-center shadow-2xl shadow-blue-600/20 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
              <BrainCircuit className="w-10 h-10 text-white" />
            </div>
            
            <div className="space-y-3">
              <h3 className="text-3xl font-black text-white italic tracking-tighter">
                AUTOFLUX <span className="text-blue-500">BROKER IA</span>
              </h3>
              <p className="text-slate-400 max-w-md mx-auto text-sm leading-relaxed font-medium">
                Analiza tu inventario como un portafolio de activos financieros. Detecta oportunidades de liquidez, tendencias de mercado y estrategias de optimización de margen.
              </p>
            </div>

            <button
              onClick={handleAnalyze}
              className="px-10 py-5 bg-blue-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.3em] flex items-center gap-4 hover:bg-blue-500 hover:scale-105 active:scale-95 transition-all shadow-xl shadow-blue-600/20"
            >
              <Activity className="w-5 h-5 animate-pulse" />
              <span>Activar Broker de Activos</span>
            </button>
          </div>
        </motion.div>
      )}

      {/* Loading State */}
      {isAnalyzing && (
        <div className="glass-card p-20 rounded-[2.5rem] border-blue-500/20 flex flex-col items-center justify-center gap-8 text-center bg-blue-600/5">
          <div className="relative">
             <Loader2 className="w-20 h-20 text-blue-500 animate-spin" />
             <BrainCircuit className="w-8 h-8 text-blue-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          </div>
          <div className="space-y-2">
            <p className="text-xl font-black text-white italic tracking-tighter animate-pulse">SINCRONIZANDO CON WALL STREET...</p>
            <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.3em]">Crunching market data & auction logs</p>
          </div>
        </div>
      )}

      {/* Results View */}
      <AnimatePresence>
        {result && !isAnalyzing && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            {/* Top Stats Row */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
                className="glass-card p-6 rounded-3xl border-white/5 flex flex-col gap-1"
              >
                <div className="flex items-center justify-between mb-2">
                  <BarChart3 className="w-5 h-5 text-blue-500" />
                  <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest bg-blue-500/10 px-2 py-0.5 rounded-full">Inventory Health</span>
                </div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Score del Portafolio</p>
                <p className="text-4xl font-black text-white">{result.portfolio_summary.portfolio_health_score}</p>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="glass-card p-6 rounded-3xl border-white/5 flex flex-col gap-1"
              >
                <div className="flex items-center justify-between mb-2">
                  <LineChart className="w-5 h-5 text-blue-500" />
                  <span className={cn(
                    "text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full",
                    result.portfolio_summary.market_trend.toLowerCase().includes('bull') ? "text-green-400 bg-green-400/10" : "text-amber-400 bg-amber-400/10"
                  )}>
                    Market Sentiment
                  </span>
                </div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Tendencia Global</p>
                <p className="text-2xl font-black text-white italic tracking-tighter truncate">{result.portfolio_summary.market_trend}</p>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="glass-card p-6 rounded-3xl border-white/5 flex flex-col gap-1"
              >
                <div className="flex items-center justify-between mb-2">
                  <Zap className="w-5 h-5 text-blue-500" />
                  <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest bg-blue-500/10 px-2 py-0.5 rounded-full">Assets</span>
                </div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Unidades Activas</p>
                <p className="text-4xl font-black text-white">{result.portfolio_summary.total_active_cars}</p>
              </motion.div>
            </div>

            {/* Main Analysis Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Hot Assets */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="glass-card p-8 rounded-[2.5rem] border-blue-500/20"
              >
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-10 h-10 bg-orange-500/20 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <h4 className="text-xl font-black text-white italic tracking-tighter">HOT ASSETS</h4>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Mayor Liquidez Estimada</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  {result.fastest_selling_assets.map((asset, idx) => (
                    <div key={idx} className="p-5 bg-white/5 rounded-2xl border border-white/5 hover:border-blue-500/30 transition-all group">
                      <div className="flex justify-between items-start mb-2">
                        <h5 className="font-bold text-white tracking-tight">{asset.make_model}</h5>
                        <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest bg-blue-500/10 px-2 py-0.5 rounded-full">
                          {asset.liquidity_index} Index
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed mb-3 line-clamp-2">{asset.why_is_hot}</p>
                      <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-slate-500">
                        <div className="w-1 h-1 bg-blue-600 rounded-full" />
                        Venta estimada: <span className="text-white">{asset.estimated_days_to_sell} días</span>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Trading Indicators */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="glass-card p-8 rounded-[2.5rem] border-blue-500/20"
              >
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-blue-500" />
                  </div>
                  <div>
                    <h4 className="text-xl font-black text-white italic tracking-tighter">TRADING LOGS</h4>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Indicadores de Desempeño</p>
                  </div>
                </div>

                <div className="space-y-4">
                   {result.trading_indicators.map((indicator, idx) => (
                    <div key={idx} className="p-5 bg-white/5 rounded-2xl border border-white/5">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{indicator.make_model}</span>
                        <span className="text-xs">{indicator.current_status}</span>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                           <ShieldCheck className="w-3 h-3 text-blue-400" />
                           <p className="text-xs font-bold text-white tracking-wide uppercase">{indicator.suggested_strategy}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <ArrowUpRight className="w-3 h-3 text-green-400" />
                          <p className="text-xs text-slate-400">Potencial: <span className="text-green-400 font-bold">{indicator.profit_margin_potential}</span></p>
                        </div>
                      </div>
                    </div>
                   ))}
                </div>
              </motion.div>
            </div>

            {/* Actionable Alerts */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="glass-card p-8 rounded-[2.5rem] border-amber-500/20 bg-amber-500/5"
            >
               <div className="flex items-center gap-4 mb-6">
                <div className="w-10 h-10 bg-amber-500/20 rounded-xl flex items-center justify-center">
                  <AlertCircle className="w-6 h-6 text-amber-500" />
                </div>
                <h4 className="text-xl font-black text-white italic tracking-tighter">ALERTAS DEL BROKER</h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {result.actionable_alerts.map((alert, idx) => (
                  <div key={idx} className="flex gap-4 p-4 bg-black/20 rounded-2xl border border-white/5 items-start">
                    <div className="w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center shrink-0 mt-0.5">
                      <ChevronRight className="w-3 h-3 text-black" />
                    </div>
                    <p className="text-sm font-medium text-slate-200 leading-relaxed italic">"{alert}"</p>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Reset Button */}
            <div className="flex justify-center pt-8">
              <button 
                onClick={() => setResult(null)}
                className="text-slate-500 hover:text-white text-[10px] font-bold uppercase tracking-[0.3em] transition-all"
              >
                Volver al Dashboard
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

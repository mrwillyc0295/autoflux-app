import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  TrendingDown, 
  AlertTriangle, 
  ArrowRight, 
  Zap, 
  Sparkles,
  RefreshCcw,
  Clock,
  History
} from 'lucide-react';
import { Car, LiquidationAdvice } from '../types';
import { analyzeLiquidation } from '../services/geminiService';
import { toast } from 'sonner';

interface LiquidationAdvisorProps {
  cars: Car[];
}

export const LiquidationAdvisor: React.FC<LiquidationAdvisorProps> = ({ cars }) => {
  const [analyzing, setAnalyzing] = useState(false);
  const [advice, setAdvice] = useState<Record<string, LiquidationAdvice>>({});
  const [showHistory, setShowHistory] = useState(false);

  const runAnalysis = async () => {
    if (cars.length === 0) {
      toast.error("No tienes vehículos activos para analizar.");
      return;
    }

    setAnalyzing(true);
    toast.loading("IA Broker analizando inventario estancado...", { id: 'liquid' });

    try {
      // Mock logic: find cars with low views and > 15 days (simulated)
      const stagnantCars = cars.filter(c => (c.views || 0) < 50);
      
      const newAdvice: Record<string, LiquidationAdvice> = {};
      
      for (const car of stagnantCars) {
        const res = await analyzeLiquidation(car, 24, 45); // Using mock days/score for demo
        if (res) newAdvice[car.id] = res;
      }

      setAdvice(newAdvice);
      toast.success("Análisis de Liquidación Completado", { id: 'liquid' });
    } catch (error) {
      toast.error("Fallo el protocolo de liquidación", { id: 'liquid' });
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="glass-card p-10 rounded-[3rem] border-white/5 bg-gradient-to-br from-red-600/5 via-transparent to-transparent relative overflow-hidden">
      {/* Decorative Background */}
      <div className="absolute -top-24 -right-24 w-64 h-64 bg-red-600/10 rounded-full blur-3xl" />
      
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 mb-12 relative z-10">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 bg-red-600/10 rounded-[1.5rem] flex items-center justify-center border border-red-500/20 shadow-lg shadow-red-900/20">
            <TrendingDown className="w-8 h-8 text-red-500" />
          </div>
          <div>
            <h2 className="text-3xl font-black text-white italic tracking-tighter uppercase leading-none">Liquidation Advisor</h2>
            <p className="text-red-500/60 text-[10px] font-bold uppercase tracking-[0.3em] mt-2">Protocolo Stop-Loss • Optimización de Liquidez</p>
          </div>
        </div>

        <div className="flex gap-4">
          <button 
            onClick={() => setShowHistory(!showHistory)}
            className="p-4 bg-white/5 rounded-2xl border border-white/10 hover:bg-white/10 transition-all text-slate-400"
          >
            <History className="w-5 h-5" />
          </button>
          <button 
            onClick={runAnalysis}
            disabled={analyzing}
            className="flex items-center gap-3 px-8 py-4 bg-red-600 text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest hover:bg-red-500 transition-all shadow-xl shadow-red-900/20 disabled:opacity-50"
          >
            {analyzing ? (
              <RefreshCcw className="w-4 h-4 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
            Escaneo de Activos
          </button>
        </div>
      </div>

      <div className="space-y-6 relative z-10">
        {Object.keys(advice).length === 0 ? (
          <div className="py-20 flex flex-col items-center justify-center text-center border-2 border-dashed border-white/5 rounded-[2.5rem]">
            <AlertTriangle className="w-12 h-12 text-slate-700 mb-4" />
            <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Sin alertas de estancamiento detectadas</p>
            <p className="text-slate-600 text-[10px] mt-1 italic">Realiza un escaneo para analizar la rotación de tu inventario.</p>
          </div>
        ) : (
          Object.entries(advice).map(([carId, info]) => {
            const car = cars.find(c => c.id === carId);
            if (!car) return null;
            
            return (
              <motion.div 
                key={carId}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-black/40 p-8 rounded-[2rem] border border-white/5 flex flex-col lg:flex-row items-center gap-8 group"
              >
                <div className="w-full lg:w-48 h-32 rounded-2xl overflow-hidden shrink-0">
                  <img src={car.image} alt={car.model} className="w-full h-full object-cover group-hover:scale-110 transition-duration-700" />
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="px-3 py-1 bg-red-600/20 text-red-500 text-[10px] font-black uppercase tracking-widest rounded-full">Alerta de Riesgo</span>
                    <span className="text-slate-500 text-[10px] font-bold uppercase tracking-widest flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      {info.days_on_market} Días en Mercado
                    </span>
                  </div>
                  <h4 className="text-2xl font-black text-white italic tracking-tighter uppercase mb-2">{car.make} {car.model}</h4>
                  <p className="text-slate-400 text-sm italic leading-relaxed line-clamp-2">{info.rationale}</p>
                </div>

                <div className="w-full lg:w-auto flex flex-col sm:flex-row items-center gap-6 lg:border-l lg:border-white/5 lg:pl-8">
                  <div className="text-center sm:text-right">
                    <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest mb-1">Precio Actual</p>
                    <p className="text-2xl font-black text-green-500 italic tracking-tighter line-through opacity-30">${car.price.toLocaleString()}</p>
                    <p className="text-3xl font-black text-green-500 italic tracking-tighter">${info.new_target_price.toLocaleString()}</p>
                  </div>
                  
                  <button className="w-full sm:w-auto px-8 py-4 bg-white/5 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-red-600 transition-all flex items-center gap-2 group">
                    Aplicar Stop-Loss
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </motion.div>
            );
          })
        )}
      </div>

      <div className="mt-12 p-8 bg-blue-600/5 rounded-[2rem] border border-blue-500/10 flex items-start gap-4">
        <Zap className="w-6 h-6 text-blue-500 shrink-0 mt-1" />
        <div>
          <p className="text-sm text-blue-100 font-bold tracking-wide leading-relaxed italic">
            "La liquidez es el combustible del crecimiento. Un activo estancado consume capital que podría estar rotando en modelos de mayor demanda (Hot Assets)."
          </p>
          <p className="text-[10px] text-blue-600 font-black uppercase tracking-widest mt-2">— BROKER IA AUTOFLUX</p>
        </div>
      </div>
    </div>
  );
};

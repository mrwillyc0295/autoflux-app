import React, { useState, useEffect } from 'react';
import { RefreshCw, Zap, Shield, AlertTriangle, Activity, CheckCircle, Brain, Wrench } from 'lucide-react';
import { toast } from 'sonner';
import { selfHeal } from '../services/geminiService';
import { cn } from '../lib/utils';

export const AutoFluxHub: React.FC = () => {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [suggestedFix, setSuggestedFix] = useState<string | null>("No hay problemas críticos detectados.");
  const [cacheStatus, setCacheStatus] = useState<"clean" | "dirty">("clean");
  const [currentCommand, setCurrentCommand] = useState("");
  const [isRepairing, setIsRepairing] = useState(false);
  const [healthScore, setHealthScore] = useState(100);
  const [auditLog, setAuditLog] = useState<{expert: string, result: string, color: string}[]>([]);

  const fetchDashboardData = async () => {
    setIsRefreshing(true);
    // Simulate n8n webhook call fetching status
    setTimeout(() => {
      const isDirty = Math.random() > 0.6;
      if (isDirty) {
        setCacheStatus("dirty");
        setSuggestedFix("El GEN Auditor ha detectado una desincronización en los contadores de estilo. Se recomienda re-indexación profunda.");
        setCurrentCommand("npm run cortex:reindex");
        setHealthScore(92);
      } else {
        setCacheStatus("clean");
        setSuggestedFix("Todos los sistemas están operando bajo los parámetros de los 8 expertos.");
        setCurrentCommand("");
        setHealthScore(100);
      }
      
      setAuditLog([
        { expert: 'El Toyotero', result: 'Fiabilidad del inventario confirmada (98% Japan Built)', color: 'border-red-500' },
        { expert: 'Truck Expert', result: 'Chasis verificado en el 100% de las nuevas unidades captadas', color: 'border-orange-500' },
        { expert: 'Market Hunter', result: 'Precios sincronizados (USA Auction + 40%)', color: 'border-emerald-500' },
        { expert: 'Gen Auditor', result: 'Coherencia lógica del sistema restaurada', color: 'border-purple-500' }
      ]);
      
      setIsRefreshing(false);
    }, 800);
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const runAutoRepair = async () => {
    setIsRepairing(true);
    setSuggestedFix("IA ANALIZANDO CÓDIGO Y LÓGICA DE NEGOCIO...");
    
    try {
      // Usamos el servicio real de Gemini para el Self-Heal
      const result = await selfHeal("Dashboard_Main", "Inconsistencia detectada en contadores de estilos de vehículos");
      
      if (result.fix_applied) {
        toast.success("✅ Autocuración Exitosa", {
          description: result.analysis || "El algoritmo ha sido optimizado por el Gen Auditor."
        });
        setCacheStatus("clean");
        setHealthScore(100);
        setSuggestedFix(result.recommendation || "Sistema estabilizado y optimizado.");
      } else {
        toast.error("Fallo Auditivo", {
          description: "No se pudo aplicar el parche virtual de forma segura."
        });
      }
    } catch (error) {
      console.error("Repair error:", error);
      toast.error("Error de Sistema", {
        description: "El Núcleo de Auditoría no respondió."
      });
    } finally {
      setIsRepairing(false);
    }
  };

  return (
    <div className="bg-[#020617] text-slate-50 p-5 md:p-6 rounded-[2rem] font-sans border border-slate-700/50 shadow-[0_0_40px_rgba(0,0,0,0.5)] relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-blue-500/10 blur-[100px] rounded-full pointer-events-none" />
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-64 h-64 bg-purple-500/10 blur-[100px] rounded-full pointer-events-none" />
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-blue-600/20 rounded-xl flex items-center justify-center border border-blue-500/30 shadow-[0_0_15px_rgba(59,130,246,0.2)]">
            <Shield className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h2 className="m-0 text-xl font-black text-white tracking-widest flex items-center gap-2 font-led">
              AUTOFLUX HUB 
              <span className="text-[9px] font-black tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 uppercase flex items-center gap-1 border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_6px_#10b981]"></span> ONLINE
              </span>
            </h2>
            <div className="flex items-center gap-2 mt-1 text-slate-500">
              <Activity className="w-3.5 h-3.5" />
              <span className="text-[10px] font-bold uppercase tracking-widest">Integridad: {healthScore}%</span>
            </div>
          </div>
        </div>
        
        <button 
          onClick={fetchDashboardData}
          disabled={isRefreshing}
          className="bg-white/5 hover:bg-white/10 border border-white/10 text-white px-4 py-2 rounded-xl cursor-pointer flex items-center gap-2 transition-all disabled:opacity-50 text-[10px] font-black uppercase tracking-widest"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-blue-400' : 'text-slate-400'}`} />
          Refrescar
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 relative z-10">
        {/* Suggested Action Section */}
        <div className={`p-5 md:p-6 rounded-[1.5rem] border relative overflow-hidden transition-all duration-500 ${cacheStatus === 'dirty' ? 'bg-amber-500/5 border-amber-500/30' : 'bg-blue-500/5 border-blue-500/20'}`}>
          <div className="absolute top-0 right-0 p-6 opacity-5">
            <Brain className="w-16 h-16 text-white" />
          </div>

          <div className="flex items-center gap-2 mb-4">
            {cacheStatus === 'dirty' ? (
              <AlertTriangle className="w-5 h-5 text-amber-400 animate-pulse" />
            ) : (
              <Zap className="w-5 h-5 text-blue-400" />
            )}
            <h4 className={`m-0 text-[11px] font-black uppercase tracking-widest ${cacheStatus === 'dirty' ? 'text-amber-400' : 'text-blue-400'}`}>
              {cacheStatus === 'dirty' ? '⚠️ Alerta Auditor' : 'Sistema Estable'}
            </h4>
          </div>
          
          <p className="text-sm text-slate-300 mb-6 font-medium leading-relaxed">
            {suggestedFix}
          </p>
          
          <div className="space-y-3">
            <button 
              onClick={runAutoRepair}
              disabled={isRepairing}
              id="autoflux-integrity-guard-button"
              className={cn(
                "w-full h-12 rounded-xl font-black text-[10px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 shadow-xl relative group",
                cacheStatus === 'dirty' 
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/40 animate-led-pulse-green' 
                  : 'bg-white/5 border border-white/10 text-slate-400 cursor-not-allowed'
              )}
            >
              {isRepairing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  SELF-HEALING...
                </>
              ) : (
                <>
                  <Wrench className="w-4 h-4 group-hover:rotate-12 transition-transform" />
                  AUTO-REPARAR
                </>
              )}
            </button>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-[9px] font-black text-slate-500 mb-2 flex items-center gap-2 uppercase tracking-[0.2em]">
            <Shield className="w-3 h-3 text-blue-500" /> Historial de Auditoría
          </h3>
          <div className="space-y-3">
            {auditLog.map((log, i) => (
              <div key={i} className={cn("p-3 bg-white/5 rounded-xl border-l-4 transition-all hover:bg-white/10", log.color)}>
                <div className="flex justify-between items-start">
                  <strong className="text-[9px] font-black uppercase tracking-widest text-white">{log.expert}</strong>
                  <CheckCircle className="w-3 h-3 text-emerald-500" />
                </div>
                <p className="text-[10px] text-slate-400 leading-tight mt-1">{log.result}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-8 p-5 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl flex items-center gap-4">
        <div className="w-10 h-10 bg-emerald-500/10 rounded-full flex items-center justify-center flex-shrink-0">
          <CheckCircle className="w-5 h-5 text-emerald-500" />
        </div>
        <p className="text-[10px] md:text-xs text-emerald-400 font-bold leading-relaxed uppercase tracking-wider italic">
          "El panel de los 8 expertos confirma que la infraestructura digital es 100% resiliente para el comercio en VZLA."
        </p>
      </div>
    </div>
  );
};

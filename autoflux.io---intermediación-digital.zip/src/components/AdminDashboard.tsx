import { Trash2, TrendingUp, BarChart3, Users, DollarSign, Activity, ChevronRight, MessageSquare, CarFront, Fuel, Settings2, Gauge, Share2, Calendar, MapPin, Edit3, Save, X as CloseIcon, Home, Download, CheckCircle, AlertTriangle, Clock as ClockIcon, Send, Plus, MessageCircle, Webhook, Monitor } from 'lucide-react';
import { Car } from '../types';
import { cn } from '../lib/utils';
import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { db } from '../services/firebase';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, updateDoc, doc, limit } from 'firebase/firestore';
import { AutoFluxHub } from './AutoFluxHub';
import { EpicVINModule } from './EpicVINModule';
import { motion, AnimatePresence } from 'motion/react';

import { OptimizedImage } from './OptimizedImage';

interface AdminDashboardProps {
  cars: Car[];
  users: { 
    name: string; 
    whatsapp: string; 
    photo?: string; 
    bio?: string;
    status?: 'active' | 'inactive';
    isNew?: boolean;
    lastLogin?: string;
    referredBy?: string;
  }[];
  onDeleteUser: (whatsapp: string) => void;
  onUpdateUser: (whatsapp: string, updatedData: Partial<{name: string, whatsapp: string}>) => void;
  onViewProfile: (seller: any) => void;
  onBack: () => void;
  onGoToMarketplace: () => void;
  onOpenExpertAudition: () => void;
  onShare: (car: Car) => void;
  onAddCar: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ cars, users, onDeleteUser, onUpdateUser, onViewProfile, onBack, onGoToMarketplace, onOpenExpertAudition, onShare, onAddCar }) => {
  const [activeTab, setActiveTab] = useState<'analytics' | 'users' | 'messages' | 'hub' | 'referrals'>('hub');
  const [referrals, setReferrals] = useState<any[]>([]);
  const [adminUsersPage, setAdminUsersPage] = useState(1);
  const adminUsersPerPage = 20;
  const paginatedUsers = users.slice(0, adminUsersPage * adminUsersPerPage);

  const [editingUser, setEditingUser] = useState<{name: string, whatsapp: string} | null>(null);
  const [deletingUser, setDeletingUser] = useState<{name: string, whatsapp: string} | null>(null);
  const [selectedUserSummary, setSelectedUserSummary] = useState<any | null>(null);
  const [editName, setEditName] = useState('');
  const [editWhatsapp, setEditWhatsapp] = useState('');
  const [selectedChat, setSelectedChat] = useState<any | null>(null);
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [chats, setChats] = useState<any[]>([]);
  const [adminReply, setAdminReply] = useState('');
  const chatEndRef = React.useRef<HTMLDivElement>(null);

  // Subscribe to all referrals
  React.useEffect(() => {
    if (activeTab === 'referrals') {
      const q = query(collection(db, 'referrals'), orderBy('createdAt', 'desc'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        setReferrals(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      }, (error) => {
        console.warn("Admin referrals sync failed", error.message);
      });
      return () => unsubscribe();
    }
  }, [activeTab]);

  const updateReferralStatus = async (id: string, status: string) => {
    try {
      await updateDoc(doc(db, 'referrals', id), {
        status,
        updatedAt: serverTimestamp()
      });
    } catch (e) {
      console.error("Error updating referral status", e);
    }
  };

  // Subscribe to all chats
  React.useEffect(() => {
    if (activeTab === 'messages') {
      const q = query(
        collection(db, 'chats'), 
        orderBy('updatedAt', 'desc'),
        limit(100)
      );
      const unsubscribe = onSnapshot(q, (snapshot) => {
        setChats(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      }, (error) => {
        console.warn("Admin chat sync failed", error.message);
      });
      return () => unsubscribe();
    }
  }, [activeTab]);

  // Subscribe to messages of selected chat
  React.useEffect(() => {
    if (selectedChat) {
      const q = query(
        collection(db, 'chats', selectedChat.id, 'messages'),
        orderBy('timestamp', 'desc'),
        limit(100)
      );
      const unsubscribe = onSnapshot(q, (snapshot) => {
        setChatMessages(snapshot.docs.map(doc => doc.data()).reverse());
      }, (error) => {
        console.warn("Admin message sync failed", error.message);
      });
      return () => unsubscribe();
    }
  }, [selectedChat]);

  React.useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleAdminReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminReply.trim() || !selectedChat) return;

    try {
      const chatId = selectedChat.id;
      const replyText = adminReply;
      setAdminReply('');

      await addDoc(collection(db, 'chats', chatId, 'messages'), {
        role: 'admin',
        text: replyText,
        timestamp: serverTimestamp()
      });

      await updateDoc(doc(db, 'chats', chatId), {
        status: 'responded',
        updatedAt: serverTimestamp()
      });
    } catch (e) {
      console.error("Error sending admin reply", e);
    }
  };

  const getStatusLight = (status: string) => {
    switch (status) {
      case 'new': return 'bg-green-500 shadow-[0_0_10px_#22c55e] animate-pulse';
      case 'responded': return 'bg-blue-500/50';
      case 'calm': return 'bg-slate-700';
      default: return 'bg-slate-700';
    }
  };

  const sellers = Array.from(new Set(cars.map(c => c.seller)));
  
  const sortedCars = [...cars].sort((a, b) => (b.views || 0) + (b.interactions || 0) - ((a.views || 0) + (a.interactions || 0)));
  const topCars = sortedCars.slice(0, 3);

  // Market Metrics
  const totalBaseValue = cars.reduce((acc, car) => acc + (car.basePrice || car.price), 0);
  const totalMarketValue = cars.reduce((acc, car) => acc + car.price, 0);
  const avgPrice = totalMarketValue / (cars.length || 1);
  const totalInteractions = cars.reduce((acc, car) => acc + (car.interactions || 0), 0);
  const totalViews = cars.reduce((acc, car) => acc + (car.views || 0), 0);
  const globalConversion = (totalInteractions / (totalViews || 1)) * 100;

  const handleEditClick = (user: {name: string, whatsapp: string}) => {
    setEditingUser(user);
    setEditName(user.name);
    setEditWhatsapp(user.whatsapp);
  };

  const handleSaveEdit = () => {
    if (editingUser) {
      onUpdateUser(editingUser.whatsapp, { name: editName, whatsapp: editWhatsapp });
      setEditingUser(null);
    }
  };

  const handleExportExcel = () => {
    const data = users.map(user => ({
      Nombre: user.name,
      WhatsApp: user.whatsapp,
      Estado: user.status === 'active' ? 'Activo' : 'Inactivo',
      Tipo: user.isNew ? 'Nuevo' : 'Constante',
      Referido_Por: user.referredBy || 'Directo',
      'Último Acceso': user.lastLogin ? new Date(user.lastLogin).toLocaleString() : 'N/A',
      Bio: user.bio || ''
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Dealers");
    XLSX.writeFile(workbook, "Reporte_Dealers_AutoFlux.xlsx");
  };

  const handleExportWhatsApp = () => {
    const textData = users.map(user => 
      `👤 *${user.name}*\n📱 ${user.whatsapp}${user.referredBy ? `\n🔗 Ref: ${user.referredBy}` : ''}\n📊 ${user.status === 'active' ? 'Activo' : 'Inactivo'}`
    ).join('\n\n');
    
    const message = `*REPORTE DE DEALERS AUTOFLUX*\nTotal: ${users.length}\n\n${textData}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleExportN8N = async () => {
    try {
      const data = users.map(user => ({
        name: user.name,
        whatsapp: user.whatsapp,
        status: user.status,
        isNew: user.isNew,
        lastLogin: user.lastLogin
      }));
      
      // Simulando webhook a n8n
      await fetch('https://n8n.autoflux.io/webhook/export-dealers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          event: "dealers_export", 
          timestamp: new Date().toISOString(),
          data 
        }),
      }).catch(err => console.warn('N8N webhook simulated error:', err)); // Ignoramos errores CORS reales para la simulacion
      
      alert("✅ Datos enviados exitosamente a n8n para sincronización.");
    } catch (error) {
      alert("Error al enviar datos a n8n.");
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-10 bg-[#070A11] relative selection:bg-blue-500/30">
      <div className="fixed top-0 left-0 w-full h-screen bg-[radial-gradient(circle_at_50%_-20%,#1e1b4b,transparent)] pointer-events-none opacity-50" />
      <div className="absolute top-0 left-0 w-full h-[500px] bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.03] pointer-events-none" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-12 md:mb-16 gap-8">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3">
              <button 
                onClick={onBack} 
                className="flex items-center gap-2 text-slate-500 hover:text-white transition-all text-[10px] font-black uppercase tracking-[0.2em] bg-white/5 px-4 py-2 rounded-xl border border-white/5 active:scale-95"
              >
                <ChevronRight className="w-3.5 h-3.5 rotate-180" />
                Salir del Panel
              </button>
              <div className="h-4 w-px bg-white/10 mx-1" />
              <div className="flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full">
                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse shadow-[0_0_8px_#3b82f6]" />
                <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest">Sistema en Línea</span>
              </div>
            </div>
            
            <h2 className="text-4xl md:text-6xl font-black text-white tracking-tighter leading-none">
              AUTOFLUX<span className="text-blue-600">.</span><span className="text-blue-600/50">CORE</span>
            </h2>
            <p className="text-slate-500 text-xs font-mono uppercase tracking-[0.3em] font-bold">Gestión de Operaciones Cuánticas</p>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-black rounded-2xl border border-white/10 shadow-2xl">
            {[
              { id: 'hub', label: 'Matriz', icon: Activity },
              { id: 'analytics', label: 'Inteligencia', icon: BarChart3 },
              { id: 'users', label: 'Red', icon: Users },
              { id: 'referrals', label: 'Recompensas', icon: DollarSign },
              { id: 'messages', label: 'Comunicaciones', icon: MessageSquare },
            ].map((tab) => (
              <button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={cn(
                  "flex items-center gap-2 px-5 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all relative group overflow-hidden",
                  activeTab === tab.id 
                    ? "bg-white text-black shadow-xl shadow-white/10" 
                    : "text-slate-500 hover:text-white"
                )}
              >
                <tab.icon className={cn("w-3.5 h-3.5", activeTab === tab.id ? "text-black" : "text-slate-600")} />
                {tab.label}
                {activeTab === tab.id && (
                  <motion.div 
                    layoutId="tab-glow"
                    className="absolute inset-0 bg-white/20 blur-xl pointer-events-none"
                  />
                )}
              </button>
            ))}
          </div>
        </div>
        
        {activeTab === 'hub' ? (
          <div className="max-w-5xl mx-auto w-full space-y-6">
            <AutoFluxHub />
            <EpicVINModule />
          </div>
        ) : activeTab === 'analytics' ? (
          <div className="space-y-12">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              {/* Left Column: Metrics & Main Actions */}
              <div className="lg:col-span-3 space-y-8">
              {/* Bento Grid Highlights */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2 glass-card p-8 rounded-[2.5rem] border-white/5 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                    <TrendingUp className="w-32 h-32 text-blue-500" />
                  </div>
                  <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.2em] mb-2">Market Liquidity</p>
                  <h3 className="text-5xl font-black text-white tracking-tighter mb-8 italic">
                    ${totalMarketValue.toLocaleString()}
                  </h3>
                  <div className="flex items-center gap-12">
                    <div>
                      <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Stock Portfolio</p>
                      <p className="text-xl font-bold text-white font-mono">{cars.length} Units</p>
                    </div>
                    <div>
                      <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Average Exit</p>
                      <p className="text-xl font-bold text-white font-mono">${Math.round(avgPrice).toLocaleString()}</p>
                    </div>
                  </div>
                </div>

                <div className="glass-card p-8 rounded-[2.5rem] border-white/10 bg-gradient-to-br from-blue-600 to-blue-900 group relative flex flex-col justify-between">
                  <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10" />
                  <div>
                    <p className="text-[10px] font-black text-white/60 uppercase tracking-[0.2em] mb-1">Conversion Node</p>
                    <h3 className="text-4xl font-black text-white tracking-tighter italic">{globalConversion.toFixed(1)}%</h3>
                  </div>
                  <div className="space-y-4">
                    <div className="w-full h-2 bg-black/20 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${globalConversion}%` }}
                        className="h-full bg-white rounded-full shadow-[0_0_15px_rgba(255,255,255,0.5)]"
                      />
                    </div>
                    <p className="text-[9px] font-bold text-white/70 uppercase tracking-widest leading-relaxed">
                      Efficiency threshold reached. Optimization recommended for luxury segment.
                    </p>
                  </div>
                </div>
              </div>

              {/* Secondary Metrics Row */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: 'Interactions', value: totalInteractions, icon: MessageSquare, color: 'text-green-400' },
                  { label: 'Raw Views', value: totalViews, icon: Activity, color: 'text-purple-400' },
                  { label: 'Network Points', value: users.length, icon: Users, color: 'text-amber-400' },
                  { label: 'Active Streams', value: chats.filter(c => c.status === 'new').length, icon: Webhook, color: 'text-red-400' },
                ].map((stat, i) => (
                  <div key={i} className="glass-card p-5 rounded-[2rem] border-white/5 hover:border-white/10 transition-all flex flex-col justify-between aspect-square md:aspect-auto md:h-32 group">
                    <div className="flex items-center justify-between">
                      <div className={cn("p-2 rounded-lg bg-white/5", stat.color)}>
                        <stat.icon className="w-4 h-4" />
                      </div>
                      <div className="w-1.5 h-1.5 rounded-full bg-white/10 group-hover:bg-green-500 animate-pulse" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest truncate">{stat.label}</p>
                      <p className="text-xl font-bold text-white font-mono">{stat.value.toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Action Hub */}
              <div className="glass-card p-1 rounded-[2.5rem] border-white/5 flex flex-col md:flex-row gap-1">
                <button 
                  onClick={onOpenExpertAudition}
                  className="flex-1 px-8 py-10 bg-white/5 hover:bg-white text-white hover:text-black rounded-[2.2rem] transition-all flex flex-col items-center justify-center gap-4 group"
                >
                  <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center group-hover:bg-black/5">
                    <Users className="w-6 h-6" />
                  </div>
                  <div className="text-center">
                    <p className="text-xs font-black uppercase tracking-widest">Expert Protocol</p>
                    <p className="text-[10px] font-bold text-slate-500 group-hover:text-black/60">Initialize Market Audit</p>
                  </div>
                </button>
                <button 
                  onClick={onAddCar}
                  className="flex-1 px-8 py-10 bg-white/5 hover:bg-[#A3FF47] text-white hover:text-black rounded-[2.2rem] transition-all flex flex-col items-center justify-center gap-4 group"
                >
                  <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center group-hover:bg-black/5">
                    <Plus className="w-6 h-6" />
                  </div>
                  <div className="text-center">
                    <p className="text-xs font-black uppercase tracking-widest">Inject Asset</p>
                    <p className="text-[10px] font-bold text-slate-500 group-hover:text-black/60">Deploy New Vehicle Entry</p>
                  </div>
                </button>
              </div>

              {/* Performance Table Section */}
              <div className="glass-card p-8 rounded-[2.5rem] border-white/5">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h4 className="text-xl font-black text-white uppercase tracking-tighter italic">Top Performing Nodes</h4>
                    <p className="text-slate-500 text-[10px] uppercase font-bold tracking-[0.2em] mt-1">Real-time asset traction data</p>
                  </div>
                  <BarChart3 className="w-6 h-6 text-slate-700" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {topCars.map((car, i) => {
                    const conversion = ((car.interactions || 0) / (car.views || 1)) * 100;
                    return (
                      <motion.div 
                        key={car.id} 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="p-6 rounded-3xl bg-white/5 border border-white/5 hover:border-blue-500/30 transition-all group relative overflow-hidden"
                      >
                        <div className="absolute top-0 right-0 px-3 py-1 bg-blue-600/20 text-blue-400 text-[8px] font-black uppercase tracking-widest rounded-bl-xl">
                          Rank 0{i + 1}
                        </div>
                        <p className="text-sm font-black text-white truncate mb-4">{car.make} {car.model}</p>
                        <div className="space-y-4">
                          <div className="flex justify-between items-end">
                            <div>
                              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Efficiency</p>
                              <p className="text-2xl font-black text-green-400 font-mono">{conversion.toFixed(1)}%</p>
                            </div>
                            <div className="text-right">
                              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Views</p>
                              <p className="text-sm font-bold text-white font-mono">{car.views}</p>
                            </div>
                          </div>
                          <button 
                            onClick={() => onShare(car)}
                            className="w-full py-2 bg-white/5 hover:bg-white text-white hover:text-black rounded-xl text-[9px] font-black uppercase tracking-widest transition-all"
                          >
                            Synchronize Node
                          </button>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Right Column: Live Hub Feed */}
            <div className="space-y-8">
              <div className="glass-card h-full rounded-[2.5rem] border-white/5 flex flex-col">
                <div className="p-8 border-b border-white/5">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-ping" />
                    <h3 className="text-sm font-black text-white uppercase tracking-widest italic">Live Operations Feed</h3>
                  </div>
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Quantum Stream v4.2</p>
                </div>
                
                <div className="flex-1 overflow-y-auto p-8 space-y-6 scrollbar-hide">
                  {[
                    { node: "SEC-AUDIT", msg: "Expert Audit completed for Toyota Hilux", time: "2m ago", type: "success" },
                    { node: "MKT-VIEW", msg: "Traffic surge detected in SUV segment", time: "5m ago", type: "warning" },
                    { node: "SYS-SYNC", msg: "n8n Webhook successfully dispatched", time: "12m ago", type: "info" },
                    { node: "CHAT-NEW", msg: "Encrypted link opened by [UID-921]", time: "18m ago", type: "alert" },
                    { node: "USER-REG", msg: "New Dealer verified in Matrix", time: "45m ago", type: "success" },
                    { node: "VAL-UPDT", msg: "Global pricing index recalibrated", time: "1h ago", type: "info" },
                    { node: "SEC-AUDIT", msg: "Salvage title detected in VIN scan", time: "2h ago", type: "error" },
                  ].map((log, i) => (
                    <div key={i} className="flex gap-4 group">
                      <div className="flex flex-col items-center">
                        <div className={cn(
                          "w-2 h-2 rounded-full ring-4 ring-black/50 mb-2",
                          log.type === 'success' ? 'bg-green-500' :
                          log.type === 'warning' ? 'bg-amber-500' :
                          log.type === 'error' ? 'bg-red-500' :
                          'bg-blue-500'
                        )} />
                        <div className="w-px h-full bg-white/5" />
                      </div>
                      <div className="pb-2">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[9px] font-black text-slate-600 font-mono italic">[{log.node}]</span>
                          <span className="text-[8px] font-bold text-slate-400 uppercase">{log.time}</span>
                        </div>
                        <p className="text-[11px] font-medium text-slate-300 leading-tight group-hover:text-white transition-colors">{log.msg}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-8 mt-auto border-t border-white/5 bg-black/20">
                  <div className="space-y-4">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest text-center">System Integrity Status</p>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 24 }).map((_, i) => (
                        <div 
                          key={i} 
                          className="flex-1 h-3 rounded-sm bg-white/5 relative overflow-hidden"
                        >
                          <motion.div 
                            animate={{ opacity: [0.2, 1, 0.2] }}
                            transition={{ duration: 2, repeat: Infinity, delay: i * 0.1 }}
                            className={cn("absolute inset-0", i < 18 ? "bg-blue-500/50" : "bg-white/10")} 
                          />
                        </div>
                      ))}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[8px] font-black text-blue-500 uppercase">Load: 31.4%</span>
                      <span className="text-[8px] font-black text-green-500 uppercase">99.98% Healthy</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
            {/* Sellers Section */}
            <div className="space-y-6 md:space-y-10">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3 md:gap-4">
                  <div className="w-1 md:w-1.5 h-6 md:h-8 bg-blue-600 rounded-full" />
                  <div>
                    <h3 className="text-xl md:text-2xl font-extrabold text-white tracking-tight">Inventario</h3>
                    <p className="text-slate-500 text-[10px] md:text-sm">Distribución por unidad de negocio</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 px-3 md:px-4 py-1.5 md:py-2 bg-white/5 rounded-xl md:rounded-2xl border border-white/10 w-fit">
                  <Users className="w-3 h-3 md:w-4 md:h-4 text-slate-500" />
                  <span className="text-[9px] md:text-xs font-mono text-slate-400 uppercase tracking-widest">{sellers.length} Activos</span>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6 md:gap-10">
                {sellers.map(seller => {
                  const sellerCars = sortedCars.filter(c => c.seller === seller);
                  const sellerValue = sellerCars.reduce((acc, c) => acc + c.price, 0);
                  const sellerInteractions = sellerCars.reduce((acc, c) => acc + (c.interactions || 0), 0);
                  
                  return (
                    <div key={seller} className="relative group">
                      {/* Seller Header Card */}
                      <div className="glass-card p-5 md:p-8 rounded-[2rem] md:rounded-[2.5rem] mb-4 md:mb-6 border-white/5 group-hover:border-blue-500/20 transition-all">
                        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                          <div className="flex items-center gap-4 md:gap-5">
                            <div className="w-12 h-12 md:w-16 md:h-16 bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl md:rounded-3xl flex items-center justify-center shadow-xl shadow-blue-900/20">
                              <Users className="w-6 h-6 md:w-8 md:h-8 text-white" />
                            </div>
                            <div>
                              <h3 className="text-lg md:text-2xl font-bold text-white tracking-tight">{seller}</h3>
                              <div className="flex flex-wrap items-center gap-2 mt-1">
                                <span className="px-1.5 py-0.5 bg-green-500/10 text-green-400 text-[8px] md:text-[10px] font-bold uppercase tracking-widest rounded-md border border-green-500/20">Verificado</span>
                                <div className="flex items-center gap-1 px-1.5 py-0.5 bg-blue-500/10 text-blue-400 text-[8px] md:text-[10px] font-bold uppercase tracking-widest rounded-md border border-blue-500/20">
                                  <CarFront className="w-2.5 h-2.5 md:w-3 md:h-3" />
                                  <span>{sellerCars.length} Stock</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-6 px-3 md:px-6 py-3 md:py-4 bg-white/5 rounded-2xl md:rounded-3xl border border-white/5">
                            <div className="text-left w-full min-w-0 break-words">
                              <p className="text-[9px] md:text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-0.5 md:mb-1 leading-tight">Valor Total</p>
                              <p className="text-xs md:text-xl font-bold text-white font-display truncate">${sellerValue.toLocaleString()}</p>
                            </div>
                            <div className="text-left w-full min-w-0 break-words">
                              <p className="text-[9px] md:text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-0.5 md:mb-1 leading-tight">Interac.</p>
                              <p className="text-xs md:text-xl font-bold text-blue-400 font-display truncate">{sellerInteractions}</p>
                            </div>
                            <div className="text-left w-full min-w-0 break-words">
                              <p className="text-[9px] md:text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-0.5 md:mb-1 leading-tight">Valor Promedio</p>
                              <p className="text-xs md:text-xl font-bold text-slate-300 font-display truncate">${Math.round(sellerValue / (sellerCars.length || 1)).toLocaleString()}</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Cars Grid for this Seller */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 pl-2 md:pl-8 border-l-2 border-white/5 ml-4 md:ml-12">
                        {sellerCars.map(car => {
                          const conversion = ((car.interactions || 0) / (car.views || 1)) * 100;
                          const whatsappUrl = car.sellerWhatsApp ? `https://wa.me/${car.sellerWhatsApp.replace(/\D/g, '')}` : null;
                          
                          return (
                            <div key={car.id} className="glass-card p-5 md:p-6 rounded-[1.5rem] md:rounded-[2rem] border-white/5 hover:border-blue-500/30 transition-all hover:-translate-y-1 duration-300">
                              <div className="flex justify-between items-start mb-4 md:mb-6">
                                <div className="min-w-0">
                                  <h4 className="font-bold text-white text-base md:text-lg tracking-tight truncate">{car.make} {car.model}</h4>
                                  <div className="flex items-center gap-2 mt-1">
                                    <span className="text-[8px] md:text-[10px] font-mono text-slate-500 uppercase">Ref: {car.id}</span>
                                    <span className="w-1 h-1 bg-slate-700 rounded-full" />
                                    <span className="text-[8px] md:text-[10px] font-mono text-blue-400 font-bold uppercase">Activo</span>
                                  </div>
                                </div>
                                {whatsappUrl && (
                                  <a 
                                    href={whatsappUrl} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="w-10 h-10 md:w-12 md:h-12 bg-green-500/10 text-green-400 rounded-xl md:rounded-2xl flex items-center justify-center hover:bg-green-500 hover:text-white transition-all shadow-lg shadow-green-500/10 group/wa shrink-0"
                                    title="Contactar Dealer"
                                  >
                                    <MessageSquare className="w-5 h-5 md:w-6 md:h-6 group-hover/wa:scale-110 transition-transform" />
                                  </a>
                                )}
                              </div>

                              <div className="space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                                  <div className="bg-white/5 p-2 rounded-xl border border-white/5 flex flex-row md:flex-col items-center justify-center gap-3 md:gap-1 text-center hover:bg-white/10 transition-colors">
                                    <Settings2 className="w-3.5 h-3.5 md:w-3 md:h-3 text-blue-400" />
                                    <span className="text-[9px] md:text-[8px] text-slate-300 font-bold uppercase tracking-tighter">{car.transmission || 'N/A'}</span>
                                  </div>
                                  <div className="bg-white/5 p-2 rounded-xl border border-white/5 flex flex-row md:flex-col items-center justify-center gap-3 md:gap-1 text-center hover:bg-white/10 transition-colors">
                                    <Fuel className="w-3.5 h-3.5 md:w-3 md:h-3 text-green-400" />
                                    <span className="text-[9px] md:text-[8px] text-slate-300 font-bold uppercase tracking-tighter">{car.fuelType || 'N/A'}</span>
                                  </div>
                                  <div className="bg-white/5 p-2 rounded-xl border border-white/5 flex flex-row md:flex-col items-center justify-center gap-3 md:gap-1 text-center hover:bg-white/10 transition-colors">
                                    <Gauge className="w-3.5 h-3.5 md:w-3 md:h-3 text-yellow-400" />
                                    <span className="text-[9px] md:text-[8px] text-slate-300 font-bold uppercase tracking-tighter">{car.engineLiters ? `${car.engineLiters}L` : 'N/A'}</span>
                                  </div>
                                </div>

                                <div className="grid grid-cols-2 gap-2">
                                  <div className="p-3 bg-blue-500/5 rounded-2xl border border-blue-500/10 hover:bg-blue-500/10 transition-all group/stat min-w-0 overflow-hidden">
                                    <div className="flex items-center gap-1.5 mb-1.5">
                                      <Activity className="w-3 h-3 text-blue-400 shrink-0" />
                                      <p className="text-[8px] font-bold text-slate-500 uppercase tracking-wider truncate">Vistas</p>
                                    </div>
                                    <div className="flex items-end justify-between gap-1">
                                      <span className="text-lg font-bold text-white font-display leading-none truncate">{car.views || 0}</span>
                                      <span className="text-[8px] text-blue-400 font-mono font-bold shrink-0">+{Math.round((car.views || 0) * 0.1)}%</span>
                                    </div>
                                  </div>
                                  <div className="p-3 bg-purple-500/5 rounded-2xl border border-purple-500/10 hover:bg-purple-500/10 transition-all group/stat min-w-0 overflow-hidden">
                                    <div className="flex items-center gap-1.5 mb-1.5">
                                      <TrendingUp className="w-3 h-3 text-purple-400 shrink-0" />
                                      <p className="text-[8px] font-bold text-slate-500 uppercase tracking-wider truncate">Interac.</p>
                                    </div>
                                    <div className="flex items-end justify-between gap-1">
                                      <span className="text-lg font-bold text-white font-display leading-none truncate">{car.interactions || 0}</span>
                                      <span className="text-[8px] text-purple-400 font-mono font-bold shrink-0">{conversion.toFixed(1)}%</span>
                                    </div>
                                  </div>
                                </div>

                                <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                                  <div className="flex justify-between items-center mb-2">
                                    <div className="flex items-center gap-2">
                                      <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                                      <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">Índice de Tracción</span>
                                    </div>
                                    <span className="text-[10px] text-blue-400 font-black font-mono">{Math.min(100, Math.round(conversion * 5))}%</span>
                                  </div>
                                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                    <div 
                                      className="h-full bg-gradient-to-r from-blue-600 via-purple-600 to-green-400 rounded-full transition-all duration-1000 shadow-[0_0_10px_rgba(37,99,235,0.5)]" 
                                      style={{ width: `${Math.min(100, Math.round(conversion * 5))}%` }} 
                                    />
                                  </div>
                                </div>

                                <div className="pt-4 flex flex-wrap items-center justify-between gap-3 md:gap-4 border-t border-white/5">
                                  <div className="flex flex-col gap-1 w-full sm:w-auto flex-1">
                                    <div className="flex items-center justify-between gap-4 border-b border-white/5 pb-1 mb-1">
                                      <span className="text-[8px] md:text-[9px] font-bold text-slate-500 uppercase tracking-widest">Precio Dealer</span>
                                      <span className="text-xs font-bold text-green-500 font-mono">
                                        ${(car.basePrice || car.price).toLocaleString()}
                                      </span>
                                    </div>
                                    <div className="flex items-center justify-between gap-4">
                                      <span className="text-[9px] md:text-[10px] font-black text-blue-400 uppercase tracking-widest">P. Público</span>
                                      <span className="text-base md:text-lg font-black text-green-500 font-display">
                                        ${car.price.toLocaleString()}
                                      </span>
                                    </div>
                                  </div>
                                  <div className="flex gap-2 shrink-0">
                                    <button 
                                      onClick={async (e) => {
                                        e.stopPropagation();
                                        try {
                                          const nextStatus = car.status === 'active' ? 'sold' : 'active';
                                          await updateDoc(doc(db, 'cars', car.id), {
                                            status: nextStatus,
                                            updatedAt: serverTimestamp()
                                          });
                                        } catch (err) {
                                          console.error("Error updating car status", err);
                                        }
                                      }}
                                      className={cn(
                                        "px-3 md:px-4 py-1.5 md:py-2 border rounded-lg md:rounded-xl font-bold text-[8px] md:text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 transition-all",
                                        car.status === 'active'
                                          ? "bg-red-500/10 border-red-500/20 text-red-400 hover:bg-red-500 hover:text-white"
                                          : "bg-green-500/10 border-green-500/20 text-green-400 hover:bg-green-500 hover:text-white"
                                      )}
                                      title={car.status === 'active' ? "Marcar como Vendido" : "Marcar como Disponible"}
                                    >
                                      {car.status === 'active' ? <AlertTriangle className="w-3 md:w-3.5 h-3 md:h-3.5" /> : <CheckCircle className="w-3 md:w-3.5 h-3 md:h-3.5" />}
                                      {car.status === 'active' ? 'Sold' : 'Active'}
                                    </button>
                                    <button 
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        onShare(car);
                                      }}
                                      className="px-3 md:px-4 py-1.5 md:py-2 bg-white/5 border border-white/10 rounded-lg md:rounded-xl text-white font-bold text-[8px] md:text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-blue-600 hover:border-blue-500 transition-all"
                                    >
                                      <Share2 className="w-3 md:w-3.5 h-3 md:h-3.5" />
                                      Share
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : activeTab === 'referrals' ? (
          <div className="space-y-8">
            <div className="glass-card p-10 rounded-[3rem] border-white/5 flex items-center justify-between">
              <div>
                <h3 className="text-3xl font-black text-white italic tracking-tighter">Reward Network</h3>
                <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.3em] mt-2">Active referrers & commission streams</p>
              </div>
              <div className="px-6 py-3 bg-amber-500/10 border border-amber-500/20 rounded-2xl">
                <span className="text-sm font-black text-amber-400 font-mono tracking-tighter">TOTAL_NODES: {referrals.length}</span>
              </div>
            </div>

            <div className="glass-card rounded-[3rem] border-white/5 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-white/5">
                      <th className="py-6 px-8 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Target Node</th>
                      <th className="py-6 px-8 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Origin (UID)</th>
                      <th className="py-6 px-8 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Comm-Link</th>
                      <th className="py-6 px-8 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Sync Status</th>
                      <th className="py-6 px-8 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {referrals.map((ref, i) => (
                      <motion.tr 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.02 }}
                        key={ref.id} 
                        className="hover:bg-white/[0.02] transition-colors"
                      >
                        <td className="py-6 px-8">
                          <p className="text-sm font-black text-white">{ref.refereeName}</p>
                          <p className="text-[9px] text-slate-500 font-mono mt-0.5">
                            {ref.createdAt?.toDate ? new Date(ref.createdAt.toDate()).toLocaleDateString() : 'N/A'}
                          </p>
                        </td>
                        <td className="py-6 px-8">
                          <span className="text-xs font-mono text-slate-400 bg-white/5 px-2 py-1 rounded-md">
                            {users.find(u => u.name.replace(/\s+/g, '').toLowerCase() === (ref.referrerUserId || '').toLowerCase())?.name || ref.referrerUserId}
                          </span>
                        </td>
                        <td className="py-6 px-8">
                          <p className="text-xs text-white font-mono">{ref.refereeWhatsApp}</p>
                        </td>
                        <td className="py-6 px-8">
                          <select 
                            value={ref.status} 
                            onChange={(e) => updateReferralStatus(ref.id, e.target.value)}
                            className={cn(
                              "text-[9px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full outline-none border-none cursor-pointer transition-all",
                              ref.status === 'converted' ? "bg-green-500 text-white shadow-lg shadow-green-500/20" : 
                              ref.status === 'reserved' ? "bg-amber-600 text-white shadow-lg shadow-amber-600/20" :
                              "bg-[#1A1E29] text-slate-500 hover:bg-slate-800"
                            )}
                          >
                            <option value="pending">Pending</option>
                            <option value="contacted">Contacted</option>
                            <option value="reserved">Reserved</option>
                            <option value="converted">Converted</option>
                          </select>
                        </td>
                        <td className="py-6 px-8 text-right">
                          <button 
                            onClick={() => window.open(`https://wa.me/${ref.refereeWhatsApp?.replace(/\D/g, '')}`, '_blank')}
                            className="p-3 bg-green-500/10 text-green-400 rounded-xl hover:bg-green-500 hover:text-white transition-all shadow-lg shadow-green-500/5 group"
                          >
                            <MessageSquare className="w-5 h-5 group-hover:scale-110 transition-transform" />
                          </button>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : activeTab === 'messages' ? (
          <div className="glass-card rounded-[3rem] border-white/5 overflow-hidden flex flex-col md:flex-row h-[800px]">
            {/* List of Chats */}
            <div className="w-full md:w-96 border-r border-white/5 flex flex-col bg-black/20">
              <div className="p-8 border-b border-white/5">
                <h3 className="text-white font-black text-lg italic tracking-tighter uppercase">Comm-Link Matrix</h3>
                <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em] mt-1">Live encrypted streams</p>
              </div>
              <div className="flex-1 overflow-y-auto scrollbar-hide py-4">
                {chats.length > 0 ? (
                  chats.map(chat => (
                    <button
                      key={chat.id}
                      onClick={() => setSelectedChat(chat)}
                      className={cn(
                        "w-full px-8 py-6 flex items-center gap-5 transition-all hover:bg-white/[0.03] text-left relative",
                        selectedChat?.id === chat.id ? "bg-white/[0.05]" : ""
                      )}
                    >
                      {selectedChat?.id === chat.id && (
                        <div className="absolute left-0 top-1/4 bottom-1/4 w-1 bg-blue-600 rounded-r-full shadow-[0_0_15px_#2563eb]" />
                      )}
                      <div className="relative">
                        <div className="w-12 h-12 bg-gradient-to-br from-slate-800 to-slate-900 border border-white/10 rounded-2xl flex items-center justify-center font-bold text-blue-400 capitalize text-xl">
                          {chat.userName?.charAt(0) || '?'}
                        </div>
                        <div className={cn("absolute -top-1 -right-1 w-4 h-4 rounded-full border-4 border-[#070A11]", getStatusLight(chat.status))} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex justify-between items-center mb-1">
                          <p className="text-white font-black text-sm truncate">{chat.userName || "Unknown Node"}</p>
                          <span className="text-[8px] font-bold text-slate-600 uppercase font-mono">
                            {chat.updatedAt?.toDate ? new Date(chat.updatedAt.toDate()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                          </span>
                        </div>
                        <p className="text-slate-500 text-[10px] font-bold truncate tracking-tight">{chat.lastMessage}</p>
                      </div>
                    </button>
                  ))
                ) : (
                  <div className="p-10 text-center">
                    <Webhook className="w-10 h-10 text-slate-800 mx-auto mb-4 animate-pulse" />
                    <p className="text-slate-600 font-mono text-[10px] uppercase font-bold tracking-widest italic">Scanning network for active signals...</p>
                  </div>
                )}
              </div>
            </div>

            {/* Chat Content */}
            <div className="flex-1 flex flex-col bg-[#0A0D16]">
              {selectedChat ? (
                <>
                  <div className="p-8 border-b border-white/10 flex items-center justify-between bg-black">
                    <div>
                      <h4 className="text-white font-black text-xl italic">{selectedChat.userName}</h4>
                      <p className="text-slate-500 text-[9px] font-black font-mono uppercase tracking-widest opacity-50 mt-1">Node: {selectedChat.userId}</p>
                    </div>
                    <div className="flex items-center gap-6">
                      <AnimatePresence>
                        {selectedChat.status === 'new' && (
                          <motion.span 
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            exit={{ scale: 0 }}
                            className="text-[9px] font-black text-green-400 uppercase tracking-widest bg-green-400/10 px-4 py-2 rounded-xl border border-green-500/20 shadow-lg shadow-green-500/5"
                          >
                            Priority Input
                          </motion.span>
                        )}
                      </AnimatePresence>
                      <button 
                         onClick={async () => {
                           await updateDoc(doc(db, 'chats', selectedChat.id), { status: 'calm', updatedAt: serverTimestamp() });
                         }}
                         className="p-3 bg-white/5 text-slate-500 hover:text-white rounded-xl transition-all border border-white/5"
                         title="Archive Stream"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                  <div className="flex-1 overflow-y-auto p-8 space-y-6 scrollbar-hide">
                    {chatMessages.map((msg, i) => (
                      <motion.div 
                        key={i} 
                        initial={{ opacity: 0, x: msg.role === 'admin' ? 20 : -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className={cn(
                          "max-w-[80%] p-5 rounded-[2rem] text-sm leading-relaxed relative group",
                          msg.role === 'admin' 
                            ? "bg-blue-600 text-white ml-auto rounded-tr-none shadow-xl shadow-blue-600/10" 
                            : msg.role === 'model'
                              ? "bg-slate-900 text-slate-400 border border-white/5 italic rounded-tl-none"
                              : "bg-white/10 text-white rounded-tl-none border border-white/5"
                        )}
                      >
                        <p className="font-medium">{msg.text}</p>
                        <div className="flex items-center justify-between mt-3 opacity-30 group-hover:opacity-100 transition-opacity">
                          <span className="text-[8px] font-black uppercase tracking-[0.2em]">
                            {msg.role === 'admin' ? 'Authorized Response' : msg.role === 'model' ? 'Core Intelligence' : 'Signal Origin'}
                          </span>
                          <span className="text-[8px] font-mono">
                            {msg.timestamp?.toDate ? new Date(msg.timestamp.toDate()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                          </span>
                        </div>
                      </motion.div>
                    ))}
                    <div ref={chatEndRef} />
                  </div>
                  <form onSubmit={handleAdminReply} className="p-8 border-t border-white/5 bg-black/40">
                    <div className="relative group">
                      <input 
                        type="text" 
                        value={adminReply}
                        onChange={(e) => setAdminReply(e.target.value)}
                        placeholder="Transmit encrypted signal..."
                        className="w-full p-6 bg-white/5 border border-white/10 rounded-3xl text-white outline-none focus:border-blue-500 focus:bg-white/10 transition-all placeholder:text-slate-700 font-medium"
                      />
                      <button 
                        type="submit"
                        disabled={!adminReply.trim()}
                        className="absolute right-3 top-3 bottom-3 px-8 bg-white hover:bg-blue-500 text-black hover:text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-xl disabled:opacity-50 disabled:grayscale"
                      >
                        Send
                      </button>
                    </div>
                  </form>
                </>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-10">
                  <div className="w-24 h-24 bg-white/5 rounded-[2rem] flex items-center justify-center mb-6 border border-white/10 shadow-2xl relative overflow-hidden">
                    <div className="absolute inset-0 bg-blue-500/5 blur-xl group-hover:bg-blue-500/10 transition-colors" />
                    <MessageSquare className="w-10 h-10 text-slate-700 relative z-10" />
                  </div>
                  <h3 className="text-xl font-black text-white italic tracking-tighter uppercase mb-2">Awaiting Spectrum Signal</h3>
                  <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em] max-w-xs leading-loose">Select a node from the Matrix to establish a secure comm-link.</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="glass-card p-5 md:p-8 rounded-[2rem] md:rounded-[2.5rem]">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-8 relative z-10">
              <div>
                <h3 className="text-3xl font-black text-white italic tracking-tighter uppercase">Network Protocol: Dealers</h3>
                <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.3em] mt-2">Managing {users.length} authenticated nodes</p>
              </div>
              <div className="flex flex-wrap gap-3">
                <button 
                  onClick={handleExportExcel}
                  className="px-6 py-3 bg-white/5 hover:bg-white text-white hover:text-black rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 border border-white/10 active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  Excel Matrix
                </button>
                <button 
                  onClick={handleExportWhatsApp}
                  className="px-6 py-3 bg-green-500/10 text-green-400 hover:bg-green-500 hover:text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 border border-green-500/20 active:scale-95"
                >
                  <MessageCircle className="w-4 h-4" />
                  Sync WhatsApp
                </button>
              </div>
            </div>

            {/* Desktop Table Matrix View */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-white/5 border-b border-white/5">
                    <th className="py-6 px-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Node Identity</th>
                    <th className="py-6 px-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] text-center">Status Matrix</th>
                    <th className="py-6 px-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] text-center">Origin Access</th>
                    <th className="py-6 px-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Link Protocol</th>
                    <th className="py-6 px-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {paginatedUsers.length > 0 ? paginatedUsers.map((user, i) => (
                    <motion.tr 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: i * 0.02 }}
                      key={user.whatsapp || i} 
                      className="group"
                    >
                      <td className="py-6 px-4 group-hover:bg-white/[0.02] transition-colors">
                        <div 
                          className="flex items-center gap-4 cursor-pointer group/user"
                          onClick={() => setSelectedUserSummary(user)}
                        >
                          <div className="w-12 h-12 bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl flex items-center justify-center font-bold text-slate-300 overflow-hidden border border-white/10 group-hover:scale-110 transition-transform">
                            {user.photo ? (
                              <OptimizedImage 
                                src={user.photo} 
                                alt={user.name} 
                                className="w-full h-full object-cover" 
                                containerClassName="w-full h-full"
                                width={100}
                              />
                            ) : (
                              <div className="w-full h-full bg-blue-600/10 flex items-center justify-center text-blue-400 font-black italic">
                                {user.name.charAt(0)}
                              </div>
                            )}
                          </div>
                          <div>
                            <span className="text-white font-black text-sm block group-hover:text-blue-400 transition-colors">{user.name}</span>
                            {user.lastLogin && (
                              <span className="text-[8px] text-slate-600 font-mono font-bold uppercase tracking-widest mt-1 block">LAST_SYNC: {new Date(user.lastLogin).toLocaleDateString()}</span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-6 px-4 group-hover:bg-white/[0.02] transition-colors">
                        <div className="flex items-center justify-center gap-2">
                          <div className={cn(
                            "px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest border",
                            user.status === 'active' ? "bg-green-500/10 text-green-400 border-green-500/20" : "bg-slate-800 text-slate-500 border-white/5"
                          )}>
                            {user.status === 'active' ? 'Active' : 'Offline'}
                          </div>
                          {user.isNew && (
                            <div className="px-3 py-1 bg-blue-500/10 text-blue-400 text-[8px] font-black uppercase tracking-widest rounded-full border border-blue-500/20">
                              New Signal
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="py-6 px-4 group-hover:bg-white/[0.02] transition-colors">
                        <div className="flex justify-center">
                          {user.referredBy ? (
                            <span className="px-3 py-1 bg-white/5 text-blue-400 rounded-lg text-[9px] font-black uppercase tracking-widest border border-white/10">
                              Ref: {user.referredBy}
                            </span>
                          ) : (
                            <span className="text-[8px] text-slate-600 font-black uppercase tracking-widest">Direct Link</span>
                          )}
                        </div>
                      </td>
                      <td className="py-6 px-4 group-hover:bg-white/[0.02] transition-colors">
                        <span className="font-mono text-blue-500 text-xs font-bold tracking-tight">{user.whatsapp}</span>
                      </td>
                      <td className="py-6 px-4 group-hover:bg-white/[0.02] transition-colors text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => handleEditClick(user)}
                            className="p-3 text-slate-500 hover:text-white hover:bg-white/10 rounded-xl transition-all"
                            title="Recalibrate Node"
                          >
                            <Edit3 className="w-5 h-5" />
                          </button>
                          <button 
                            onClick={() => setDeletingUser(user)}
                            className="p-3 text-red-500/50 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all"
                            title="Purge Connection"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  )) : (
                    <tr>
                      <td colSpan={5} className="py-24 text-center">
                        <Activity className="w-12 h-12 text-slate-800 mx-auto mb-4 opacity-50" />
                        <p className="text-slate-600 font-mono text-[10px] uppercase font-black tracking-[0.3em] italic">
                          NO_SIGNAL_DETECTED
                        </p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Mobile Card View */}
            <div className="md:hidden space-y-4">
              {paginatedUsers.length > 0 ? paginatedUsers.map((user, i) => (
                <div key={i} className="bg-white/5 p-5 rounded-2xl border border-white/5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div 
                      className="flex items-center gap-3 cursor-pointer group/user"
                      onClick={() => setSelectedUserSummary(user)}
                    >
                      <div className="w-10 h-10 bg-gradient-to-br from-slate-700 to-slate-800 rounded-xl flex items-center justify-center font-bold text-slate-300 overflow-hidden border border-white/10 group-hover/user:border-blue-500/50 transition-all">
                        {user.photo ? (
                          <OptimizedImage 
                            src={user.photo} 
                            alt={user.name} 
                            className="w-full h-full object-cover" 
                            containerClassName="w-full h-full"
                            width={80}
                          />
                        ) : (
                          <div className="w-full h-full bg-blue-600/20 flex items-center justify-center text-blue-400">
                            {user.name.charAt(0)}
                          </div>
                        )}
                      </div>
                      <div>
                        <span className="text-white font-bold block text-sm group-hover/user:text-blue-400 transition-colors">{user.name}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] text-blue-400 font-mono">{user.whatsapp}</span>
                          {user.referredBy && (
                            <span className="text-[8px] bg-blue-600/20 text-blue-400 px-1.5 py-0.5 rounded border border-blue-500/20 font-bold uppercase">
                              Ref: {user.referredBy}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <button 
                        onClick={() => handleEditClick(user)}
                        className="p-2 bg-white/5 rounded-lg text-slate-400"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => setDeletingUser(user)}
                        className="p-2 bg-red-500/10 rounded-lg text-red-400"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between pt-3 border-t border-white/5">
                    <div className="flex gap-2">
                      {user.status === 'active' ? (
                        <div className="flex items-center gap-1 px-2 py-0.5 bg-green-500/10 text-green-400 text-[8px] font-bold uppercase rounded-md">
                          Activo
                        </div>
                      ) : (
                        <div className="flex items-center gap-1 px-2 py-0.5 bg-red-500/10 text-red-400 text-[8px] font-bold uppercase rounded-md">
                          Inactivo
                        </div>
                      )}
                      {user.isNew ? (
                        <div className="flex items-center gap-1 px-2 py-0.5 bg-blue-500/10 text-blue-400 text-[8px] font-bold uppercase rounded-md">
                          Nuevo
                        </div>
                      ) : (
                        <div className="flex items-center gap-1 px-2 py-0.5 bg-purple-500/10 text-purple-400 text-[8px] font-bold uppercase rounded-md">
                          Constante
                        </div>
                      )}
                    </div>
                    {user.lastLogin && (
                      <span className="text-[8px] text-slate-500 font-mono uppercase">Visto: {new Date(user.lastLogin).toLocaleDateString()}</span>
                    )}
                  </div>
                </div>
              )) : (
                <div className="py-12 text-center text-slate-600 font-mono text-xs italic">
                  NO_DATA_FOUND
                </div>
              )}
            </div>

            {users.length > paginatedUsers.length && (
              <div className="p-8 border-t border-white/5 flex justify-center">
                <button 
                  onClick={() => setAdminUsersPage(p => p + 1)}
                  className="px-8 py-3 bg-white/5 hover:bg-white text-white hover:text-black rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border border-white/5 active:scale-95"
                >
                  Load More Nodes
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modernized Modals */}
      <AnimatePresence mode="wait">
        {editingUser && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              onClick={() => setEditingUser(null)} 
              className="absolute inset-0 bg-black" 
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 30 }} 
              animate={{ scale: 1, opacity: 1, y: 0 }} 
              exit={{ scale: 0.9, opacity: 0, y: 30 }} 
              className="glass-card p-12 rounded-[3.5rem] w-full max-w-md shadow-2xl border-white/10 relative z-10"
            >
              <div className="flex items-center justify-between mb-10">
                <h3 className="text-3xl font-black text-white italic tracking-tighter uppercase">Calibrate Node</h3>
                <button onClick={() => setEditingUser(null)} className="text-slate-500 hover:text-white transition-colors p-3 bg-white/5 rounded-2xl"><CloseIcon className="w-5 h-5" /></button>
              </div>
              <div className="space-y-8">
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Identity Identifier</label>
                  <input type="text" value={editName} onChange={(e) => setEditName(e.target.value)} className="w-full p-6 bg-white/5 border border-white/10 rounded-3xl text-white font-black italic outline-none focus:border-blue-500 transition-all text-xl" />
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Comm-Link Protocol</label>
                  <input type="text" value={editWhatsapp} onChange={(e) => setEditWhatsapp(e.target.value)} className="w-full p-6 bg-white/5 border border-white/10 rounded-3xl text-white font-mono text-sm outline-none focus:border-blue-500 transition-all" />
                </div>
                <button onClick={handleSaveEdit} className="w-full py-6 bg-white hover:bg-blue-600 text-black hover:text-white rounded-[2.5rem] font-black text-xs uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-3 group shadow-2xl shadow-blue-600/20"><Save className="w-5 h-5 group-hover:scale-125 transition-transform" /> Commit Calibration</button>
              </div>
            </motion.div>
          </div>
        )}

        {deletingUser && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setDeletingUser(null)} className="absolute inset-0 bg-black" />
            <motion.div initial={{ scale: 0.9, opacity: 0, y: 30 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.9, opacity: 0, y: 30 }} 
              className="glass-card p-12 rounded-[3.5rem] w-full max-w-sm shadow-2xl border-red-500/20 text-center relative z-10"
            >
              <div className="w-24 h-24 bg-red-500/10 rounded-[2.5rem] flex items-center justify-center mx-auto mb-10 border border-red-500/20"><Trash2 className="w-12 h-12 text-red-500" /></div>
              <h3 className="text-3xl font-black text-white tracking-tighter uppercase mb-4 italic">Purge Protocol?</h3>
              <p className="text-slate-500 text-[10px] font-bold mb-10 uppercase tracking-[0.2em] leading-relaxed italic">Purging link with <span className="text-white">{deletingUser.name}</span> will result in permanent signal loss.</p>
              <div className="flex gap-4">
                <button onClick={() => setDeletingUser(null)} className="flex-1 py-5 bg-white/5 text-slate-500 hover:text-white rounded-[2rem] font-black text-[10px] uppercase tracking-widest transition-all">Abort</button>
                <button onClick={() => { onDeleteUser(deletingUser.whatsapp); setDeletingUser(null); }} className="flex-1 py-5 bg-red-600 text-white rounded-[2rem] font-black text-[10px] uppercase tracking-widest hover:bg-red-500 transition-all shadow-2xl shadow-red-600/40">Execute Purge</button>
              </div>
            </motion.div>
          </div>
        )}

        {selectedUserSummary && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelectedUserSummary(null)} className="absolute inset-0 bg-black" />
            <motion.div initial={{ scale: 0.95, opacity: 0, x: 50 }} animate={{ scale: 1, opacity: 1, x: 0 }} exit={{ scale: 0.95, opacity: 0, x: 50 }} 
              className="glass-card p-12 rounded-[4rem] w-full max-w-lg shadow-2xl border-white/10 relative z-10 overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-80 h-80 bg-blue-600/10 blur-[120px] rounded-full -mr-40 -mt-40 pointer-events-none" />
              <div className="flex items-center justify-between mb-10 relative z-10">
                <h3 className="text-3xl font-black text-white italic tracking-tighter uppercase">Signal Intel</h3>
                <button onClick={() => setSelectedUserSummary(null)} className="text-slate-500 hover:text-white transition-colors p-3 bg-white/5 rounded-2xl"><CloseIcon className="w-7 h-7" /></button>
              </div>
              <div className="flex flex-col items-center text-center mb-12 relative z-10">
                <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-32 h-32 bg-gradient-to-br from-slate-800 to-slate-900 rounded-[3rem] flex items-center justify-center font-bold text-slate-300 border-4 border-white/5 mb-8 shadow-2xl relative">
                  {selectedUserSummary.photo ? (
                    <OptimizedImage 
                      src={selectedUserSummary.photo} 
                      alt={selectedUserSummary.name} 
                      className="w-full h-full object-cover rounded-[2.8rem]" 
                      containerClassName="w-full h-full rounded-[2.8rem]"
                      width={200}
                    />
                  ) : <span className="text-5xl font-black italic text-blue-500">{selectedUserSummary.name.charAt(0)}</span>}
                  <div className={cn("absolute -bottom-2 -right-2 w-8 h-8 rounded-full border-4 border-[#0F172A]", selectedUserSummary.status === 'active' ? "bg-green-500 shadow-[0_0_15px_rgba(34,197,94,0.5)]" : "bg-slate-700")} />
                </motion.div>
                <h4 className="text-4xl font-black text-white tracking-tighter italic mb-2 tracking-tight uppercase">{selectedUserSummary.name}</h4>
                <p className="text-blue-500 font-mono text-base font-bold tracking-tight mb-8">{selectedUserSummary.whatsapp}</p>
                <div className="flex flex-wrap justify-center gap-3">
                  {selectedUserSummary.referredBy && <div className="px-5 py-2 bg-blue-500/10 text-blue-400 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-blue-500/20 italic">Relay: {selectedUserSummary.referredBy}</div>}
                  <div className="px-5 py-2 bg-white/5 text-slate-400 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-white/10 italic">Tier: Node_Alpha</div>
                </div>
              </div>
              <div className="space-y-10 relative z-10">
                <div className="bg-white/[0.03] p-10 rounded-[3rem] border border-white/5">
                  <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-4 italic">Auxiliary Data (Bio)</p>
                  <p className="text-slate-400 text-base italic font-medium leading-relaxed">{selectedUserSummary.bio || "No auxiliary data found in current signal segment."}</p>
                </div>
                <div className="flex items-center justify-between px-6">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest italic">Signal Persistence</span>
                    <span className="text-white font-mono text-sm mt-1 font-black italic">{selectedUserSummary.lastLogin ? new Date(selectedUserSummary.lastLogin).toLocaleString() : 'SIGNAL_LOST'}</span>
                  </div>
                  <button onClick={() => { onViewProfile({ seller: selectedUserSummary.name, sellerPhoto: selectedUserSummary.photo || `https://ui-avatars.com/api/?name=${encodeURIComponent(selectedUserSummary.name)}&background=random`, sellerBio: selectedUserSummary.bio || 'N/A' }); setSelectedUserSummary(null); }} className="text-white hover:text-blue-400 transition-all text-[11px] font-black uppercase tracking-widest bg-white/5 px-8 py-4 rounded-3xl border border-white/10">Full Profile Mapping</button>
                </div>
                <button onClick={() => setSelectedUserSummary(null)} className="w-full py-6 bg-white text-black hover:bg-blue-600 hover:text-white rounded-[2.5rem] font-black text-xs uppercase tracking-[0.4em] transition-all shadow-2xl">Return to Protocol</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

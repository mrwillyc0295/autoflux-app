import React, { useState, useRef, useEffect } from 'react';
import { Search, ChevronDown } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface ComboboxProps {
  items: { value: string; label: string; category?: string }[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  label?: string;
  disabled?: boolean;
}

export const Combobox: React.FC<ComboboxProps> = ({ 
  items, 
  value, 
  onChange, 
  placeholder = "Seleccionar...",
  label,
  disabled = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (!isOpen) {
      setQuery('');
    }
  }, [isOpen]);

  const selectedItem = items.find(item => item.value === value);

  const filteredItems = items.filter(item => 
    item.label.toLowerCase().includes(query.toLowerCase()) || 
    (item.category && item.category.toLowerCase().includes(query.toLowerCase()))
  );

  return (
    <div className="space-y-1 relative" ref={wrapperRef}>
      {label && (
        <label className="text-[8px] font-bold text-slate-500 uppercase tracking-widest ml-1">
          {label}
        </label>
      )}
      <div 
        className={cn(
          "w-full h-12 px-4 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-between cursor-pointer transition-all",
          isOpen ? "ring-2 ring-blue-500/50 border-blue-500/50" : "hover:border-white/20",
          disabled && "opacity-50 cursor-not-allowed pointer-events-none"
        )}
        onClick={() => !disabled && setIsOpen(!isOpen)}
      >
        <div className="flex items-center gap-2 flex-1 overflow-hidden">
          {isOpen ? (
            <>
              <Search className="w-4 h-4 text-blue-400 shrink-0" />
              <input
                autoFocus
                className="bg-transparent border-none outline-none text-sm text-white w-full"
                placeholder="Buscar..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onClick={(e) => e.stopPropagation()}
              />
            </>
          ) : (
            <span className={cn("text-sm truncate", selectedItem ? "text-white font-medium" : "text-slate-400")}>
              {selectedItem ? selectedItem.label : placeholder}
            </span>
          )}
        </div>
        <ChevronDown className={cn("w-4 h-4 text-slate-500 transition-transform", isOpen && "rotate-180")} />
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.15 }}
            className="absolute z-50 w-full mt-2 py-2 bg-[#0F172A] border border-white/10 rounded-2xl shadow-xl shadow-black/50 overflow-hidden"
          >
            <div className="max-h-60 overflow-y-auto custom-scrollbar">
              {value && !query && (
                <div
                  className="px-4 py-3 hover:bg-white/5 cursor-pointer text-sm text-red-400 font-medium transition-colors border-b border-white/5"
                  onClick={() => { onChange(''); setIsOpen(false); }}
                >
                  Limpiar selección
                </div>
              )}
              {filteredItems.length === 0 ? (
                <div className="px-4 py-3 text-sm text-slate-500 text-center">
                  No se encontraron resultados
                </div>
              ) : (
                filteredItems.map((item) => (
                  <div
                    key={item.value}
                    className={cn(
                      "px-4 py-2.5 cursor-pointer text-sm transition-colors flex flex-col",
                      value === item.value ? "bg-blue-600/20 text-blue-400" : "text-slate-300 hover:bg-white/5 hover:text-white"
                    )}
                    onClick={() => {
                      onChange(item.value);
                      setIsOpen(false);
                    }}
                  >
                    <span className="font-medium">{item.label}</span>
                    {item.category && (
                      <span className="text-[10px] text-slate-500 uppercase">{item.category}</span>
                    )}
                  </div>
                ))
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

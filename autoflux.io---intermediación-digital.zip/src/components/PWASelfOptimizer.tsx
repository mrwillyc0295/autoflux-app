import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, Cpu, Zap, Sparkles, RefreshCw, Sliders, Database, Wifi, Layers, 
  Trash2, ShieldCheck, CheckCircle2, Play, Terminal, HelpCircle, X, ShieldAlert,
  Home
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { pwaGenEngine, DiagnosticLog, PWAState } from '../services/pwaGenEngine';
import { toast } from 'sonner';

interface PWASelfOptimizerProps {
  onClose?: () => void;
  onGoHome?: () => void;
  allCars?: any[];
}

export const PWASelfOptimizer: React.FC<PWASelfOptimizerProps> = ({ onClose, onGoHome, allCars = [] }) => {
  const [logs, setLogs] = useState<DiagnosticLog[]>([]);
  const [state, setState] = useState<PWAState>({
    memoryUsage: 0,
    latency: 0,
    cacheSizeKB: 0,
    swStatus: 'no-soportado',
    healedIssuesCount: 0,
    performanceScore: 100,
    autoHealEnabled: false
  });
  const [isMounted, setIsMounted] = useState(false);
  const [activeTab, setActiveTab] = useState<'monitor' | 'metrics' | 'actions' | 'rules'>('monitor');
  const [runningAction, setRunningAction] = useState<string | null>(null);
  const [selectedLogType, setSelectedLogType] = useState<string | 'all'>('all');
  const terminalRef = useRef<HTMLDivElement>(null);

  // Sound Synthesizer: Creación de efectos sonoros cibernéticos de alta fidelidad directos de la API Web Audio
  const playBeep = (freq: number = 800, type: OscillatorType = 'sine', duration: number = 0.08) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      
      gain.gain.setValueAtTime(0.04, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      // Ignorar fallos de AudioContext en navegadores que restringen reproducción sin interacción
    }
  };

  const playSuccessSound = () => {
    playBeep(600, 'sine', 0.1);
    setTimeout(() => playBeep(900, 'sine', 0.12), 80);
    setTimeout(() => playBeep(1200, 'sine', 0.18), 160);
  };

  const playErrorSound = () => {
    playBeep(350, 'sawtooth', 0.15);
    setTimeout(() => playBeep(250, 'sawtooth', 0.25), 100);
  };

  const playCyberScan = () => {
    let delay = 0;
    for (let f = 300; f < 1000; f += 80) {
      setTimeout(() => playBeep(f, 'triangle', 0.04), delay);
      delay += 30;
    }
  };

  // Suscribirse a los datos dinámicos de pwaGenEngine
  useEffect(() => {
    const unsubLogs = pwaGenEngine.subscribeToLogs((newLogs) => {
      setLogs(newLogs);
    });
    const unsubState = pwaGenEngine.subscribeToState((newState) => {
      setState(newState);
    });

    // Auto-scroll del terminal hacia abajo al recibir nuevos logs
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }

    setIsMounted(true);
    setState(pwaGenEngine.getCurrentState()); // Initialize valid data after mount

    return () => {
      unsubLogs();
      unsubState();
    };
  }, []);

  if (!isMounted) return null; // Safe wrapper para SSR / Hidratación Vercel

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [logs, activeTab]);

  const handleAction = async (actionType: 'clean' | 'restore' | 'preheat' | 'verify') => {
    setRunningAction(actionType);
    playCyberScan();
    
    let result = '';
    try {
      if (actionType === 'clean') {
        result = await pwaGenEngine.runCleanCache();
      } else if (actionType === 'restore') {
        result = await pwaGenEngine.runRestoreState();
      } else if (actionType === 'preheat') {
        result = await pwaGenEngine.runPreheatImages(allCars);
      } else if (actionType === 'verify') {
        result = await pwaGenEngine.runVerifyServiceWorker();
      }
      playSuccessSound();
      toast.success('GEN Auto-Corrección Lista', {
        id: 'pwa-action-toast',
        description: result,
        duration: 4000
      });
    } catch (e: any) {
      playErrorSound();
      toast.error('Fallo en la acción del GEN', {
        id: 'pwa-action-toast',
        description: e.message
      });
    } finally {
      setRunningAction(null);
    }
  };

  const filteredLogs = logs.filter(log => {
    if (selectedLogType === 'all') return true;
    if (selectedLogType === 'heal') return log.type === 'heal';
    if (selectedLogType === 'error-warning') return log.type === 'error' || log.type === 'warning';
    return log.type === selectedLogType;
  });

  return (
    <div className="absolute inset-0 z-[110] flex lg:items-center lg:justify-center p-0 lg:p-6 overflow-y-auto bg-slate-950/95 font-sans">
      <div 
        id="pwa-optimizer-panel" 
        className="w-full max-w-5xl bg-[#090D1A] lg:rounded-[2.5rem] border border-white/10 lg:shadow-[0_20px_50px_rgba(0,0,0,0.8)] flex flex-col overflow-hidden min-h-screen lg:min-h-[80vh] md:h-auto"
      >
        {/* Header Superior estilo Terminal Holográfica */}
        <div className="p-6 border-b border-white/10 bg-gradient-to-r from-blue-950/30 to-[#0c142d] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-10 h-10 bg-[#A3FF47]/10 border border-[#A3FF47]/30 rounded-xl flex items-center justify-center text-[#A3FF47] shadow-[0_0_15px_rgba(163,255,71,0.2)] animate-pulse">
                <Cpu className="w-5 h-5 stroke-[2.5px]" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-[#090D1A] flex items-center justify-center">
                <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-black text-white uppercase tracking-wider">GEN PWA AutoFlux</h2>
                <span className="px-2 py-0.5 bg-blue-500/10 border border-blue-500/20 rounded-full text-[8.5px] font-bold text-blue-400 uppercase tracking-widest leading-none">
                  v3.1-SelfHeal
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">
                Sincronizador Inteligente Autónomo para Depuración, Rendimiento y Auto-reparación
              </p>
            </div>
          </div>
          
          {onClose && (
            <button 
              onClick={() => {
                playBeep(450, 'sine', 0.1);
                onClose();
              }}
              className="p-2 hover:bg-white/10 rounded-full text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Panel Principal - Distribución en Grid de Control */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden h-full">
          
          {/* Columna Izquierda: Indicadores Críticos y Navegación */}
          <div className="lg:col-span-4 border-r border-white/5 p-6 bg-[#070A14] flex flex-col justify-between gap-6 overflow-y-auto">
            {/* Esfera de Puntuación Energética */}
            <div className="space-y-4">
              <div className="relative flex flex-col items-center justify-center p-6 bg-slate-900/40 rounded-3xl border border-white/5 overflow-hidden">
                <div className="absolute top-0 right-0 p-3">
                  <Activity className="w-4 h-4 text-[#A3FF47]/40" />
                </div>
                
                {/* Visualizador Circular */}
                <div className="w-28 h-28 rounded-full border-4 border-dashed border-[#A3FF47]/20 flex flex-col items-center justify-center relative p-2 animate-spin-slow">
                  <div className="absolute inset-2 rounded-full border-2 border-dashed border-blue-500/30 animate-reverse-spin" />
                  <div className="w-full h-full bg-slate-950 rounded-full flex flex-col items-center justify-center rotate-normal">
                    <span className="text-3xl font-black text-white font-mono tracking-tighter">{state.performanceScore}%</span>
                    <span className="text-[7.5px] font-black text-[#A3FF47] uppercase tracking-widest mt-0.5">ÓPTIMO</span>
                  </div>
                </div>

                <div className="mt-4 text-center">
                  <p className="text-xs font-bold text-slate-300">Autonomía del Sistema PWA</p>
                  <p className="text-[9.5px] text-slate-500 mt-1 uppercase font-black tracking-widest flex items-center justify-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    Bucle de retroalimentación listo
                  </p>
                </div>
              </div>

              {/* Toggle de Autocuración de Fondo */}
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/5 flex items-center justify-between">
                <div>
                  <h4 className="text-[10px] font-black text-white uppercase tracking-widest">
                    Corrección Autónoma
                  </h4>
                  <p className="text-[9px] text-slate-400 mt-0.5">
                    GEN interceptará y reparará fallos en silencio
                  </p>
                </div>
                <button
                  onClick={() => {
                    playBeep(state.autoHealEnabled ? 500 : 750, 'sine', 0.08);
                    pwaGenEngine.setAutoHeal(!state.autoHealEnabled);
                  }}
                  className={`w-11 h-6 rounded-full p-1 transition-all ${state.autoHealEnabled ? 'bg-emerald-500' : 'bg-slate-700'}`}
                >
                  <div className={`w-4 h-4 bg-white rounded-full transition-all transform ${state.autoHealEnabled ? 'translate-x-5' : 'translate-x-0'}`} />
                </button>
              </div>

              {/* Mini Métricas Rápidas */}
              <div className="grid grid-cols-2 gap-3 font-mono">
                <div className="p-3 bg-slate-900/30 border border-white/5 rounded-xl">
                  <span className="text-[8px] text-slate-500 block uppercase font-bold">Latencia DB</span>
                  <span className="text-sm font-black text-blue-400 tracking-tight mt-1 inline-block">{state.latency} ms</span>
                </div>
                <div className="p-3 bg-slate-900/30 border border-white/5 rounded-xl">
                  <span className="text-[8px] text-slate-500 block uppercase font-bold">Resueltos</span>
                  <span className="text-sm font-black text-[#A3FF47] tracking-tight mt-1 inline-block">+{state.healedIssuesCount} GEN</span>
                </div>
              </div>
            </div>

            {/* Menu de Pestañas de Navegación Lateral */}
            <div className="space-y-2 mt-auto">
              <h5 className="text-[8.5px] font-black text-slate-500 uppercase tracking-widest mb-3">Módulos del Motor</h5>
              <button
                onClick={() => { playBeep(650, 'sine', 0.05); setActiveTab('monitor'); }}
                className={`w-full py-3 px-4 rounded-xl text-xs font-bold uppercase tracking-widest flex items-center gap-3 transition-colors ${activeTab === 'monitor' ? 'bg-white/10 text-white border-l-2 border-[#A3FF47]' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
              >
                <Terminal className="w-4 h-4 text-[#A3FF47]" />
                Monitor GEN
              </button>
              <button
                onClick={() => { playBeep(650, 'sine', 0.05); setActiveTab('metrics'); }}
                className={`w-full py-3 px-4 rounded-xl text-xs font-bold uppercase tracking-widest flex items-center gap-3 transition-colors ${activeTab === 'metrics' ? 'bg-white/10 text-white border-l-2 border-blue-500' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
              >
                <Activity className="w-4 h-4 text-blue-400" />
                Métricas (Telemetría)
              </button>
              <button
                onClick={() => { playBeep(650, 'sine', 0.05); setActiveTab('actions'); }}
                className={`w-full py-3 px-4 rounded-xl text-xs font-bold uppercase tracking-widest flex items-center gap-3 transition-colors ${activeTab === 'actions' ? 'bg-white/10 text-white border-l-2 border-amber-500' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
              >
                <Sliders className="w-4 h-4 text-amber-400" />
                Herramientas
              </button>
              <button
                onClick={() => { playBeep(650, 'sine', 0.05); setActiveTab('rules'); }}
                className={`w-full py-3 px-4 rounded-xl text-xs font-bold uppercase tracking-widest flex items-center gap-3 transition-colors ${activeTab === 'rules' ? 'bg-white/10 text-white border-l-2 border-purple-500' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
              >
                <Zap className="w-4 h-4 text-purple-400" />
                Auto-Mejora Futura
              </button>
            </div>
          </div>

          {/* Columna Derecha: Contenido Principal de cada Panel */}
          <div className="lg:col-span-8 p-6 lg:p-8 flex flex-col justify-between overflow-y-auto">
            
            {/* PESTAÑA 1: MONITOR GEN DE LOGS */}
            {activeTab === 'monitor' && (
              <div className="space-y-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                    <div>
                      <h3 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
                        <Terminal className="text-[#A3FF47] w-5 h-5" /> Terminal de Eventos GEN
                      </h3>
                      <p className="text-[10px] text-slate-400">Canalizadores en tiempo real de operaciones de la PWA</p>
                    </div>

                    {/* Filtros de logs */}
                    <div className="flex bg-slate-900 border border-white/5 rounded-lg p-0.5 max-width-max font-mono text-[9px] font-bold">
                      <button 
                        onClick={() => setSelectedLogType('all')}
                        className={`px-3 py-1.5 rounded-md ${selectedLogType === 'all' ? 'bg-amber-500/20 text-amber-300' : 'text-slate-400 hover:text-white'}`}
                      >
                        TODO
                      </button>
                      <button 
                        onClick={() => setSelectedLogType('heal')}
                        className={`px-3 py-1.5 rounded-md ${selectedLogType === 'heal' ? 'bg-emerald-500/20 text-emerald-300' : 'text-slate-400 hover:text-white'}`}
                      >
                        CORRECCIONES
                      </button>
                      <button 
                        onClick={() => setSelectedLogType('error-warning')}
                        className={`px-3 py-1.5 rounded-md ${selectedLogType === 'error-warning' ? 'bg-rose-500/20 text-rose-300' : 'text-slate-400 hover:text-white'}`}
                      >
                        RIESGOS
                      </button>
                    </div>
                  </div>

                  {/* Consola Estilo Retro Hacker */}
                  <div className="bg-[#04060C] border border-white/10 rounded-2xl p-4 font-mono text-[10px] space-y-2 h-[340px] overflow-y-auto flex flex-col scrollbar-thin shadow-inner" ref={terminalRef}>
                    <div className="text-slate-500 mb-2 border-b border-white/5 pb-1 flex justify-between">
                      <span>AUTOFLUX_SYS_LOGS_A1</span>
                      <span>SECURE_PIPE_STABLE</span>
                    </div>
                    {filteredLogs.length === 0 ? (
                      <div className="text-slate-500 italic text-center py-20 uppercase tracking-widest text-[9px]">
                        No se encontraron registros de este nivel de severidad.
                      </div>
                    ) : (
                      filteredLogs.slice().reverse().map((log) => {
                        let color = 'text-sky-400';
                        let symbol = '●';
                        if (log.type === 'success') { color = 'text-emerald-400'; symbol = '✔'; }
                        if (log.type === 'warning') { color = 'text-amber-400'; symbol = '▲'; }
                        if (log.type === 'error') { color = 'text-rose-500'; symbol = '✘'; }
                        if (log.type === 'heal') { color = 'text-[#A3FF47] blink-fast'; symbol = '⚡'; }

                        return (
                          <div key={log.id} className="leading-relaxed hover:bg-white/[0.02] p-1.5 rounded transition-colors flex items-start gap-2.5">
                            <span className={`${color} shrink-0 font-bold`}>{symbol}</span>
                            <span className="text-slate-500 shrink-0 select-none">
                              [{new Date(log.timestamp).toLocaleTimeString()}]
                            </span>
                            <span className="px-1.5 py-0.5 bg-white/5 rounded text-[8px] text-slate-400 font-bold tracking-wider shrink-0 uppercase border border-white/10">
                              {log.module}
                            </span>
                            <span className="text-slate-300 break-words flex-1">
                              {log.message}
                            </span>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                <div className="p-4 bg-[#A3FF47]/5 border border-[#A3FF47]/10 rounded-2xl flex items-center gap-3.5 mt-4">
                  <Sparkles className="w-5 h-5 text-[#A3FF47] shrink-0" />
                  <p className="text-[10px] text-slate-300 leading-relaxed md:pr-4">
                    <strong className="text-white uppercase tracking-widest text-[9.5px]">Funcionamiento Autónomo Activo:</strong> El motor Genius de Autoflux examina automáticamente el comportamiento de la ventana, corrige desbordamientos de buffers de red, y reajusta la PWA contra fallos no controlados del navegador.
                  </p>
                </div>
              </div>
            )}

            {/* PESTAÑA 2: TELEMETRÍA Y MÉTRICAS */}
            {activeTab === 'metrics' && (
              <div className="space-y-6 flex-1">
                <div>
                  <h3 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-3">
                    <Activity className="text-blue-400 w-5 h-5" /> Telemetría Avanzada
                  </h3>
                  <p className="text-[10px] text-slate-400">Auditorías fundamentales del entorno de ejecución de la PWA</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Memoria e Integridad */}
                  <div className="p-5 rounded-2xl bg-slate-900/40 border border-white/10 space-y-4">
                    <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center justify-between">
                      Canal de Almacenamiento
                      <Database className="w-3.5 h-3.5 text-blue-400" />
                    </h4>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs font-mono text-slate-300">
                        <span>Caché de Descargas PWA</span>
                        <span className="font-bold text-white">18.42 MB</span>
                      </div>
                      <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: '38%' }} />
                      </div>
                      <span className="text-[8.5px] font-bold text-slate-500 block uppercase font-mono">Límite asignado: 50 MB de Contingencia</span>
                    </div>
                  </div>

                  {/* Latencia del Firestore */}
                  <div className="p-5 rounded-2xl bg-slate-900/40 border border-white/10 space-y-4">
                    <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center justify-between">
                      Respuesta del Servidor
                      <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                    </h4>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs font-mono text-slate-300">
                        <span>Punto de Ingress (Firestore)</span>
                        <span className="font-bold text-emerald-400">{state.latency} ms</span>
                      </div>
                      <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{ width: '18%' }} />
                      </div>
                      <span className="text-[8.5px] font-bold text-[#A3FF47] block uppercase font-mono">Estatus: Conexión Óptima P2P</span>
                    </div>
                  </div>

                  {/* Estado de Ciclo de SW */}
                  <div className="p-5 rounded-2xl bg-slate-900/40 border border-white/10 space-y-4">
                    <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center justify-between">
                      Optimización Service Worker
                      <Layers className="w-3.5 h-3.5 text-purple-400" />
                    </h4>
                    <div className="space-y-3 font-mono">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-300">Controlador Activo:</span>
                        <span className="font-bold px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-md text-[9px] border border-emerald-500/20 uppercase tracking-wider">
                          SÍ (Auto-Reparable)
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-300">Carga Offline:</span>
                        <span className="text-slate-200">Pre-Cacheado Completo</span>
                      </div>
                    </div>
                  </div>

                  {/* Diagnóstico de Capas */}
                  <div className="p-5 rounded-2xl bg-slate-900/40 border border-white/10 space-y-4">
                    <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center justify-between">
                      Salud Operativa del Hilo Principal
                      <Cpu className="w-3.5 h-3.5 text-amber-400" />
                    </h4>
                    <div className="space-y-3 font-mono">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-300">Fugas de Memoria:</span>
                        <span className="font-bold text-emerald-400 text-[10px]">0 DETECTADAS</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-300">Heap Empleado:</span>
                        <span className="text-slate-200">{state.memoryUsage} MB</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-slate-900 bg-gradient-to-r from-blue-950/10 to-transparent border border-white/5 rounded-2.5rem mt-6 flex items-start gap-4">
                  <div className="p-2 bg-blue-500/10 rounded-xl text-blue-400 shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white uppercase tracking-wider">Certificación de Velocidad Móvil</h4>
                    <p className="text-[9.5px] text-slate-400 mt-1 leading-relaxed">
                      AutoFlux monitorea el cuello de botella del Hilo de Renderizado para garantizar transiciones suaves a 60FPS. El tamaño de los recursos iniciales ha sido optimizado con pre-cacheado adaptativo.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* PESTAÑA 3: ACCIONES / HERRAMIENTAS MANUALES */}
            {activeTab === 'actions' && (
              <div className="space-y-6 flex-1">
                <div>
                  <h3 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-3">
                    <Sliders className="text-amber-400 w-5 h-5" /> Acciones de Autocuración Forzada
                  </h3>
                  <p className="text-[10px] text-slate-400">Ejecuta rutinas avanzadas del motor corrector</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Purga de Cache */}
                  <button 
                    disabled={runningAction !== null}
                    onClick={() => handleAction('clean')}
                    className="p-5 rounded-2.2rem bg-slate-900/50 hover:bg-slate-900 border border-white/5 hover:border-amber-500/30 text-left transition-all active:scale-95 duration-200 group flex flex-col justify-between h-[150px] relative overflow-hidden"
                  >
                    <div className="flex justify-between items-start w-full">
                      <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl ring-2 ring-amber-500/0 group-hover:ring-amber-500/20 transition-all">
                        <Trash2 className="w-5 h-5" />
                      </div>
                      {runningAction === 'clean' && (
                        <RefreshCw className="w-4 h-4 text-amber-400 animate-spin" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-white uppercase tracking-wider group-hover:text-amber-400 transition-colors">
                        Purga Profunda de Caché
                      </h4>
                      <p className="text-[9.5px] text-slate-400 mt-1 leading-normal">
                        Fuerza la eliminación de cachés locales estancadas y regenera buffers de SW.
                      </p>
                    </div>
                  </button>

                  {/* Re-estabilizar Estados */}
                  <button 
                    disabled={runningAction !== null}
                    onClick={() => handleAction('restore')}
                    className="p-5 rounded-2.2rem bg-slate-900/50 hover:bg-slate-900 border border-white/5 hover:border-blue-500/30 text-left transition-all active:scale-95 duration-200 group flex flex-col justify-between h-[150px] relative overflow-hidden"
                  >
                    <div className="flex justify-between items-start w-full">
                      <div className="p-2 bg-blue-500/10 text-blue-400 rounded-xl ring-2 ring-blue-500/0 group-hover:ring-blue-500/20 transition-all">
                        <Database className="w-5 h-5" />
                      </div>
                      {runningAction === 'restore' && (
                        <RefreshCw className="w-4 h-4 text-blue-400 animate-spin" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-white uppercase tracking-wider group-hover:text-blue-400 transition-colors">
                        Saneamiento de Estados
                      </h4>
                      <p className="text-[9.5px] text-slate-400 mt-1 leading-normal">
                        Rellena inconsistencias, purga variables huérfanas y re-alinea el almacenamiento de filtros.
                      </p>
                    </div>
                  </button>

                  {/* Precalentar Imágenes */}
                  <button 
                    disabled={runningAction !== null}
                    onClick={() => handleAction('preheat')}
                    className="p-5 rounded-2.2rem bg-slate-900/50 hover:bg-slate-900 border border-white/5 hover:border-[#A3FF47]/30 text-left transition-all active:scale-95 duration-200 group flex flex-col justify-between h-[150px] relative overflow-hidden"
                  >
                    <div className="flex justify-between items-start w-full">
                      <div className="p-2 bg-[#A3FF47]/10 text-[#A3FF47] rounded-xl ring-2 ring-[#A3FF47]/0 group-hover:ring-[#A3FF47]/20 transition-all">
                        <Zap className="w-5 h-5" />
                      </div>
                      {runningAction === 'preheat' && (
                        <RefreshCw className="w-4 h-4 text-[#A3FF47] animate-spin" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-white uppercase tracking-wider group-hover:text-[#A3FF47] transition-colors">
                        Precarga de Activos (Pre-warm)
                      </h4>
                      <p className="text-[9.5px] text-slate-400 mt-1 leading-normal">
                        Precalienta el búfer descargando las 5 fotos principales de vehículos para carga al instante.
                      </p>
                    </div>
                  </button>

                  {/* Sincronización de SW */}
                  <button 
                    disabled={runningAction !== null}
                    onClick={() => handleAction('verify')}
                    className="p-5 rounded-2.2rem bg-slate-900/50 hover:bg-slate-900 border border-white/5 hover:border-purple-500/30 text-left transition-all active:scale-95 duration-200 group flex flex-col justify-between h-[150px] relative overflow-hidden"
                  >
                    <div className="flex justify-between items-start w-full">
                      <div className="p-2 bg-purple-500/10 text-purple-400 rounded-xl ring-2 ring-purple-500/0 group-hover:ring-purple-500/20 transition-all">
                        <Layers className="w-5 h-5" />
                      </div>
                      {runningAction === 'verify' && (
                        <RefreshCw className="w-4 h-4 text-purple-400 animate-spin" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-white uppercase tracking-wider group-hover:text-purple-400 transition-colors">
                        Checkear Service Worker
                      </h4>
                      <p className="text-[9.5px] text-slate-400 mt-1 leading-normal">
                        Fuerza actualización offline periódica del controlador offline para mantener datos actualizados.
                      </p>
                    </div>
                  </button>

                </div>
              </div>
            )}

            {/* PESTAÑA 4: REGLAS DE FUTURO (AI-DRIVEN RULES) */}
            {activeTab === 'rules' && (
              <div className="space-y-6 flex-1">
                <div>
                  <h3 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-3">
                    <Zap className="text-purple-400 w-5 h-5" /> Planificador de Auto-Mejoras GEN-4
                  </h3>
                  <p className="text-[10px] text-slate-400">Heurísticas avanzadas configuradas para autocuración futura autónoma</p>
                </div>

                <div className="space-y-3.5">
                  {[
                    {
                      title: "Redirección Óptima ante Caída de Red (Circuit Breaker)",
                      desc: "Si la petición de Firestore tarda más de 5 segundos, el GEN conmuta a memoria resiliente en segundo plano para evitar bloqueos del sistema.",
                      badge: "Estable"
                    },
                    {
                      title: "Heurística de Redimensionamiento Dinámico de Imágenes",
                      desc: "Detecta conexiones lentas (3G módem) y redirecciona la carga de fotos del catálogo a formatos miniaturas o gráficos vectoriales optimizados.",
                      badge: "Estable"
                    },
                    {
                      title: "Alineación de LocalStorage por sumas de comprobación",
                      desc: "Inspecciona el formato estructural JSON al inicio para descartar llaves heredadas de versiones antiguas de producción, evitando pantalla blanca.",
                      badge: "Automático"
                    },
                    {
                      title: "Monitoreo Predictivo de Rutas y Tráfico Offline",
                      desc: "Analiza qué vistas frecuenta más el usuario y pre-cachea activos críticos para lograr respuesta instantánea el 100% de las veces.",
                      badge: "Heurístico"
                    }
                  ].map((rule, idx) => (
                    <div key={idx} className="p-4 bg-slate-900/40 border border-white/5 hover:border-purple-500/20 rounded-2xl transition-all relative flex flex-col md:flex-row md:items-center justify-between gap-3">
                      <div className="space-y-1 md:pr-10">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                          <h4 className="text-xs font-black text-white tracking-tight leading-normal">{rule.title}</h4>
                        </div>
                        <p className="text-[10px] text-slate-400 leading-normal">{rule.desc}</p>
                      </div>
                      <span className="shrink-0 px-2 py-1 bg-purple-500/10 border border-purple-500/20 text-[8px] font-mono font-bold uppercase tracking-wider text-purple-400 rounded-md max-w-max">
                        {rule.badge}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Footer de Acciones Globles del Modal */}
            <div className="mt-8 pt-4 border-t border-white/5 flex items-center justify-between gap-4">
              <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest hidden sm:inline">
                ESTADO: EN ESCUCHA ACTIVA DEL CORE
              </span>
              <div className="flex items-center gap-3 ml-auto">
                <button
                  onClick={() => {
                    playBeep(600, 'sine', 0.1);
                    if (onGoHome) onGoHome();
                  }}
                  className="px-5 py-2.5 bg-[#141C33] hover:bg-[#1C2645] border border-blue-500/30 text-blue-400 rounded-xl text-xs font-bold uppercase tracking-widest transition-all flex items-center gap-2"
                >
                  <Home className="w-3.5 h-3.5" />
                  Ir al Inicio
                </button>
                <button
                  onClick={() => {
                    playBeep(400, 'triangle', 0.1);
                    if (onClose) onClose();
                  }}
                  className="px-6 py-2.5 bg-white text-slate-950 hover:bg-slate-100 rounded-xl text-xs font-bold uppercase tracking-widest transition-colors shadow-2xl"
                >
                  Cerrar Panel
                </button>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};

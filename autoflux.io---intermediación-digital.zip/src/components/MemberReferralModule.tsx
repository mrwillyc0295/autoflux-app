import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  Wallet, 
  Share2, 
  ArrowRight, 
  TrendingUp, 
  ShieldCheck, 
  Zap, 
  DollarSign, 
  QrCode,
  Copy,
  CheckCircle2,
  Lock,
  ChevronRight,
  Target,
  MessageCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '../lib/utils';

interface MemberReferralModuleProps {
  userProfile: any;
  rankData: {
    user_rank: {
      current_level: string;
      commission_rate: number;
      sales_to_next_level: number;
    };
    growth_projection: {
      potential_earnings_next_level: number;
      motivational_hook: string;
    };
  };
  shareStrategy: {
    recommended_car_to_share: string;
    custom_message_whatsapp: string;
    estimated_earnings_on_sale: number;
  };
  wallet: {
    available_balance: number;
    pending_commissions: number;
    total_withdrawn: number;
  };
}

export const MemberReferralModule: React.FC<MemberReferralModuleProps> = ({ 
  userProfile, 
  rankData, 
  shareStrategy, 
  wallet 
}) => {
  const [activeTab, setActiveTab] = useState<'ranks' | 'wallet' | 'share'>('ranks');
  const [isWithdrawing, setIsWithdrawing] = useState(false);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Enlace Copiado", {
      description: "Compártelo en tus redes para empezar a ganar."
    });
  };

  const shareOnWhatsApp = () => {
    const message = encodeURIComponent(shareStrategy.custom_message_whatsapp + "\n\nMira más aquí: https://autoflux.io/ref/" + userProfile.uid);
    window.open(`https://wa.me/?text=${message}`, '_blank');
  };

  const handleWithdrawal = () => {
    if (wallet.available_balance < 50) {
      toast.error("Monto mínimo de retiro: $50");
      return;
    }
    setIsWithdrawing(true);
    setTimeout(() => {
      setIsWithdrawing(false);
      toast.success("Solicitud Enviada", {
        description: "Nuestro 'Digital Treasurer' verificará la operación en las próximas 24h."
      });
    }, 2000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Navigation Tabs */}
      <div className="flex bg-[#0B0F1A]/80 backdrop-blur-xl p-1.5 rounded-[2rem] border border-white/5 mx-auto w-fit">
        {[
          { id: 'ranks', label: 'Estatus Elite', icon: Trophy },
          { id: 'share', label: 'Viral Engine', icon: Share2 },
          { id: 'wallet', label: 'Digital Treasurer', icon: Wallet },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "px-6 py-3 rounded-full flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-all",
              activeTab === tab.id 
                ? "bg-blue-600 text-white shadow-xl shadow-blue-600/20" 
                : "text-slate-500 hover:text-white"
            )}
          >
            <tab.icon className="w-4 h-4" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {/* Ranks & Growth */}
        {activeTab === 'ranks' && (
          <motion.div
            key="ranks"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="glass-card p-8 rounded-[2.5rem] border-blue-500/20 bg-gradient-to-br from-blue-600/5 to-transparent relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                  <Trophy className="w-40 h-40" />
                </div>
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-blue-600/20 rounded-xl flex items-center justify-center">
                      <ShieldCheck className="w-6 h-6 text-blue-500" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Rango Actual</p>
                      <h4 className="text-xl font-black text-white italic tracking-tighter uppercase">{rankData.user_rank.current_level}</h4>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex justify-between items-end">
                      <span className="text-3xl font-black text-white italic">{rankData.user_rank.commission_rate}%</span>
                      <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest bg-blue-500/10 px-2 py-0.5 rounded-full">Comisión de Trading</span>
                    </div>
                    <div className="bg-white/5 h-2 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: '65%' }}
                        className="bg-blue-600 h-full shadow-[0_0_10px_rgba(37,99,235,0.5)]"
                      />
                    </div>
                    <p className="text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      Faltan <span className="text-white">{rankData.user_rank.sales_to_next_level} ventas</span> para el próximo nivel
                    </p>
                  </div>
                </div>
              </div>

              <div className="glass-card p-8 rounded-[2.5rem] border-amber-500/20 bg-amber-500/5">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-amber-500/20 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-amber-500" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-white italic tracking-tight uppercase">CRECIMIENTO ELITE</h4>
                  </div>
                </div>
                <div className="space-y-6">
                  <div className="p-4 bg-black/20 rounded-2xl border border-white/5">
                    <p className="text-xs text-slate-300 italic leading-relaxed">
                      "{rankData.growth_projection.motivational_hook}"
                    </p>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-white/5 rounded-2xl">
                    <div>
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Potencial Ganancia Siguiente Nivel</p>
                      <p className="text-xl font-black text-white italic">${rankData.growth_projection.potential_earnings_next_level.toLocaleString()}+</p>
                    </div>
                    <ArrowRight className="w-5 h-5 text-amber-500 animate-pulse" />
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { name: 'Novato', sales: '0-5', rate: '1%', color: 'slate' },
                { name: 'Influencer', sales: '6-15', rate: '1.5%', color: 'blue' },
                { name: 'Socio Pro', sales: '16-30', rate: '2%', color: 'indigo' },
                { name: 'Ambassador', sales: '31+', rate: '3%', color: 'amber' },
              ].map((rank, i) => (
                <div key={i} className={cn(
                  "p-4 rounded-2xl border flex flex-col items-center text-center gap-1",
                  rankData.user_rank.current_level.toLowerCase().includes(rank.name.toLowerCase())
                    ? "bg-blue-600/10 border-blue-500/30"
                    : "bg-white/5 border-white/5 opacity-40 grayscale"
                )}>
                  <p className="text-[10px] font-black uppercase text-white">{rank.name}</p>
                  <p className="text-[9px] font-bold text-slate-500 uppercase">{rank.sales} Ventas</p>
                  <p className="text-xs font-black text-blue-400 mt-2">{rank.rate}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Share & Viral Engine */}
        {activeTab === 'share' && (
          <motion.div
            key="share"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="glass-card p-10 rounded-[2.5rem] border-[#A3FF47]/20 bg-gradient-to-br from-[#A3FF47]/5 to-transparent text-center">
              <div className="w-16 h-16 bg-[#A3FF47]/20 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-[#A3FF47]/10">
                <Zap className="w-8 h-8 text-[#A3FF47]" />
              </div>
              <h3 className="text-3xl font-black text-white italic tracking-tighter uppercase mb-4">Viral <span className="text-[#A3FF47]">Engine</span></h3>
              <p className="text-slate-400 text-sm max-w-md mx-auto mb-8 font-medium italic">
                Comparte este activo de alta liquidez y gana hasta <span className="text-white font-bold">${shareStrategy.estimated_earnings_on_sale.toLocaleString()}</span> por venta.
              </p>

              <div className="bg-[#0B0F1A] p-8 rounded-3xl border border-white/5 space-y-6 max-w-xl mx-auto">
                <div className="flex items-center gap-4 text-left">
                  <div className="w-12 h-12 bg-white/5 rounded-xl border border-white/10 shrink-0 flex items-center justify-center">
                    <Target className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Activo Recomendado</p>
                    <p className="text-lg font-black text-white italic uppercase">{shareStrategy.recommended_car_to_share}</p>
                  </div>
                </div>

                <div className="bg-white/5 p-5 rounded-2xl text-left border border-white/5">
                  <div className="flex justify-between items-center mb-3">
                    <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Mensaje de Social Trading</p>
                    <button 
                      onClick={() => copyToClipboard(shareStrategy.custom_message_whatsapp)}
                      className="text-[#A3FF47] hover:scale-110 transition-transform"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-xs text-slate-300 italic leading-relaxed line-clamp-3">
                    "{shareStrategy.custom_message_whatsapp}"
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <button 
                    onClick={shareOnWhatsApp}
                    className="flex-1 py-5 bg-[#25D366] text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 hover:scale-105 active:scale-95 transition-all shadow-xl shadow-[#25D366]/20"
                  >
                    <MessageCircle className="w-5 h-5" />
                    <span>Compartir en WhatsApp</span>
                  </button>
                  <button 
                    onClick={() => copyToClipboard("https://autoflux.io/ref/" + userProfile.uid)}
                    className="py-5 px-8 bg-white/5 border border-white/10 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-white/10 transition-all"
                  >
                    <QrCode className="w-5 h-5 opacity-50" />
                    <span>Mi Enlace de Socio</span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Wallet & Digital Treasurer */}
        {activeTab === 'wallet' && (
          <motion.div
            key="wallet"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="glass-card p-6 rounded-3xl border-white/5 flex flex-col gap-1">
                <div className="w-10 h-10 bg-green-500/10 rounded-xl flex items-center justify-center mb-3">
                  <DollarSign className="w-6 h-6 text-green-500" />
                </div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Saldo Disponible</p>
                <div className="flex items-end gap-2">
                  <p className="text-3xl font-black text-white italic tracking-tighter">${wallet.available_balance.toLocaleString()}</p>
                </div>
              </div>

              <div className="glass-card p-6 rounded-3xl border-white/5 flex flex-col gap-1">
                <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center mb-3">
                  <TrendingUp className="w-6 h-6 text-blue-500" />
                </div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Comisiones Pendientes</p>
                <p className="text-3xl font-black text-slate-400 italic tracking-tighter">${wallet.pending_commissions.toLocaleString()}</p>
              </div>

              <div className="glass-card p-6 rounded-3xl border-white/5 flex flex-col gap-1">
                <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center mb-3">
                  <CheckCircle2 className="w-6 h-6 text-slate-400" />
                </div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Total Retirado</p>
                <p className="text-3xl font-black text-slate-600 italic tracking-tighter">${wallet.total_withdrawn.toLocaleString()}</p>
              </div>
            </div>

            <div className="glass-card p-8 rounded-[2.5rem] border-blue-500/20 bg-blue-600/5">
              <div className="flex flex-col md:flex-row justify-between items-center gap-8">
                <div className="flex-1 space-y-2 text-center md:text-left">
                  <h4 className="text-xl font-black text-white italic tracking-tighter uppercase flex items-center gap-3 justify-center md:justify-start">
                    <Lock className="w-5 h-5 text-blue-500" />
                    Bóveda de Liquidación
                  </h4>
                  <p className="text-slate-400 text-xs font-medium">Retira tus comisiones de forma segura a Zelle, Cripto o transferencia nacional.</p>
                </div>
                <button 
                  onClick={handleWithdrawal}
                  disabled={isWithdrawing}
                  className="px-12 py-5 bg-blue-600 text-white rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] hover:scale-105 active:scale-95 transition-all shadow-xl shadow-blue-600/20 disabled:opacity-50 disabled:scale-100 flex items-center gap-3"
                >
                  {isWithdrawing ? (
                    <>Verificando Operación...</>
                  ) : (
                    <>Retirar Fondos <ChevronRight className="w-4 h-4" /></>
                  )}
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8 pt-8 border-t border-white/5">
                <div className="flex items-center gap-4 opacity-30 grayscale hover:grayscale-0 hover:opacity-100 transition-all cursor-default">
                   <div className="w-10 h-10 bg-white/5 rounded-lg border border-white/10 flex items-center justify-center text-[10px] font-black">VISA</div>
                   <div className="w-10 h-10 bg-white/5 rounded-lg border border-white/10 flex items-center justify-center text-[10px] font-black">BTC</div>
                   <div className="w-10 h-10 bg-white/5 rounded-lg border border-white/10 flex items-center justify-center text-[10px] font-black">ETH</div>
                   <div className="w-10 h-10 bg-white/5 rounded-lg border border-white/10 flex items-center justify-center text-[10px] font-black">ZELLE</div>
                </div>
                <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest text-center md:text-right italic">
                  Digital Treasurer v2.4 Node Active
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

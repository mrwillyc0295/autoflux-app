import React from 'react';
import { motion } from 'motion/react';
import { 
  ArrowLeft, 
  Settings, 
  ShieldCheck, 
  LogOut, 
  User,
  Settings2,
  Bell,
  Mail,
  Smartphone,
  Cpu,
  Home
} from 'lucide-react';
import { MemberReferralModule } from './MemberReferralModule';
import { UserProfile } from '../types';

interface MemberProfileViewProps {
  user: UserProfile;
  onBack: () => void;
  onLogout: () => void;
  rankData: any;
  shareStrategy: any;
  wallet: any;
  onOpenOptimizer: () => void;
  onGoHome: () => void;
}

export const MemberProfileView: React.FC<MemberProfileViewProps> = ({ 
  user, 
  onBack, 
  onLogout,
  rankData,
  shareStrategy,
  wallet,
  onOpenOptimizer,
  onGoHome
}) => {
  return (
    <div className="min-h-screen bg-[#0B0F1A] text-white pb-20">
      {/* Header Profile */}
      <div className="relative h-64 overflow-hidden border-b border-white/5">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-600/20 to-transparent" />
        <div className="absolute inset-0 bg-[#0B0F1A]" />
        
        <div className="max-w-4xl mx-auto px-6 pt-12 flex flex-col md:flex-row items-center gap-8 relative z-10">
          <button 
            onClick={onBack}
            className="absolute top-4 left-4 p-3 bg-white/5 rounded-full hover:bg-white/10 transition-all border border-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="relative">
            <div className="w-32 h-32 rounded-3xl bg-blue-600/20 border-2 border-blue-500/30 flex items-center justify-center overflow-hidden shadow-2xl">
              {user.photo ? (
                <img src={user.photo} alt={user.name} className="w-full h-full object-cover" />
              ) : (
                <User className="w-12 h-12 text-blue-500" />
              )}
            </div>
            <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-blue-600 rounded-2xl border-4 border-[#0B0F1A] flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
          </div>

          <div className="text-center md:text-left flex-1">
            <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-4 mb-2">
              <h1 className="text-4xl font-black italic tracking-tighter uppercase">{user.name}</h1>
              <span className="px-3 py-1 bg-blue-600 rounded-full text-[10px] font-black uppercase tracking-widest w-fit mx-auto md:mx-0">
                Socio Elite
              </span>
            </div>
            <p className="text-slate-400 text-sm font-medium italic mb-6 max-w-md">
              {user.bio || "Operador estratégico en el ecosistema AutoFlux. Especialista en la Isla de Margarita."}
            </p>
            
            <div className="flex flex-wrap justify-center md:justify-start gap-4">
              <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-xl border border-white/5">
                <Mail className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-bold">{user.email}</span>
              </div>
              <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-xl border border-white/5">
                <Smartphone className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-bold">{user.whatsapp || "Sin contacto"}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-4xl mx-auto px-6 -mt-10 relative z-20 space-y-12">
        {/* Referral & Economy Module */}
        <MemberReferralModule 
          userProfile={user}
          rankData={rankData}
          shareStrategy={shareStrategy}
          wallet={wallet}
        />

        {/* Profile Settings */}
        <div className="glass-card p-10 rounded-[2.5rem] border-white/5 bg-white/2 my-12">
           <div className="flex items-center gap-4 mb-10">
              <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center">
                <Settings2 className="w-6 h-6 text-slate-400" />
              </div>
              <div>
                <h3 className="text-xl font-black text-white italic tracking-tighter uppercase leading-none">Security Hardware</h3>
                <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest mt-1">Configuración y Seguridad de Cuenta</p>
              </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <button className="flex items-center justify-between p-6 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all group">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-blue-600/10 rounded-xl group-hover:bg-blue-600/20 transition-colors">
                    <Bell className="w-5 h-5 text-blue-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-bold text-white">Notificaciones de Leads</p>
                    <p className="text-[10px] text-slate-500 uppercase font-black">Activar alertas en tiempo real</p>
                  </div>
                </div>
                <div className="w-12 h-6 bg-blue-600 rounded-full relative">
                  <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full" />
                </div>
              </button>

              <button className="flex items-center justify-between p-6 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all group">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-amber-600/10 rounded-xl group-hover:bg-amber-600/20 transition-colors">
                    <ShieldCheck className="w-5 h-5 text-amber-500" />
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-bold text-white">Verificación Biométrica</p>
                    <p className="text-[10px] text-slate-500 uppercase font-black">Cifrado de grado militar</p>
                  </div>
                </div>
                <Settings className="w-5 h-5 text-slate-600" />
              </button>
           </div>

           <button 
            onClick={onLogout}
            className="w-full mt-10 py-5 bg-red-600/10 border border-red-500/20 text-red-500 rounded-2xl font-black text-xs uppercase tracking-[0.2em] hover:bg-red-600 hover:text-white transition-all flex items-center justify-center gap-3 active:scale-95 shadow-xl shadow-red-900/10"
           >
            <LogOut className="w-5 h-5" />
            Termination Protocol (Cerrar Sesión)
           </button>
        </div>
               {/* PWA Self-Healer and Optimizer Section */}
         <div className="glass-card p-8 rounded-3xl border-white/10 bg-slate-900/60 my-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-48 h-48 bg-[#A3FF47]/5 rounded-full blur-3xl -mr-24 -mt-24 pointer-events-none" />
            <div className="flex flex-col sm:flex-row items-center justify-between gap-6 relative z-10 w-full">
              <div className="flex items-center gap-4 text-center sm:text-left">
                <div className="w-12 h-12 bg-[#A3FF47]/10 border border-[#A3FF47]/20 rounded-2xl flex items-center justify-center relative shrink-0">
                  <span className="absolute top-1.5 right-1.5 flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#A3FF47] opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#A3FF47]"></span>
                  </span>
                  <Cpu className="w-6 h-6 text-[#A3FF47]" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-white italic tracking-tighter uppercase leading-none text-left">Motor de Autocuración PWA</h3>
                  <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest mt-1 text-left">Manejo Autónomo de Caché y Rendimiento (GEN Engine)</p>
                </div>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={onGoHome}
                  className="px-5 py-4 rounded-xl bg-[#141C33] hover:bg-[#1C2645] border border-blue-500/30 hover:border-blue-500/50 text-white flex items-center justify-center gap-2 text-xs font-black uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(59,130,246,0.15)] group"
                >
                  <Home className="w-4 h-4 text-blue-400 group-hover:rotate-6 transition-transform" />
                  Inicio
                </button>
                <button
                  onClick={onOpenOptimizer}
                  className="px-6 py-4 rounded-xl bg-[#0E1528] hover:bg-[#131d36] border border-[#A3FF47]/30 hover:border-[#A3FF47]/70 text-white flex items-center justify-center gap-2 text-xs font-black uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(163,255,71,0.15)] group"
                >
                  <Cpu className="w-4 h-4 text-[#A3FF47] group-hover:rotate-12 transition-transform" />
                  Optimizar PWA
                </button>
              </div>
            </div>
         </div>
       </main>
    </div>
  );
};

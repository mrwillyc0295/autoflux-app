import React, { useState } from 'react';
import { toast } from 'sonner';
import { Zap, Send, Loader2, Search, ClipboardCheck } from 'lucide-react';
import { OptimizedImage } from './OptimizedImage';

export const EpicVINModule: React.FC = () => {
  const [vin, setVin] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const analyzeVehicle = async () => {
    if (vin.length < 5) {
      toast.error("Por favor ingresa un VIN o Placa.");
      return;
    }

    setLoading(true);
    try {
      // Simulation as before, will be replaced with actual webhook URL when available
      await new Promise(resolve => setTimeout(resolve, 1500));
      const data = {
        title_check: "Título Limpio ✅",
        mileage: "48,500",
        price_usa: 12500,
        price_venezuela: 17500,
        ai_summary: "El histórico de servicios es impecable. Alta demanda para este modelo en el mercado local.",
        auction_photos: [
          "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=300&q=80",
          "https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&w=300&q=80"
        ]
      };

      setResult(data);
      toast.success("Análisis completado");
    } catch (error) {
      toast.error("Error al conectar con el sistema de auditoría.");
    } finally {
      setLoading(false);
    }
  };

  const shareToWhatsApp = () => {
    toast.success("El bot de AutoFlux está generando el reporte para compartir...");
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-2xl">
      
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold text-sky-400 flex items-center gap-3">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
          </span>
          USA MARKET SYNC
        </h3>
        <OptimizedImage 
          src="https://epicvin.com/favicon.ico" 
          alt="EpicVIN" 
          className="w-6 h-6 grayscale brightness-200" 
          containerClassName="w-6 h-6"
          width={24}
        />
      </div>

      {/* Input */}
      <div className="relative mb-6">
        <input 
          type="text" 
          value={vin}
          onChange={(e) => setVin(e.target.value.toUpperCase())}
          placeholder="VIN o Placa de EE.UU." 
          className="w-full p-5 rounded-2xl border border-slate-700 bg-slate-950 text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 transition-all font-mono"
        />
        <button 
          onClick={analyzeVehicle}
          disabled={loading}
          className="absolute right-2 top-2 bottom-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold px-6 rounded-xl transition-all disabled:opacity-50"
        >
          {loading ? <Loader2 className="animate-spin w-5 h-5" /> : "AUDITAR"}
        </button>
      </div>

      {/* Results */}
      {result && (
        <div className="animate-in slide-in-from-bottom-4 duration-500">
          <div className="flex gap-4 overflow-x-auto pb-4 mb-6 snap-x">
            {result.auction_photos.map((url: string, i: number) => (
              <OptimizedImage 
                key={i} 
                src={url} 
                alt="Vehículo" 
                className="snap-center flex-none h-40 w-full md:w-80 object-cover rounded-2xl border border-slate-700" 
                containerClassName="snap-center flex-none h-40 w-full md:w-80"
                width={400}
              />
            ))}
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center">
              <p className="text-[10px] text-slate-400 uppercase tracking-widest mb-1">Historial USA</p>
              <strong className="text-emerald-400 text-sm">{result.title_check}</strong>
            </div>
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center">
              <p className="text-[10px] text-slate-400 uppercase tracking-widest mb-1">Precio Est. VZLA</p>
              <strong className="text-amber-400 text-sm">${result.price_venezuela.toLocaleString()}</strong>
            </div>
          </div>

          <div className="bg-sky-500/10 border-l-4 border-sky-400 p-4 rounded-lg mb-6">
            <p className="text-xs text-sky-100 leading-relaxed">
              <strong>💡 Veredicto Expertos:</strong> {result.ai_summary}
            </p>
          </div>

          <button 
            onClick={shareToWhatsApp}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-4 rounded-2xl cursor-pointer transition-all flex items-center justify-center gap-3"
          >
            <Send className="w-5 h-5" /> ENVIAR A CLIENTE (WHATSAPP)
          </button>
        </div>
      )}
    </div>
  );
};

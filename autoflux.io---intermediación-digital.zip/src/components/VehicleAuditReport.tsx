import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, AlertCircle, TrendingUp, TrendingDown, Minus, DollarSign, Globe, Gauge, CheckCircle2, MessageSquare, Brain } from 'lucide-react';
import { cn } from '../lib/utils';

interface AuditReportProps {
  data: {
    car_identity: {
      make_model: string;
      year: number;
      style: string;
    };
    market_intel: {
      usa_auction_avg: number;
      import_logistics_cost: number;
      final_target_vzla: number;
      market_trend: string;
    };
    expert_audit: {
      status: string;
      summary: string;
      legal_check: string;
    };
    devops_action: {
      fix_code: string | null;
      clean_cache: boolean;
    };
  };
  onClose: () => void;
}

export const VehicleAuditReport: React.FC<AuditReportProps> = ({ data, onClose }) => {
  const isCritical = data.expert_audit.status === "Rechazado" || 
                     data.expert_audit.summary.toLowerCase().includes("alto riesgo") || 
                     data.expert_audit.legal_check.toLowerCase().includes("salvage") || 
                     data.expert_audit.legal_check.toLowerCase().includes("flood");

  const getWhatsAppMessage = () => {
    return `*REPORTE DE AUDITORÍA AUTOFLUX*\n\n` +
           `🚗 *Vehículo:* ${data.car_identity.make_model} (${data.car_identity.year})\n` +
           `📊 *Estatus:* ${data.expert_audit.status}\n` +
           `💰 *Precio Final VZLA:* $${data.market_intel.final_target_vzla.toLocaleString()}\n` +
           `🛡️ *Veredicto:* ${data.expert_audit.summary}\n\n` +
           `Generado por el Cerebro Operativo AUTOFLUX.`;
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="glass-card p-10 rounded-[3rem] border-white/10 shadow-2xl max-w-4xl w-full mx-auto overflow-hidden relative"
    >
      <div className="absolute top-0 right-0 p-10 opacity-5">
        <ShieldCheck className="w-40 h-40 text-blue-500" />
      </div>

      <div className="relative z-10 space-y-10">
        <div className="flex flex-col md:flex-row justify-between items-start gap-6 border-b border-white/5 pb-8">
          <div>
            <h2 className="text-3xl font-black text-white tracking-tighter mb-1">AUDITORÍA AUTOFLUX</h2>
            <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.3em]">CORTEX AUDIT ENGINE V1.0</p>
          </div>
          <div className={cn(
            "px-6 py-3 rounded-2xl border flex items-center gap-3",
            data.expert_audit.status === "Aprobado" ? "bg-green-500/10 border-green-500/30 text-green-400" : 
            data.expert_audit.status === "Advertencia" ? "bg-amber-500/10 border-amber-500/30 text-amber-400" :
            "bg-red-500/10 border-red-500/30 text-red-400"
          )}>
            {data.expert_audit.status === "Aprobado" ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
            <span className="text-xs font-black uppercase tracking-widest">
              {data.expert_audit.status.toUpperCase()}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1 space-y-6">
            <div className="bg-white/5 p-6 rounded-3xl border border-white/5">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Identidad del Vehículo</p>
              <h3 className="text-2xl font-black text-white mb-2">{data.car_identity.make_model}</h3>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-blue-600 text-white rounded-full text-[9px] font-bold uppercase">{data.car_identity.year}</span>
                <span className="px-3 py-1 bg-white/10 text-slate-400 rounded-full text-[9px] font-bold uppercase border border-white/10">{data.car_identity.style}</span>
              </div>
            </div>

            <div className="bg-white/5 p-6 rounded-3xl border border-white/5">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Estatus Legal (USA)</p>
              <div className="flex items-center gap-3">
                <Globe className="w-5 h-5 text-blue-400" />
                <p className={cn("text-sm font-bold", isCritical ? "text-red-400" : "text-white")}>{data.expert_audit.legal_check}</p>
              </div>
            </div>
          </div>

          <div className="md:col-span-2 space-y-6">
            <div className="bg-blue-600/10 p-8 rounded-[2.5rem] border border-blue-500/20">
              <div className="flex justify-between items-center mb-8">
                <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Análisis de Mercado (VZLA)</p>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Tendencia:</span>
                  {data.market_intel.market_trend.includes('Alta') ? <TrendingUp className="w-4 h-4 text-green-400" /> : 
                   data.market_intel.market_trend.includes('Baja') ? <TrendingDown className="w-4 h-4 text-red-400" /> : 
                   <Minus className="w-4 h-4 text-slate-400" />}
                  <span className="text-xs font-black text-white">{data.market_intel.market_trend}</span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-8 mb-8 border-b border-white/5 pb-8">
                <div>
                  <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Precio Subasta (USA)</p>
                  <p className="text-2xl font-black text-white">${data.market_intel.usa_auction_avg.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Logística e Impuestos</p>
                  <p className="text-2xl font-black text-white">${data.market_intel.import_logistics_cost.toLocaleString()}</p>
                </div>
              </div>

              <div>
                <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest mb-2 font-led">Precio Final Sugerido</p>
                <p className="text-5xl font-black text-white tracking-tighter animate-led-color">
                  ${data.market_intel.final_target_vzla.toLocaleString()}
                </p>
              </div>
            </div>

            <div className="glass-card p-8 rounded-[2rem] border-white/5">
              <div className="flex items-center gap-3 mb-6">
                <Brain className="w-6 h-6 text-purple-400" />
                <h4 className="text-sm font-black text-white uppercase tracking-widest">Veredicto del Panel</h4>
              </div>
              <div className="prose prose-invert prose-sm text-slate-400 leading-relaxed max-w-none">
                <p>{data.expert_audit.summary}</p>
              </div>
              
              {isCritical && (
                <div className="mt-6 p-4 bg-red-600/20 border border-red-500/50 rounded-2xl flex items-center gap-4">
                  <AlertCircle className="w-6 h-6 text-red-500" />
                  <p className="text-[10px] font-bold text-red-400 uppercase tracking-widest">ALERTA CRÍTICA: RIESGO DE SEGURIDAD O ESTATUS LEGAL COMPROMETIDO</p>
                </div>
              )}

              {data.devops_action.fix_code && (
                <div className="mt-6 p-4 bg-blue-600/10 border border-blue-500/20 rounded-2xl">
                  <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-2">💻 DevOps Fix Applied:</p>
                  <pre className="text-[10px] text-slate-300 overflow-x-auto whitespace-pre-wrap font-mono">
                    {data.devops_action.fix_code}
                  </pre>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t border-white/5">
          <button 
            onClick={() => {
              window.open(`https://wa.me/?text=${encodeURIComponent(getWhatsAppMessage())}`, '_blank');
            }}
            className="flex-1 h-14 bg-green-600 hover:bg-green-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-3 shadow-xl shadow-green-900/20"
          >
            <MessageSquare className="w-5 h-5" />
            Enviar Reporte a Cliente
          </button>
          <button 
            onClick={onClose}
            className="px-10 h-14 bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all border border-white/10"
          >
            Cerrar
          </button>
        </div>
      </div>
    </motion.div>
  );
};

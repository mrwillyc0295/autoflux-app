import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Users, MessageSquare, ArrowLeft, Send, Sparkles, Brain, TrendingUp, ShieldCheck, Zap, Globe, DollarSign, BarChart3, Rocket, Settings2, CarFront, LayoutGrid } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { GoogleGenAI } from "@google/genai";
import { cn } from '../lib/utils';
import { auditVehicle } from '../services/geminiService';
import { VehicleAuditReport } from './VehicleAuditReport';
import { Car } from '../types';

interface Expert {
  id: string;
  name: string;
  role: string;
  icon: any;
  color: string;
  description: string;
}

const EXPERTS: Expert[] = [
  { id: 'toyotero', name: 'El Toyotero', role: 'Fiabilidad y Reventa', icon: ShieldCheck, color: 'text-red-500', description: 'Experto en marcas japonesas. Evalúa la durabilidad del motor, disponibilidad de repuestos y valor de reventa en Venezuela.' },
  { id: 'truck', name: 'Truck Expert', role: 'Fuerza y Chasis', icon: Settings2, color: 'text-orange-500', description: 'Especialista en vehículos de carga y trabajo pesado. Analiza capacidad de arrastre, torque y robustez del chasis.' },
  { id: '4x4', name: '4x4 Specialist', role: 'Tracción y Suspensión', icon: Zap, color: 'text-green-500', description: 'Experto en off-road. Evalúa sistemas de doble tracción, ángulos de ataque y resistencia de la suspensión.' },
  { id: 'luxury', name: 'Luxury Tech', role: 'Electrónica y Sensores', icon: Sparkles, color: 'text-blue-400', description: 'Especialista en alta gama. Analiza sistemas de infoentretenimiento, asistencias a la conducción y sensores premium.' },
  { id: 'import', name: 'Import Scout', role: 'Historial USA', icon: Globe, color: 'text-cyan-400', description: 'Analista de historial. Revisa títulos de propiedad, accidentes reportados en USA y record de mantenimiento previo.' },
  { id: 'market', name: 'Market Hunter', role: 'Análisis de Precios', icon: DollarSign, color: 'text-emerald-400', description: 'Estratega de mercado. Compara el precio actual contra subastas en USA (Copart/IAAI) y oferta local.' },
  { id: 'city', name: 'City Advisor', role: 'Consumo Urbano', icon: MessageSquare, color: 'text-indigo-400', description: 'Especialista en movilidad urbana. Evalúa consumo de combustible, maniobrabilidad y facilidad de mantenimiento.' },
  { id: 'auditor', name: 'Gen Auditor', role: 'Coherencia Lógica', icon: Brain, color: 'text-purple-400', description: 'Súper IA de verificación. Revisa que todos los datos del vehículo sean coherentes y detecta posibles fraudes.' }
];

interface ExpertAuditionViewProps {
  onBack: () => void;
  cars: any[];
  users: any[];
}

export const ExpertAuditionView: React.FC<ExpertAuditionViewProps> = ({ onBack, cars, users }) => {
  const [query, setQuery] = useState('');
  const [responses, setResponses] = useState<{ expertId: string, text: string }[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedExperts, setSelectedExperts] = useState<string[]>(EXPERTS.map(e => e.id));
  const [selectedCarId, setSelectedCarId] = useState<string>('');
  const [auditResult, setAuditResult] = useState<any | null>(null);

  const templates = [
    { label: '🔎 Auditoría de VIN', text: 'Analiza este vehículo basándote en su historial de subasta en USA y reportes de daños.' },
    { label: '💰 Análisis de Precio VZLA', text: 'Calcula el precio final en Venezuela aplicando impuestos y logística, comparándolo con el valor de mercado actual.' },
    { label: '🛡️ Veredicto de 8 Expertos', text: 'Genera un consenso técnico entre los 8 especialistas sobre la viabilidad de compra de esta unidad.' },
    { label: '📲 WhatsApp Payload', text: 'Prepara el resumen ejecutivo listo para enviar al cliente final con todos los datos técnicos y el sello de aprobación.' }
  ];

  const handleAudition = async (customQuery?: string) => {
    const finalQuery = customQuery || query;
    const selectedCar = cars.find(c => c.id === selectedCarId);

    if (selectedCar && !customQuery) {
      setIsLoading(true);
      setAuditResult(null);
      setResponses([]);
      try {
        const result = await auditVehicle(selectedCar);
        setAuditResult(result);
      } catch (error) {
        console.error("Audit error:", error);
        alert("Error al auditar el vehículo. Intente de nuevo.");
      } finally {
        setIsLoading(false);
      }
      return;
    }

    if (!finalQuery.trim()) return;
    setIsLoading(true);
    setResponses([]);
    setAuditResult(null);

    try {
      const selectedNames = EXPERTS.filter(e => selectedExperts.includes(e.id)).map(e => `${e.name} (${e.role})`).join(', ');
      
      const inventorySummary = {
        totalCars: cars.length,
        avgPrice: cars.length > 0 ? cars.reduce((acc, car) => acc + (car.price || 0), 0) / cars.length : 0,
        makes: [...new Set(cars.map(c => c.make))],
        totalUsers: users.length,
        sellers: users.filter(u => u.role === 'seller').length
      };

      const prompt = `
        Actúa como un panel de expertos para la plataforma AutoFlux.io (un marketplace de vehículos de lujo y alta gama).
        Los expertos seleccionados para esta audición son: ${selectedNames}.
        
        CONTEXTO DEL SISTEMA ACTUAL:
        - Vehículos en inventario: ${inventorySummary.totalCars}
        - Precio promedio: $${inventorySummary.avgPrice.toLocaleString()}
        - Marcas presentes: ${inventorySummary.makes.join(', ')}
        - Usuarios registrados: ${inventorySummary.totalUsers} (${inventorySummary.sellers} son dealers/vendedores).
        
        El usuario pregunta: "${finalQuery}"
        
        Proporciona una respuesta donde CADA uno de los expertos mencionados dé su opinión crítica, técnica o estratégica basada en su personalidad y experiencia real. 
        
        INSTRUCCIÓN CRÍTICA: Cuando realices una comparación entre modelos, precios o estrategias, utiliza SIEMPRE una tabla de Markdown titulada "📊 COMPARATIVA ESTRATÉGICA" para que la información sea visualmente clara y accionable.
        
        Formato de cada experto:
        ### [Nombre del Experto]
        [Respuesta del experto con análisis profundo y específico basado en los datos del sistema]
        
        ---
      `;

      // Corregido: Usar el proxy del servidor en lugar de inicializarlo en el cliente
      const response = await fetch("/api/gemini", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "GENERATE_TEXT",
          prompt: prompt,
          model: "gemini-1.5-flash"
        })
      });

      if (!response.ok) {
        throw new Error("Fallo en el servicio de IA central");
      }

      const result = await response.json();
      const text = result.text;
      
      // Parse the response into individual expert sections
      const sections = text.split('---').map(s => s.trim()).filter(s => s.length > 0);
      const parsedResponses = sections.map(section => {
        const match = section.match(/### (.*)\n([\s\S]*)/);
        if (match) {
          const name = match[1].trim();
          const expert = EXPERTS.find(e => name.toLowerCase().includes(e.name.toLowerCase()));
          return {
            expertId: expert?.id || 'unknown',
            text: match[2].trim()
          };
        }
        return null;
      }).filter(r => r !== null) as { expertId: string, text: string }[];

      setResponses(parsedResponses);
    } catch (error: any) {
      console.error("Error in expert audition:", error);
      
      let errorMessage = "Ocurrió un error inesperado al contactar con el panel de expertos. Por favor, intenta de nuevo.";
      const rawMessage = error.message ? error.message.toLowerCase() : "";
      
      if (rawMessage.includes("api_key") || rawMessage.includes("key not valid") || rawMessage.includes("unauthenticated")) {
        errorMessage = "Error de autenticación con el servicio de IA. Verifica que tu clave de API Gemini esté configurada.";
      } else if (rawMessage.includes("quota") || rawMessage.includes("429") || rawMessage.includes("exhausted")) {
        errorMessage = "El panel de expertos está muy concurrido en este momento (Límite de cuota alcanzado). Espera unos minutos y vuelve a intentarlo.";
      } else if (rawMessage.includes("network") || rawMessage.includes("fetch") || rawMessage.includes("failed to fetch")) {
        errorMessage = "Hay un problema con la conexión a internet. Revisa tu red e intenta de nuevo para escuchar a los expertos.";
      } else if (rawMessage.includes("500") || rawMessage.includes("503")) {
        errorMessage = "Los servidores del panel están experimentando interrupciones. Por favor, inténtalo más tarde.";
      }

      alert(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleExpert = (id: string) => {
    setSelectedExperts(prev => 
      prev.includes(id) 
        ? prev.filter(expertId => expertId !== id) 
        : (prev.length < 8 ? [...prev, id] : prev)
    );
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#0B0F1A] relative scrollbar-hide py-10">
      <div className="absolute top-0 left-0 w-full h-96 bg-gradient-to-b from-blue-600/5 to-transparent pointer-events-none" />
      
      <div className="pwa-container relative z-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <button 
              onClick={onBack}
              className="group flex items-center gap-3 text-slate-500 hover:text-white transition-colors text-xs font-bold uppercase tracking-widest mb-4"
            >
              <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              Volver al Dashboard
            </button>
            <h2 className="text-4xl md:text-5xl font-extrabold text-white tracking-tighter flex items-center gap-4 font-led">
              <ShieldCheck className="w-10 h-10 text-blue-500 animate-pulse" />
              Núcleo de Auditoría
            </h2>
            <p className="text-slate-500 mt-2 text-[8px] md:text-sm font-medium uppercase tracking-[0.3em]">Cortex Engine - Venezuela Automotive Inteligencia</p>
          </div>
          
          <div className="flex items-center gap-4 bg-white/5 p-4 rounded-3xl border border-white/10 shrink-0">
            <div className="text-right">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Expertos Seleccionados</p>
              <p className="text-xl font-black text-blue-400">{selectedExperts.length} / 8</p>
            </div>
            <div className="w-12 h-12 bg-blue-600/20 rounded-2xl flex items-center justify-center">
              <Brain className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-10">
          {/* Sidebar: Expert Selection */}
          <div className="lg:col-span-1 space-y-6">
            <div className="glass-card p-6 rounded-[2rem] border-white/10">
              <h3 className="text-xs font-black text-white uppercase tracking-widest mb-6 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-orange-400" />
                Panel de Profesionales
              </h3>
              <div className="grid grid-cols-2 lg:grid-cols-1 gap-2 max-h-[400px] lg:max-h-[600px] overflow-y-auto pr-2 scrollbar-hide">
                {EXPERTS.map((expert) => (
                  <button
                    key={expert.id}
                    onClick={() => toggleExpert(expert.id)}
                    className={cn(
                      "w-full p-3 rounded-2xl border transition-all flex items-center gap-3 text-left group",
                      selectedExperts.includes(expert.id)
                        ? "bg-blue-600/20 border-blue-500/50 shadow-lg shadow-blue-900/20"
                        : "bg-white/5 border-white/5 hover:bg-white/10"
                    )}
                  >
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-110",
                      selectedExperts.includes(expert.id) ? "bg-blue-600 text-white" : "bg-white/5 text-slate-500"
                    )}>
                      <expert.icon className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <p className={cn(
                        "text-xs font-bold truncate",
                        selectedExperts.includes(expert.id) ? "text-white" : "text-slate-400"
                      )}>{expert.name}</p>
                      <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter truncate">{expert.role}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Main: Chat and Responses */}
          <div className="lg:col-span-3 space-y-8">
            <div className="glass-card p-8 rounded-[2.5rem] border-white/10 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <ShieldCheck className="w-32 h-32 text-blue-500" />
              </div>
              
              <div className="relative z-10">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-8">
                  <div>
                    <h3 className="text-2xl font-black text-white tracking-tight mb-2">Punto de Control Auditivo</h3>
                    <p className="text-slate-500 text-sm">Selecciona un vehículo del inventario para iniciar la auditoría profunda del Cortex.</p>
                  </div>
                  
                  <div className="w-full md:w-80">
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 ml-1">Vehículo a Auditar</p>
                    <select 
                      value={selectedCarId} 
                      onChange={(e) => setSelectedCarId(e.target.value)}
                      className="w-full h-14 px-4 bg-white/5 border border-white/10 rounded-2xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 appearance-none cursor-pointer"
                    >
                      <option value="" className="bg-[#0B0F1A]">--- Seleccionar Vehículo ---</option>
                      {cars.map(car => (
                        <option key={car.id} value={car.id} className="bg-[#0B0F1A]">
                          {car.make} {car.model} ({car.year}) - ${car.price.toLocaleString()}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-6">
                  {templates.map((t, i) => (
                    <button
                      key={i}
                      onClick={() => handleAudition(t.text)}
                      disabled={isLoading}
                      className="px-3 py-1.5 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-400 hover:text-white rounded-full text-[10px] font-bold transition-all"
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-1 relative">
                    <textarea 
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Ej: ¿Cómo podemos optimizar la logística de entrega de vehículos de lujo en Venezuela usando blockchain?"
                      className="w-full p-6 bg-white/5 border border-white/10 rounded-3xl text-white placeholder-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/50 min-h-[120px] resize-none"
                    />
                  </div>
                  <button 
                    onClick={() => handleAudition()}
                    disabled={isLoading || !query.trim() || selectedExperts.length === 0}
                    className="px-8 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-600 text-white rounded-3xl transition-all flex flex-col items-center justify-center gap-2 shadow-xl shadow-blue-900/20 group"
                  >
                    {isLoading ? (
                      <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <Send className="w-6 h-6 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                        <span className="text-[10px] font-black uppercase tracking-widest">Iniciar</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <AnimatePresence mode="popLayout">
                {auditResult ? (
                  <VehicleAuditReport 
                    data={auditResult} 
                    onClose={() => setAuditResult(null)} 
                  />
                ) : responses.length > 0 ? (
                  responses.map((resp, idx) => {
                    const expert = EXPERTS.find(e => e.id === resp.expertId);
                    if (!expert) return null;
                    
                    return (
                      <motion.div
                        key={expert.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        className="glass-card p-8 rounded-[2.5rem] border-white/10 shadow-xl"
                      >
                        <div className="flex items-center gap-4 mb-6">
                          <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg", expert.color.replace('text', 'bg').replace('400', '600/20').replace('500', '600/20'))}>
                            <expert.icon className={cn("w-7 h-7", expert.color)} />
                          </div>
                          <div>
                            <h4 className="text-xl font-black text-white tracking-tight">{expert.name}</h4>
                            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{expert.role}</p>
                          </div>
                        </div>
                        <div className="prose prose-invert prose-sm max-w-none text-slate-300 leading-relaxed">
                          <ReactMarkdown>{resp.text}</ReactMarkdown>
                        </div>
                      </motion.div>
                    );
                  })
                ) : (
                  <div className="text-center py-20 bg-white/5 rounded-[3rem] border border-dashed border-white/10">
                    <Users className="w-16 h-16 text-slate-700 mx-auto mb-4" />
                    <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">Selecciona tus expertos e inicia la consulta</p>
                  </div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

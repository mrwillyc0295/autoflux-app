import React, { useMemo, useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { VehicleStyle, Car } from '../types';
import { cn } from '../lib/utils';

const STYLE_META: { id: VehicleStyle; label: string; icon: string }[] = [
  { id: 'Sedans', label: 'SEDAN', icon: 'fa-car' },
  { id: 'SUVs & Crossovers', label: 'SUV', icon: 'fa-car-rear' },
  { id: 'Trucks', label: 'TRUCK', icon: 'fa-truck-pickup' },
  { id: 'Coupes', label: 'COUPE', icon: 'fa-car-side' },
  { id: 'Vans & Minivans', label: 'VAN', icon: 'fa-van-shuttle' },
  { id: 'Luxury', label: 'LUXURY', icon: 'fa-gem' },
  { id: 'Hatchbacks', label: 'CITY', icon: 'fa-car-burst' },
  { id: 'Commercial', label: 'WORK', icon: 'fa-truck' },
  { id: 'AWDs & 4WDs', label: '4x4', icon: 'fa-mountain' },
];

interface AnimatedCounterProps {
  target: number;
}

const AnimatedCounter: React.FC<AnimatedCounterProps> = ({ target }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime: number | null = null;
    const duration = 2000; // 2 seconds

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      setCount(Math.floor(progress * target));

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setCount(target);
      }
    };

    requestAnimationFrame(animate);
  }, [target]);

  return <span className="font-mono">{count}</span>;
};

interface VehicleStyleCarouselProps {
  cars: Car[];
  onSelectStyle?: (style: VehicleStyle) => void;
  selectedStyle?: VehicleStyle | null;
}

export const VehicleStyleCarousel: React.FC<VehicleStyleCarouselProps> = ({ cars, onSelectStyle, selectedStyle }) => {
  const styleCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    cars.forEach(car => {
      if (car.style) {
        counts[car.style] = (counts[car.style] || 0) + 1;
      }
    });
    return counts;
  }, [cars]);

  // Duplicamos los estilos para crear el efecto de loop infinito
  const duplicatedStyles = useMemo(() => [...STYLE_META, ...STYLE_META, ...STYLE_META], []);

  return (
    <div className="py-8 w-full overflow-hidden">
      <div className="marquee-wrapper">
        <div className="marquee-content hover:[animation-play-state:paused] transition-all">
          {duplicatedStyles.map((style, index) => {
            const count = styleCounts[style.id] || 0;
            const isActive = selectedStyle === style.id;

            return (
              <motion.div
                key={`${style.id}-${index}`}
                onClick={() => onSelectStyle?.(style.id)}
                className={cn(
                  "flex flex-col items-center justify-center flex-none w-[140px] h-[110px] cursor-pointer rounded-[1.5rem] border transition-all duration-300 relative group/item",
                  isActive 
                    ? "bg-[#DEFF9A]/10 border-[#DEFF9A] shadow-[0_0_20px_rgba(222,255,154,0.2)]" 
                    : "bg-white/5 border-white/10 hover:bg-white/10 hover:border-[#DEFF9A]/50"
                )}
              >
                <i className={cn(
                  `fa-solid ${style.icon} text-xl mb-2 transition-colors`,
                  isActive ? "text-[#DEFF9A]" : "text-slate-500 group-hover/item:text-slate-300"
                )} />
                
                <span className={cn(
                  "text-[10px] font-black uppercase tracking-[0.2em] transition-colors",
                  isActive ? "text-[#DEFF9A]" : "text-slate-500 group-hover/item:text-slate-300"
                )}>
                  {style.label}
                </span>

                <div className={cn(
                  "mt-2 px-3 py-1 rounded-full text-[10px] font-bold font-mono transition-all",
                  isActive 
                    ? "bg-[#DEFF9A] text-black shadow-[0_0_10px_rgba(222,255,154,0.4)]" 
                    : "bg-white/5 text-slate-500 group-hover/item:text-slate-300"
                )}>
                  <AnimatedCounter target={count} />
                </div>

                {isActive && (
                  <motion.div 
                    layoutId="active-glow-style"
                    className="absolute inset-0 bg-[#DEFF9A]/5 rounded-[1.5rem] blur-xl -z-10"
                  />
                )}
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

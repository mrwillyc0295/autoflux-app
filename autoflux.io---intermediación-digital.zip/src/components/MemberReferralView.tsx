import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Share2, Copy, Check, Users, DollarSign, ArrowLeft, ExternalLink, QrCode, Plus } from 'lucide-react';
import { UserProfile } from '../types';
import { toast } from 'sonner';
import { collection, addDoc, query, where, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { db } from '../services/firebase';

interface MemberReferralViewProps {
  user: UserProfile;
  onBack: () => void;
}

export const MemberReferralView: React.FC<MemberReferralViewProps> = ({ user, onBack }) => {
  const [copied, setCopied] = useState(false);
  const [referrals, setReferrals] = useState<any[]>([]);
  const [newRefereeName, setNewRefereeName] = useState('');
  const [newRefereeWhatsApp, setNewRefereeWhatsApp] = useState('');
  const [adding, setAdding] = useState(false);

  useEffect(() => {
    if (!user.uid) return;
    const q = query(collection(db, 'referrals'), where('referrerUserId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setReferrals(data);
    }, (error) => {
      console.warn("Referrals sync failed:", error.message);
    });
    return unsubscribe;
  }, [user.uid]);

  const addReferral = async () => {
    if (!newRefereeName) return;
    setAdding(true);
    try {
      await addDoc(collection(db, 'referrals'), {
        referrerUserId: user.uid,
        refereeName: newRefereeName,
        refereeWhatsApp: newRefereeWhatsApp || '',
        status: 'pending',
        createdAt: serverTimestamp()
      });
      setNewRefereeName('');
      setNewRefereeWhatsApp('');
      toast.success("¡Referido registrado!");
    } catch (e) {
      toast.error("Error al registrar referido");
    } finally {
      setAdding(false);
    }
  };

  // En producción esto vendría de la URL real, aquí usamos una base genérica
  const baseUrl = window.location.origin;
  const referralLink = `${baseUrl}?ref=${user.name.replace(/\s+/g, '').toLowerCase()}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    toast.success("¡Enlace copiado!", {
      description: "Compártelo con tus clientes para ganar comisiones."
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-slate-100 rounded-full transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <h1 className="text-sm font-black text-slate-900 uppercase tracking-widest">
            Socio Afiliado AutoFlux
          </h1>
          <div className="w-10" /> {/* Spacer */}
        </div>
      </div>

      <main className="max-w-4xl mx-auto p-4 space-y-6 pt-6">
        {/* Welcome Section */}
        <section className="bg-blue-600 rounded-[2rem] p-8 text-white shadow-xl shadow-blue-200 overflow-hidden relative">
          <div className="relative z-10">
            <h2 className="text-3xl font-black mb-2">¡Gana hasta $500 por Referido!</h2>
            <p className="text-blue-100 text-sm max-w-md font-medium">
              Recibe <span className="font-black text-white">$100 USD</span> inmediatos por cada Reserva y un total de <span className="font-black text-white">$500 USD</span> al completarse la venta.
            </p>
          </div>
          <Users className="absolute -right-4 -bottom-4 w-40 h-40 text-blue-500/30 rotate-12" />
        </section>

        {/* Link Generator */}
        <section className="bg-white rounded-[2rem] p-6 shadow-sm border border-slate-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
              <Share2 className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900">Tu Enlace Personalizado</h3>
              <p className="text-xs text-slate-500">Copia y comparte este link en redes o WhatsApp</p>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-3">
            <div className="flex-1 bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 font-mono text-xs text-slate-600 flex items-center overflow-x-auto whitespace-nowrap">
              {referralLink}
            </div>
            <div className="flex gap-2">
              <button 
                onClick={copyToClipboard}
                className="flex-1 md:flex-none px-6 py-3 bg-blue-600 text-white rounded-2xl text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-blue-700 transition-all active:scale-95"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copied ? 'Copiado' : 'Copiar'}
              </button>
              <button 
                onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(`¡Mira estos autos increíbles en AutoFlux! ${referralLink}`)}`, '_blank')}
                className="p-3 bg-green-500 text-white rounded-2xl hover:bg-green-600 transition-all"
              >
                <Share2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        </section>

        {/* Master Plan Section */}
        <section className="bg-white rounded-[2rem] p-8 shadow-sm border border-slate-100 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8">
            <QrCode className="w-12 h-12 text-slate-100" />
          </div>
          
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-200">
                <Check className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tight">Plan Maestro de Referidos</h3>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <h4 className="text-xs font-black text-blue-600 uppercase tracking-widest mb-3">01. CAPTACIÓN</h4>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Utiliza tu enlace único para registrar prospectos. El sistema asocia la IP y el dispositivo del cliente a tu cuenta por 30 días (Cookies de rastreo).
                  </p>
                </div>
                <div>
                  <h4 className="text-xs font-black text-blue-600 uppercase tracking-widest mb-3">02. RESERVA (Bono $100)</h4>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    En cuanto tu referido realiza el pago de la reserva ($500 - $1,000), se genera automáticamente un bono de <span className="font-bold text-slate-900">$100 USD</span> para ti.
                  </p>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <h4 className="text-xs font-black text-blue-600 uppercase tracking-widest mb-3">03. CIERRE (Bono $400)</h4>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Al completarse la venta y entrega del vehículo en Venezuela, recibes el remanente de <span className="font-bold text-slate-900">$400 USD</span> adicionales.
                  </p>
                </div>
                <div>
                  <h4 className="text-xs font-black text-blue-600 uppercase tracking-widest mb-3">04. CONTROL Y AUDITORÍA</h4>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Puedes ver el estatus de tus referidos en tiempo real abajo. "Pendiente" significa que están en proceso de selección, "Convertido" significa reserva pagada.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Pago Promedio por Cierre</p>
                  <p className="text-lg font-black text-slate-900">$500.00 USD</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Próxima Fecha de Corte</p>
                <p className="px-4 py-1 bg-slate-900 text-white rounded-full text-[10px] font-black uppercase tracking-widest inline-block">
                  CADA VIERNES
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div className="bg-white p-6 rounded-[2rem] border border-slate-100 text-center">
            <Users className="w-6 h-6 text-slate-400 mx-auto mb-2" />
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Total Referidos</p>
            <p className="text-2xl font-black text-slate-900">{referrals.length}</p>
          </div>
          <div className="bg-white p-6 rounded-[2rem] border border-slate-100 text-center">
            <DollarSign className="w-6 h-6 text-green-500 mx-auto mb-2" />
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Comisión Pendiente</p>
            <p className="text-2xl font-black text-slate-900">${referrals.filter(r => r.status === 'converted').length * 100}</p>
          </div>
          <div className="bg-white p-6 rounded-[2rem] border border-slate-100 text-center col-span-2 md:col-span-1">
            <ExternalLink className="w-6 h-6 text-blue-500 mx-auto mb-2" />
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Convertidos</p>
            <p className="text-2xl font-black text-slate-900">{referrals.filter(r => r.status === 'converted').length}</p>
          </div>
        </div>

        {/* Add Referral Form */}
        <section className="bg-white rounded-[2rem] p-6 shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-900 mb-4 tracking-tight">Registrar nuevo prospecto</h3>
          <div className="grid gap-3">
             <input type="text" placeholder="Nombre completo del referido" className="w-full bg-slate-50 rounded-2xl px-4 py-3 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500/20" value={newRefereeName} onChange={e => setNewRefereeName(e.target.value)} />
             <input type="text" placeholder="WhatsApp (opcional)" className="w-full bg-slate-50 rounded-2xl px-4 py-3 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500/20" value={newRefereeWhatsApp} onChange={e => setNewRefereeWhatsApp(e.target.value)} />
             <button onClick={addReferral} disabled={adding || !newRefereeName} className="w-full py-3 bg-blue-600 text-white rounded-2xl font-bold text-sm hover:bg-blue-700 transition-all">
                {adding ? 'Registrando...' : 'Registrar Prospecto'}
             </button>
          </div>
        </section>

        {/* Referral List */}
        <section className="space-y-4">
          <div className="flex items-center justify-between px-2">
            <h3 className="font-bold text-slate-900 tracking-tight">Tus Referidos</h3>
            <button 
              onClick={() => toast.info("Generando PDF de Master Plan...", { description: "Tus términos y condiciones personalizados se están procesando." })}
              className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline"
            >
              Descargar PDF del Plan
            </button>
          </div>
          <div className="grid gap-3">
            {referrals.length === 0 ? (
              <div className="bg-white p-12 rounded-[2rem] border border-slate-100 text-center">
                <Users className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                <p className="text-sm text-slate-500 font-medium">Aún no tienes referidos registrados.</p>
                <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-widest">¡Empieza compartiendo tu link!</p>
              </div>
            ) : referrals.map(ref => (
               <div key={ref.id} className="bg-white p-5 rounded-[2rem] border border-slate-100 flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 font-bold">
                        {ref.refereeName.charAt(0)}
                      </div>
                      <div>
                        <p className="font-black text-slate-900 leading-none">{ref.refereeName}</p>
                        <p className="text-[10px] text-slate-500 mt-1 uppercase font-bold tracking-widest">
                          ID: {ref.id.substring(0, 8).toUpperCase()} • {new Date(ref.createdAt?.toDate()).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
                        ref.status === 'converted' ? 'bg-green-500 text-white shadow-lg shadow-green-200' : 
                        ref.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                        'bg-slate-100 text-slate-500'
                      }`}>
                        {ref.status === 'converted' ? 'GANANCIA LISTA' : ref.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                  
                  {/* Progress Bar for 'Control' */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-[9px] font-bold uppercase tracking-widest">
                      <span className="text-blue-600">Proceso de Venta</span>
                      <span className="text-slate-500">{ref.status === 'converted' ? '100%' : '20%'}</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: ref.status === 'converted' ? '100%' : '20%' }}
                        className={`h-full rounded-full ${ref.status === 'converted' ? 'bg-green-500' : 'bg-blue-600'}`}
                      />
                    </div>
                    <div className="flex justify-between text-[8px] text-slate-400 font-bold uppercase tracking-tighter">
                      <span>Prospecto</span>
                      <span>Reserva</span>
                      <span>Aduana</span>
                      <span>Entrega</span>
                    </div>
                  </div>
               </div>
            ))}
          </div>
        </section>

        {/* How it works */}
        <section className="space-y-4">
          <h3 className="font-bold text-slate-900 px-2 tracking-tight">¿Cómo funciona?</h3>
          <div className="grid gap-4">
            {[
              { 
                step: 1, 
                title: "Comparte tu Link", 
                desc: "Envía tu enlace por redes sociales, estados de WhatsApp o mensajes directos." 
              },
              { 
                step: 2, 
                title: "Rastreo de 30 Días", 
                desc: "Si el cliente entra hoy pero reserva dentro de 3 semanas, la comisión sigue siendo tuya." 
              },
              { 
                step: 3, 
                title: "Cobra y Gana", 
                desc: "Liquidamos tus $100 por reserva al instante y hasta $500 si el cliente finaliza la compra." 
              }
            ].map((item, idx) => (
              <div key={idx} className="bg-white p-5 rounded-3xl border border-slate-100 flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-slate-900 text-white text-xs font-bold flex items-center justify-center shrink-0">
                  {item.step}
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{item.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed mt-1">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Admin Contact */}
        <button 
          onClick={() => window.open(`https://wa.me/584248691131?text=Hola,%20soy%20socio%20afiliado%20y%20quiero%20consultar%20mis%20comisiones.`, '_blank')}
          className="w-full py-4 bg-slate-900 text-white rounded-[2rem] font-bold text-sm uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl shadow-slate-200"
        >
          Contactar Soporte de Pagos
        </button>
      </main>
    </div>
  );
};

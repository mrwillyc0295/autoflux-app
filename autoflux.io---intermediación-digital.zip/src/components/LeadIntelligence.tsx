import React from 'react';
import { motion } from 'motion/react';
import { Target, Brain, Zap, TrendingUp, User, MessageCircle, DollarSign } from 'lucide-react';
import { cn } from '../lib/utils';

interface LeadScoringReport {
  id: string;
  car_model: string;
  customer_name: string;
  message: string;
  budget: number;
  timestamp: Date;
  analysis?: {
    lead_analysis: {
      seriousness_level: 'BAJO' | 'MEDIO' | 'ALTO';
      budget_vs_market: string;
      buyer_profile: string;
      intent_score: number;
    };
    sales_strategy: {
      psychological_approach: string;
      hooks: string[];
    };
  };
}

interface LeadIntelligenceProps {
  leads: LeadScoringReport[];
}

export const LeadIntelligence: React.FC<LeadIntelligenceProps> = ({ leads }) => {
  return (
    <div className="glass-card p-4 md:p-8 rounded-[2.5rem] border-[#A3FF47]/20 bg-gradient-to-br from-[#A3FF47]/5 to-transparent">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-12 h-12 bg-[#A3FF47]/10 rounded-2xl flex items-center justify-center">
          <Target className="w-6 h-6 text-[#A3FF47]" />
        </div>
        <div>
          <h3 className="text-xl font-black text-white tracking-widest uppercase">Lead Intelligence</h3>
          <p className="text-[#A3FF47]/60 text-[10px] font-bold uppercase tracking-widest">
            Calificador de Seriedad y Estrategia (Gemini 3.5)
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {leads.length > 0 ? (
          leads.map((lead, idx) => (
            <motion.div
              key={lead.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="glass-card p-6 rounded-3xl border-white/5 bg-[#0B0F1A]/50 hover:border-[#A3FF47]/30 transition-all group"
            >
              <div className="flex flex-col lg:flex-row gap-6">
                {/* Left side: Basic Info */}
                <div className="lg:w-1/3 border-b lg:border-b-0 lg:border-r border-white/5 pb-6 lg:pb-0 lg:pr-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-blue-600/10 rounded-xl flex items-center justify-center">
                      <User className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Prospecto</p>
                      <p className="text-sm font-black text-white uppercase">{lead.customer_name}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500 font-bold uppercase">Interés</span>
                      <span className="text-white font-black uppercase text-right">{lead.car_model}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500 font-bold uppercase">Presupuesto</span>
                      <span className="text-[#A3FF47] font-black">${lead.budget.toLocaleString()}</span>
                    </div>
                    <div className="bg-white/5 p-3 rounded-xl mt-4">
                      <p className="text-[10px] font-bold text-slate-500 uppercase mb-1 flex items-center gap-1">
                        <MessageCircle className="w-3 h-3" /> Mensaje
                      </p>
                      <p className="text-[11px] text-slate-300 italic">"{lead.message}"</p>
                    </div>
                  </div>
                </div>

                {/* Right side: AI Analysis */}
                <div className="flex-1 space-y-4">
                  {lead.analysis ? (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-[#A3FF47]/5 border border-[#A3FF47]/20 p-4 rounded-2xl">
                          <div className="flex items-center gap-2 mb-2">
                            <TrendingUp className="w-4 h-4 text-[#A3FF47]" />
                            <span className="text-[10px] font-bold text-[#A3FF47] uppercase tracking-widest">Score de Intención</span>
                          </div>
                          <div className="flex items-end gap-3">
                            <span className="text-3xl font-black text-white tracking-tighter">{lead.analysis.lead_analysis.intent_score}%</span>
                            <span className={cn(
                              "text-[10px] font-bold px-2 py-0.5 rounded-full mb-1",
                              lead.analysis.lead_analysis.seriousness_level === 'ALTO' ? "bg-green-500/20 text-green-400" :
                              lead.analysis.lead_analysis.seriousness_level === 'MEDIO' ? "bg-yellow-500/20 text-yellow-400" : "bg-red-500/20 text-red-400"
                            )}>
                              {lead.analysis.lead_analysis.seriousness_level}
                            </span>
                          </div>
                        </div>

                        <div className="bg-blue-600/5 border border-blue-600/20 p-4 rounded-2xl">
                          <div className="flex items-center gap-2 mb-2">
                            <Brain className="w-4 h-4 text-blue-400" />
                            <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Perfil Psicográfico</span>
                          </div>
                          <p className="text-sm font-bold text-white truncate">{lead.analysis.lead_analysis.buyer_profile}</p>
                        </div>
                      </div>

                      <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                        <div className="flex items-center gap-2 mb-3">
                          <Zap className="w-4 h-4 text-orange-400" />
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Estrategia: <span className="text-white">{lead.analysis.sales_strategy.psychological_approach}</span></span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          {lead.analysis.sales_strategy.hooks.map((hook, i) => (
                            <div key={i} className="bg-[#0B0F1A] border border-white/5 p-3 rounded-xl text-[10px] font-medium text-slate-300 leading-tight">
                              {hook}
                            </div>
                          ))}
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="h-full flex items-center justify-center py-10">
                      <div className="flex items-center gap-3 text-slate-500 animate-pulse">
                        <Zap className="w-5 h-5 animate-bounce" />
                        <span className="text-xs font-bold uppercase tracking-widest">Calculando Inteligencia de Lead...</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-12 border-2 border-dashed border-white/5 rounded-3xl">
            <p className="text-slate-500 text-xs font-bold uppercase tracking-widest italic">Esperando entrada de leads...</p>
          </div>
        )}
      </div>
    </div>
  );
};

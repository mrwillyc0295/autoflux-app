import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { SecurityMonitor } from './components/SecurityMonitor.tsx';

// Registro del Service Worker para PWA
import { registerSW } from 'virtual:pwa-register';

// ==========================================
// AUTOFLUX ENTERPRISE-GRADE RUNTIME SAFEGUARDS
// ==========================================

// 1. SAFEGUARD: Polyfill 'process.env' to insulate client code from ReferenceError where Node globals are expected
if (typeof process === 'undefined') {
  (window as any).process = { env: {} };
} else if (!(process as any).env) {
  (process as any).env = {};
}

// 2. SAFEGUARD: Resilient Storage Mocking to prevent SecurityError exceptions in restricted iframes or privacy modes
let isStorageSafe = false;
try {
  localStorage.setItem('__test_storage__', '1');
  localStorage.removeItem('__test_storage__');
  isStorageSafe = true;
} catch (e) {
  isStorageSafe = false;
}

if (!isStorageSafe) {
  console.warn("[AUTOFLUX] LocalStorage restricted or blocked. Mounting memory-based persistent layer.");
  const memoryStore: Record<string, string> = {};
  const mockStorage: Storage = {
    length: 0,
    clear: () => {
      Object.keys(memoryStore).forEach(k => delete memoryStore[k]);
      (mockStorage as any).length = 0;
    },
    getItem: (key: string) => memoryStore[key] || null,
    key: (index: number) => Object.keys(memoryStore)[index] || null,
    removeItem: (key: string) => {
      delete memoryStore[key];
      (mockStorage as any).length = Object.keys(memoryStore).length;
    },
    setItem: (key: string, value: string) => {
      memoryStore[key] = String(value);
      (mockStorage as any).length = Object.keys(memoryStore).length;
    }
  };
  Object.defineProperty(window, 'localStorage', { value: mockStorage, configurable: true, writable: true });
}

let isSessionStorageSafe = false;
try {
  sessionStorage.setItem('__test_session__', '1');
  sessionStorage.removeItem('__test_session__');
  isSessionStorageSafe = true;
} catch (e) {
  isSessionStorageSafe = false;
}

if (!isSessionStorageSafe) {
  console.warn("[AUTOFLUX] SessionStorage restricted or blocked. Mounting memory-based transient layer.");
  const memoryStore: Record<string, string> = {};
  const mockStorage: Storage = {
    length: 0,
    clear: () => {
      Object.keys(memoryStore).forEach(k => delete memoryStore[k]);
      (mockStorage as any).length = 0;
    },
    getItem: (key: string) => memoryStore[key] || null,
    key: (index: number) => Object.keys(memoryStore)[index] || null,
    removeItem: (key: string) => {
      delete memoryStore[key];
      (mockStorage as any).length = Object.keys(memoryStore).length;
    },
    setItem: (key: string, value: string) => {
      memoryStore[key] = String(value);
      (mockStorage as any).length = Object.keys(memoryStore).length;
    }
  };
  Object.defineProperty(window, 'sessionStorage', { value: mockStorage, configurable: true, writable: true });
}

// Constante de versión para invalidar cachés y estados corruptos en Vercel
const APP_VERSION = '1.0.3';

// Limpieza agresiva en caso de cambio de versión
const checkVersionAndClean = () => {
  try {
    const currentVersion = localStorage.getItem('autoflux_version');
    if (currentVersion !== APP_VERSION) {
      console.log(`[AUTOFLUX] Nueva versión detectada (${APP_VERSION}). Purgando estado obsoleto...`);
      // Evitamos borrar todo localStorage indiscriminadamente si hay algo importante,
      // pero como es PWA, borramos el estado de la UI
      
      // Cleanup de zustand o estados parseados que pueden romper hidratación
      Object.keys(localStorage).forEach(key => {
        if (!key.includes('firebase')) { // Proteger sesión auth
          localStorage.removeItem(key);
        }
      });
      localStorage.setItem('autoflux_version', APP_VERSION);
    }
  } catch (e) {
    console.error("Error al limpiar caché local", e);
  }
};
checkVersionAndClean();

if ('serviceWorker' in navigator) {
  let updateSW: any;
  updateSW = registerSW({
    immediate: true,
    onNeedRefresh() {
      console.log('[AUTOFLUX] Nuevo Service Worker en espera.');
      // Usamos un retraso seguro o dejamos que 'autoUpdate' del config se encargue
      if (typeof updateSW === 'function') {
        updateSW(true);
      } else {
        // Alternativa segura si se dispara antes de la asignación de la constante
        window.location.reload();
      }
    },
    onRegistered(r) {
      console.log('SW Registered:', r);
      // Opcional: chequear actualizaciones periódicamente
      r && setInterval(() => { r.update(); }, 60 * 60 * 1000); 
    },
    onRegisterError(error) {
      console.log('SW registration error', error);
    }
  });
}

// LIMPIEZA DE CACHÉ GLOBAL - Utilizado para resetear PWA local
window.clearAppCache = async () => {
  console.log('[AUTOFLUX] Iniciando purga de caché...');
  localStorage.clear();
  sessionStorage.clear();
  if ('caches' in window) {
    try {
      const keys = await caches.keys();
      await Promise.all(keys.map(key => caches.delete(key)));
      console.log('[AUTOFLUX] Caché de PWA eliminada con éxito.');
    } catch (e) {
      console.error('[AUTOFLUX] Fallo al eliminar caché:', e);
    }
  }
  if (navigator.serviceWorker) {
    const registrations = await navigator.serviceWorker.getRegistrations();
    for (const registration of registrations) {
      await registration.unregister();
    }
    console.log('[AUTOFLUX] Service Workers desregistrados.');
  }
  window.location.reload();
};

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <SecurityMonitor />
      <App />
    </ErrorBoundary>
  </StrictMode>,
);

export type LeadStatus = 'Vendido por Nuestra App' | 'Vendido por Fuera' | 'Lead No Calificado' | 'Apartado/En Pausa' | 'Nuevo';

export type VehicleStyle = 'Sedans' | 'Trucks' | 'Commercial' | 'SUVs & Crossovers' | 'Coupes' | 'Hatchbacks' | 'Vans & Minivans' | 'Convertibles' | 'Wagons' | 'AWDs & 4WDs' | 'Hybrids' | 'Electrics' | 'Luxury';

export interface Car {
  id: string;
  make: string;
  model: string;
  year: number;
  price: number; 
  basePrice?: number;
  mileage: number;
  location: string;
  image: string;
  images?: string[];
  video?: string;
  seller: string;
  sellerId: string;
  sellerPhoto?: string;
  sellerBio?: string;
  sellerWhatsApp?: string;
  status: 'active' | 'reserved' | 'sold';
  condition?: 'Nuevo' | 'Usado';
  style?: VehicleStyle;
  createdAt?: any;
  updatedAt?: any;
  views?: number;
  clics?: number;
  interactions?: number;
  transmission?: string;
  fuelType?: string;
  engineLiters?: string;
  description?: string;
  placa?: string;
}

declare global {
  interface Window {
    clearAppCache: () => Promise<void>;
  }
}

export interface UserProfile {
  uid: string;
  authUid?: string;
  name: string;
  email?: string;
  whatsapp: string;
  role: 'marketplace' | 'seller' | 'admin';
  country?: string;
  photo?: string;
  bio?: string;
  createdAt?: any;
  referredBy?: string;
  isOfflineFallback?: boolean;
}

export interface Message {
  role: 'user' | 'model' | 'admin';
  text: string;
  timestamp: any;
}

export interface LiquidationAdvice {
  is_stagnant: boolean;
  days_on_market: number;
  suggested_price_drop: number;
  new_target_price: number;
  rationale: string;
}

export interface ReferralRank {
  currentRank: string;
  commission: string;
  salesToNextRank: number;
  nextRank: string;
  projection: string;
}

export interface ShareStrategy {
  recommendedCars: string[];
  hooks: string[];
  whatsAppMessage: string;
}

export interface WalletStatus {
  totalBalance: number;
  pendingBalance: number;
  transactions: {
    id: string;
    amount: number;
    type: 'commission' | 'withdrawal';
    status: 'pending' | 'completed';
    date: any;
  }[];
}

export interface ModelInfo {
  id: string;
  name: string;
  category?: string;
}

export const CAR_DATA: Record<string, (string | ModelInfo)[]> = {
  "Toyota": [
    {"id": "4runner", "name": "4Runner", "category": "SUV - Demanda: Extrema"},
    {"id": "land_cruiser", "name": "Land Cruiser", "category": "SUV - Demanda: Extrema"},
    {"id": "sequoia", "name": "Sequoia", "category": "SUV - Demanda: Alta"},
    {"id": "highlander", "name": "Highlander", "category": "SUV - Demanda: Alta"},
    {"id": "grand_highlander", "name": "Grand Highlander", "category": "SUV - Demanda: Alta"},
    {"id": "rav4", "name": "RAV4", "category": "SUV - Demanda: Alta"},
    {"id": "corolla_cross", "name": "Corolla Cross", "category": "SUV - Demanda: Alta"},
    {"id": "venza", "name": "Venza", "category": "SUV - Demanda: Media"},
    {"id": "bz4x", "name": "bZ4X", "category": "SUV - Demanda: Baja"},
    {"id": "tacoma", "name": "Tacoma", "category": "Pickup - Demanda: Extrema"},
    {"id": "tundra", "name": "Tundra", "category": "Pickup - Demanda: Extrema"},
    {"id": "corolla", "name": "Corolla", "category": "Sedán - Demanda: Alta"},
    {"id": "camry", "name": "Camry", "category": "Sedán - Demanda: Alta"},
    {"id": "crown", "name": "Crown", "category": "Sedán - Demanda: Media"},
    {"id": "prius", "name": "Prius", "category": "Sedán - Demanda: Media"},
    {"id": "prius_prime", "name": "Prius Prime", "category": "Sedán - Demanda: Media"},
    {"id": "gr_supra", "name": "GR Supra", "category": "Deportivo - Demanda: Alta"},
    {"id": "gr_corolla", "name": "GR Corolla", "category": "Deportivo - Demanda: Media"},
    {"id": "gr86", "name": "GR86", "category": "Deportivo - Demanda: Media"},
    {"id": "sienna", "name": "Sienna", "category": "Minivan - Demanda: Media"}
  ],
  "Ford": [
    {"id": "f150", "name": "F-150 (Lariat, Platinum, King Ranch)", "category": "Pickup - Demanda: Extrema"},
    {"id": "f150_raptor", "name": "F-150 Raptor / Raptor R", "category": "Pickup - Demanda: Extrema"},
    {"id": "ranger_raptor", "name": "Ranger Raptor", "category": "Pickup - Demanda: Alta"},
    {"id": "super_duty", "name": "F-250 / F-350 Super Duty", "category": "Pickup - Demanda: Alta"},
    {"id": "maverick", "name": "Maverick", "category": "Pickup - Demanda: Media"},
    {"id": "bronco", "name": "Bronco (2-Door / 4-Door)", "category": "Todoterreno - Demanda: Extrema"},
    {"id": "bronco_raptor", "name": "Bronco Raptor", "category": "Todoterreno - Demanda: Extrema"},
    {"id": "mustang", "name": "Mustang (GT, Dark Horse)", "category": "Deportivo - Demanda: Alta"},
    {"id": "explorer", "name": "Explorer / Explorer ST", "category": "SUV Familiar - Demanda: Extrema"},
    {"id": "expedition", "name": "Expedition / Max", "category": "SUV Familiar - Demanda: Alta"},
    {"id": "edge", "name": "Edge", "category": "SUV Familiar - Demanda: Media"},
    {"id": "bronco_sport", "name": "Bronco Sport", "category": "SUV Familiar - Demanda: Alta"},
    {"id": "f150_lightning", "name": "F-150 Lightning", "category": "Eléctrico - Demanda: Media"},
    {"id": "mustang_mach_e", "name": "Mustang Mach-E", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Chevrolet": [
    {"id": "silverado_1500", "name": "Silverado 1500", "category": "Pickup - Demanda: Extrema"},
    {"id": "silverado_hd", "name": "Silverado 2500HD / 3500HD", "category": "Pickup - Demanda: Alta"},
    {"id": "colorado", "name": "Colorado", "category": "Pickup - Demanda: Alta"},
    {"id": "tahoe", "name": "Tahoe", "category": "SUV - Demanda: Extrema"},
    {"id": "suburban", "name": "Suburban", "category": "SUV - Demanda: Extrema"},
    {"id": "traverse", "name": "Traverse", "category": "SUV - Demanda: Media"},
    {"id": "blazer", "name": "Blazer", "category": "SUV - Demanda: Media"},
    {"id": "equinox", "name": "Equinox", "category": "SUV - Demanda: Media"},
    {"id": "trailblazer", "name": "Trailblazer", "category": "SUV - Demanda: Media"},
    {"id": "trax", "name": "Trax", "category": "SUV - Demanda: Media"},
    {"id": "corvette", "name": "Corvette (Stingray, Z06, E-Ray)", "category": "Deportivo - Demanda: Alta"},
    {"id": "camaro", "name": "Camaro", "category": "Deportivo - Demanda: Media"},
    {"id": "malibu", "name": "Malibu", "category": "Sedán - Demanda: Baja"},
    {"id": "silverado_ev", "name": "Silverado EV", "category": "Eléctrico - Demanda: Baja"},
    {"id": "blazer_ev", "name": "Blazer EV", "category": "Eléctrico - Demanda: Baja"},
    {"id": "equinox_ev", "name": "Equinox EV", "category": "Eléctrico - Demanda: Baja"},
    {"id": "bolt_euv", "name": "Bolt EV / EUV", "category": "Eléctrico - Demanda: Baja"}
  ],
  "GMC": [
    {"id": "yukon", "name": "Yukon / Yukon Denali", "category": "SUV - Demanda: Extrema"},
    {"id": "yukon_xl", "name": "Yukon XL / Yukon XL Denali", "category": "SUV - Demanda: Extrema"},
    {"id": "sierra_1500", "name": "Sierra 1500 / Denali", "category": "Pickup - Demanda: Extrema"},
    {"id": "sierra_hd", "name": "Sierra 2500HD / 3500HD", "category": "Pickup - Demanda: Alta"},
    {"id": "canyon", "name": "Canyon / Canyon AT4X", "category": "Pickup - Demanda: Alta"},
    {"id": "acadia", "name": "Acadia / Acadia Denali", "category": "SUV - Demanda: Media"},
    {"id": "terrain", "name": "Terrain / Terrain Denali", "category": "SUV - Demanda: Media"},
    {"id": "hummer_ev_pickup", "name": "Hummer EV Pickup", "category": "Supertruck - Demanda: Alta"},
    {"id": "hummer_ev_suv", "name": "Hummer EV SUV", "category": "Supertruck - Demanda: Alta"},
    {"id": "sierra_ev", "name": "Sierra EV Denali Edition 1", "category": "Eléctrico - Demanda: Media"}
  ],
  "Honda": [
    {"id": "cr_v", "name": "CR-V", "category": "SUV - Demanda: Extrema"},
    {"id": "pilot", "name": "Pilot", "category": "SUV - Demanda: Extrema"},
    {"id": "passport", "name": "Passport", "category": "SUV - Demanda: Alta"},
    {"id": "hr_v", "name": "HR-V", "category": "SUV - Demanda: Alta"},
    {"id": "civic_sedan", "name": "Civic Sedan", "category": "Sedán - Demanda: Alta"},
    {"id": "civic_hatchback", "name": "Civic Hatchback", "category": "Compacto - Demanda: Media"},
    {"id": "accord", "name": "Accord", "category": "Sedán - Demanda: Alta"},
    {"id": "ridgeline", "name": "Ridgeline", "category": "Pickup - Demanda: Media"},
    {"id": "odyssey", "name": "Odyssey", "category": "Minivan - Demanda: Media"},
    {"id": "civic_type_r", "name": "Civic Type R", "category": "Deportivo - Demanda: Alta"},
    {"id": "prologue", "name": "Prologue", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Nissan": [
    {"id": "armada", "name": "Armada", "category": "SUV Grande - Demanda: Extrema"},
    {"id": "armada_nismo", "name": "Armada NISMO", "category": "SUV Grande - Demanda: Alta"},
    {"id": "pathfinder", "name": "Pathfinder", "category": "SUV Grande - Demanda: Alta"},
    {"id": "frontier", "name": "Frontier (PRO-4X / Hardbody)", "category": "Pickup - Demanda: Alta"},
    {"id": "titan", "name": "Titan / Titan XD", "category": "Pickup - Demanda: Media"},
    {"id": "rogue", "name": "Rogue", "category": "SUV Compacta - Demanda: Alta"},
    {"id": "rogue_phev", "name": "Rogue Plug-in Hybrid", "category": "SUV Compacta - Demanda: Media"},
    {"id": "murano", "name": "Murano (Redesign)", "category": "SUV Compacta - Demanda: Media"},
    {"id": "kicks", "name": "Kicks / Kicks Play", "category": "SUV Compacta - Demanda: Media"},
    {"id": "nissan_z", "name": "Nissan Z / Z NISMO", "category": "Deportivo - Demanda: Alta"},
    {"id": "gtr", "name": "GT-R (R35 Final Editions)", "category": "Deportivo - Demanda: Alta"},
    {"id": "sentra", "name": "Sentra", "category": "Sedán - Demanda: Alta"},
    {"id": "altima", "name": "Altima", "category": "Sedán - Demanda: Media"},
    {"id": "versa", "name": "Versa", "category": "Sedán - Demanda: Media"},
    {"id": "ariya", "name": "Ariya", "category": "Eléctrico - Demanda: Baja"},
    {"id": "leaf", "name": "Leaf (Next Gen Crossover)", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Hyundai": [
    {"id": "palisade", "name": "Palisade", "category": "SUV - Demanda: Alta"},
    {"id": "santa_fe", "name": "Santa Fe", "category": "SUV - Demanda: Alta"},
    {"id": "tucson", "name": "Tucson", "category": "SUV - Demanda: Extrema"},
    {"id": "kona", "name": "Kona", "category": "SUV - Demanda: Media"},
    {"id": "venue", "name": "Venue", "category": "SUV - Demanda: Media"},
    {"id": "elantra", "name": "Elantra", "category": "Sedán - Demanda: Alta"},
    {"id": "sonata", "name": "Sonata", "category": "Sedán - Demanda: Media"},
    {"id": "santa_cruz", "name": "Santa Cruz", "category": "Pickup - Demanda: Media"},
    {"id": "elantra_n", "name": "Elantra N", "category": "Línea N - Demanda: Media"},
    {"id": "kona_n", "name": "Kona N", "category": "Línea N - Demanda: Baja"},
    {"id": "ioniq_5", "name": "IONIQ 5", "category": "Eléctrico - Demanda: Baja"},
    {"id": "ioniq_6", "name": "IONIQ 6", "category": "Eléctrico - Demanda: Baja"},
    {"id": "ioniq_5_n", "name": "IONIQ 5 N", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Kia": [
    {"id": "telluride", "name": "Telluride", "category": "SUV - Demanda: Extrema"},
    {"id": "sorento", "name": "Sorento", "category": "SUV - Demanda: Alta"},
    {"id": "sportage", "name": "Sportage", "category": "SUV - Demanda: Extrema"},
    {"id": "seltos", "name": "Seltos", "category": "SUV - Demanda: Media"},
    {"id": "niro", "name": "Niro (HEV / PHEV)", "category": "SUV - Demanda: Media"},
    {"id": "soul", "name": "Soul", "category": "SUV - Demanda: Media"},
    {"id": "k5", "name": "K5", "category": "Sedán - Demanda: Media"},
    {"id": "forte", "name": "Forte", "category": "Sedán - Demanda: Media"},
    {"id": "rio", "name": "Rio", "category": "Sedán - Demanda: Baja"},
    {"id": "stinger", "name": "Stinger", "category": "Deportivo - Demanda: Alta"},
    {"id": "carnival", "name": "Carnival", "category": "Minivan - Demanda: Alta"},
    {"id": "ev9", "name": "EV9 (SUV 3 Filas)", "category": "Eléctrico - Demanda: Media"},
    {"id": "ev6", "name": "EV6", "category": "Eléctrico - Demanda: Baja"},
    {"id": "niro_ev", "name": "Niro EV", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Mazda": [
    {"id": "cx_90", "name": "CX-90", "category": "SUV - Demanda: Alta"},
    {"id": "cx_9", "name": "CX-9", "category": "SUV - Demanda: Media"},
    {"id": "cx_70", "name": "CX-70", "category": "SUV - Demanda: Media"},
    {"id": "cx_50", "name": "CX-50", "category": "SUV - Demanda: Alta"},
    {"id": "cx_5", "name": "CX-5", "category": "SUV - Demanda: Alta"},
    {"id": "cx_30", "name": "CX-30", "category": "SUV - Demanda: Media"},
    {"id": "mazda3_sedan", "name": "Mazda3 Sedan", "category": "Sedán - Demanda: Media"},
    {"id": "mazda3_hatchback", "name": "Mazda3 Hatchback", "category": "Hatchback - Demanda: Media"},
    {"id": "mx_5_miata", "name": "MX-5 Miata / RF", "category": "Deportivo - Demanda: Media"},
    {"id": "mx_30", "name": "MX-30 EV", "category": "Eléctrico - Demanda: Baja"}
  ],
  "BMW": [
    {"id": "x1", "name": "X1", "category": "SUV - Demanda: Media"},
    {"id": "x3", "name": "X3", "category": "SUV - Demanda: Alta"},
    {"id": "x4", "name": "X4", "category": "SUV - Demanda: Alta"},
    {"id": "x5", "name": "X5", "category": "SUV - Demanda: Extrema"},
    {"id": "x6", "name": "X6", "category": "SUV - Demanda: Extrema"},
    {"id": "x7", "name": "X7", "category": "SUV - Demanda: Extrema"},
    {"id": "xm", "name": "XM", "category": "SUV - Demanda: Extrema"},
    {"id": "2_series", "name": "Serie 2", "category": "Coupé - Demanda: Media"},
    {"id": "3_series", "name": "Serie 3", "category": "Sedán - Demanda: Alta"},
    {"id": "4_series", "name": "Serie 4", "category": "Coupé - Demanda: Media"},
    {"id": "5_series", "name": "Serie 5", "category": "Sedán - Demanda: Alta"},
    {"id": "7_series", "name": "Serie 7", "category": "Sedán - Demanda: Alta"},
    {"id": "8_series", "name": "Serie 8", "category": "Coupé - Demanda: Media"},
    {"id": "m2", "name": "M2", "category": "M - Demanda: Alta"},
    {"id": "m3", "name": "M3", "category": "M - Demanda: Extrema"},
    {"id": "m4", "name": "M4", "category": "M - Demanda: Alta"},
    {"id": "m5", "name": "M5", "category": "M - Demanda: Alta"},
    {"id": "m8", "name": "M8", "category": "M - Demanda: Media"},
    {"id": "x5m", "name": "X5 M", "category": "M - Demanda: Extrema"},
    {"id": "x6m", "name": "X6 M", "category": "M - Demanda: Extrema"},
    {"id": "i4", "name": "i4", "category": "Eléctrico - Demanda: Baja"},
    {"id": "i5", "name": "i5", "category": "Eléctrico - Demanda: Baja"},
    {"id": "i7", "name": "i7", "category": "Eléctrico - Demanda: Baja"},
    {"id": "ix", "name": "iX", "category": "Eléctrico - Demanda: Baja"},
    {"id": "z4", "name": "Z4", "category": "Roadster - Demanda: Media"}
  ],
  "Mercedes-Benz": [
    {"id": "g_class", "name": "G-Class (G 550 / AMG G 63)", "category": "SUV de Lujo - Demanda: Extrema"},
    {"id": "gls", "name": "GLS SUV", "category": "SUV de Lujo - Demanda: Extrema"},
    {"id": "gle", "name": "GLE SUV / Coupe", "category": "SUV de Lujo - Demanda: Extrema"},
    {"id": "glc", "name": "GLC SUV / Coupe", "category": "SUV de Lujo - Demanda: Alta"},
    {"id": "maybach_s", "name": "Mercedes-Maybach S-Class", "category": "Maybach - Demanda: Alta"},
    {"id": "maybach_gls", "name": "Mercedes-Maybach GLS SUV", "category": "Maybach - Demanda: Extrema"},
    {"id": "s_class", "name": "S-Class", "category": "Sedán - Demanda: Alta"},
    {"id": "e_class", "name": "E-Class", "category": "Sedán - Demanda: Alta"},
    {"id": "c_class", "name": "C-Class", "category": "Sedán - Demanda: Media"},
    {"id": "cla", "name": "CLA Coupe", "category": "Sedán - Demanda: Media"},
    {"id": "amg_gt_4door", "name": "AMG GT 4-Door Coupe", "category": "AMG - Demanda: Alta"},
    {"id": "amg_gt_2door", "name": "AMG GT Coupe (2-Door)", "category": "AMG - Demanda: Alta"},
    {"id": "amg_sl", "name": "AMG SL Roadster", "category": "AMG - Demanda: Media"},
    {"id": "eqs_suv", "name": "EQS SUV", "category": "Eléctrico - Demanda: Baja"},
    {"id": "eqs_sedan", "name": "EQS Sedan", "category": "Eléctrico - Demanda: Baja"},
    {"id": "eqe_suv", "name": "EQE SUV", "category": "Eléctrico - Demanda: Baja"},
    {"id": "g_580_eq", "name": "G 580 with EQ Technology (G-Wagon EV)", "category": "Eléctrico - Demanda: Media"}
  ],
  "Jeep": [
    {"id": "wrangler", "name": "Wrangler (Sport, Sahara, Rubicon)", "category": "Todoterreno - Demanda: Extrema"},
    {"id": "wrangler_392", "name": "Wrangler Rubicon 392 (V8)", "category": "Todoterreno - Demanda: Extrema"},
    {"id": "gladiator", "name": "Gladiator", "category": "Pickup - Demanda: Alta"},
    {"id": "grand_cherokee", "name": "Grand Cherokee", "category": "SUV - Demanda: Extrema"},
    {"id": "grand_cherokee_l", "name": "Grand Cherokee L (3 Filas)", "category": "SUV - Demanda: Extrema"},
    {"id": "cherokee", "name": "Cherokee", "category": "SUV - Demanda: Media"},
    {"id": "wagoneer", "name": "Wagoneer / Wagoneer L", "category": "Premium - Demanda: Alta"},
    {"id": "grand_wagoneer", "name": "Grand Wagoneer / Grand Wagoneer L", "category": "Premium - Demanda: Alta"},
    {"id": "compass", "name": "Compass", "category": "SUV - Demanda: Media"},
    {"id": "renegade", "name": "Renegade", "category": "SUV - Demanda: Baja"},
    {"id": "wrangler_4xe", "name": "Wrangler 4xe", "category": "Híbrido - Demanda: Alta"},
    {"id": "grand_cherokee_4xe", "name": "Grand Cherokee 4xe", "category": "Híbrido - Demanda: Alta"},
    {"id": "wagoneer_s", "name": "Wagoneer S (EV)", "category": "Eléctrico - Demanda: Baja"},
    {"id": "recon", "name": "Recon (EV)", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Ram": [
    {"id": "ram_1500_tungsten", "name": "RAM 1500 Tungsten (Ultra Lujo)", "category": "Pickup - Demanda: Extrema"},
    {"id": "ram_1500_rho", "name": "RAM 1500 RHO (High Performance)", "category": "Pickup - Demanda: Extrema"},
    {"id": "ram_1500_limited", "name": "RAM 1500 Limited / Longhorn", "category": "Pickup - Demanda: Extrema"},
    {"id": "ram_1500_laramie", "name": "RAM 1500 Laramie / Big Horn", "category": "Pickup - Demanda: Alta"},
    {"id": "ram_1500_rebel", "name": "RAM 1500 Rebel", "category": "Pickup - Demanda: Alta"},
    {"id": "ram_1500_trx", "name": "RAM 1500 TRX (V8 Final Edition)", "category": "Pickup - Demanda: Extrema"},
    {"id": "ram_2500_rebel", "name": "RAM 2500 Rebel / Power Wagon", "category": "Pickup - Demanda: Alta"},
    {"id": "ram_2500_limited", "name": "RAM 2500 Limited", "category": "Pickup - Demanda: Alta"},
    {"id": "ram_3500", "name": "RAM 3500 Heavy Duty", "category": "Pickup - Demanda: Media"},
    {"id": "ram_1500_rev", "name": "RAM 1500 REV (Full Electric)", "category": "Eléctrico - Demanda: Baja"},
    {"id": "ram_1500_ramcharger", "name": "Ramcharger (Electric with Generator)", "category": "Eléctrico - Demanda: Media"}
  ],
  "Mitsubishi": [
    {"id": "outlander", "name": "Outlander", "category": "SUV Familiar - Demanda: Extrema"},
    {"id": "outlander_phev", "name": "Outlander PHEV (Híbrida Enchufable)", "category": "SUV Familiar - Demanda: Alta"},
    {"id": "outlander_trail", "name": "Outlander Trail Edition", "category": "SUV Familiar - Demanda: Alta"},
    {"id": "eclipse_cross", "name": "Eclipse Cross", "category": "SUV Compacto - Demanda: Alta"},
    {"id": "outlander_sport", "name": "Outlander Sport", "category": "SUV Compacto - Demanda: Media"},
    {"id": "outlander_ralliart", "name": "Outlander Ralliart Edition", "category": "Ralliart - Demanda: Alta"},
    {"id": "eclipse_cross_ralliart", "name": "Eclipse Cross Ralliart", "category": "Ralliart - Demanda: Media"},
    {"id": "mirage", "name": "Mirage Hatchback", "category": "Urbano - Demanda: Baja"},
    {"id": "mirage_g4", "name": "Mirage G4 (Sedán)", "category": "Urbano - Demanda: Baja"}
  ],
  "Lexus": [
    {"id": "lx", "name": "LX (LX 600)", "category": "SUV - Demanda: Extrema"},
    {"id": "gx", "name": "GX (GX 460 / GX 550)", "category": "SUV - Demanda: Extrema"},
    {"id": "rx", "name": "RX", "category": "SUV - Demanda: Alta"},
    {"id": "tx", "name": "TX (3 Filas)", "category": "SUV - Demanda: Alta"},
    {"id": "nx", "name": "NX", "category": "SUV - Demanda: Media"},
    {"id": "ux", "name": "UX", "category": "SUV - Demanda: Baja"},
    {"id": "es", "name": "ES", "category": "Sedán - Demanda: Alta"},
    {"id": "is", "name": "IS", "category": "Sedán - Demanda: Media"},
    {"id": "ls", "name": "LS", "category": "Sedán - Demanda: Media"},
    {"id": "lc", "name": "LC / LC Convertible", "category": "Coupé - Demanda: Media"},
    {"id": "rc", "name": "RC / RC F", "category": "Coupé - Demanda: Baja"},
    {"id": "is_500", "name": "IS 500 F SPORT Performance", "category": "Performance - Demanda: Media"},
    {"id": "rz", "name": "RZ", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Acura": [
    {"id": "mdx", "name": "MDX", "category": "SUV - Demanda: Alta"},
    {"id": "rdx", "name": "RDX", "category": "SUV - Demanda: Media"},
    {"id": "integra", "name": "Integra", "category": "Sedán - Demanda: Media"},
    {"id": "tlx", "name": "TLX", "category": "Sedán - Demanda: Media"},
    {"id": "ilx", "name": "ILX", "category": "Sedán - Demanda: Baja"},
    {"id": "mdx_type_s", "name": "MDX Type S", "category": "Type S - Demanda: Alta"},
    {"id": "tlx_type_s", "name": "TLX Type S", "category": "Type S - Demanda: Media"},
    {"id": "integra_type_s", "name": "Integra Type S", "category": "Type S - Demanda: Media"},
    {"id": "nsx_type_s", "name": "NSX Type S", "category": "Type S - Demanda: Baja"},
    {"id": "zdx", "name": "ZDX", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Cadillac": [
    {"id": "escalade", "name": "Escalade / Escalade ESV", "category": "SUV - Demanda: Extrema"},
    {"id": "xt6", "name": "XT6", "category": "SUV - Demanda: Media"},
    {"id": "xt5", "name": "XT5", "category": "SUV - Demanda: Media"},
    {"id": "xt4", "name": "XT4", "category": "SUV - Demanda: Baja"},
    {"id": "ct5", "name": "CT5", "category": "Sedán - Demanda: Media"},
    {"id": "ct4", "name": "CT4", "category": "Sedán - Demanda: Baja"},
    {"id": "escalade_v", "name": "Escalade-V", "category": "V-Series - Demanda: Extrema"},
    {"id": "ct5_v_blackwing", "name": "CT5-V Blackwing", "category": "V-Series - Demanda: Alta"},
    {"id": "ct5_v", "name": "CT5-V", "category": "V-Series - Demanda: Media"},
    {"id": "ct4_v_blackwing", "name": "CT4-V Blackwing", "category": "V-Series - Demanda: Media"},
    {"id": "ct4_v", "name": "CT4-V", "category": "V-Series - Demanda: Baja"},
    {"id": "escalade_iq", "name": "Escalade IQ", "category": "Eléctrico - Demanda: Media"},
    {"id": "lyriq", "name": "LYRIQ", "category": "Eléctrico - Demanda: Baja"},
    {"id": "optiq", "name": "OPTIQ", "category": "Eléctrico - Demanda: Baja"},
    {"id": "celestiq", "name": "CELESTIQ", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Dodge": [
    {"id": "durango", "name": "Durango", "category": "SUV - Demanda: Extrema"},
    {"id": "hornet", "name": "Hornet", "category": "SUV - Demanda: Baja"},
    {"id": "charger_classic", "name": "Charger", "category": "Sedán - Demanda: Alta"},
    {"id": "challenger", "name": "Challenger", "category": "Coupé - Demanda: Alta"},
    {"id": "durango_srt", "name": "Durango SRT / Hellcat", "category": "SRT - Demanda: Extrema"},
    {"id": "charger_srt", "name": "Charger SRT Hellcat", "category": "SRT - Demanda: Extrema"},
    {"id": "challenger_srt", "name": "Challenger SRT Hellcat / Demon", "category": "SRT - Demanda: Extrema"},
    {"id": "charger_sixpack", "name": "Charger Sixpack (Gasolina)", "category": "Nueva Gen - Demanda: Media"},
    {"id": "charger_daytona", "name": "Charger Daytona (Eléctrico)", "category": "Nueva Gen - Demanda: Baja"}
  ],
  "Infiniti": [
    {"id": "qx80", "name": "QX80", "category": "SUV - Demanda: Alta"},
    {"id": "qx60", "name": "QX60", "category": "SUV - Demanda: Alta"},
    {"id": "qx50", "name": "QX50", "category": "SUV - Demanda: Media"},
    {"id": "qx55", "name": "QX55", "category": "SUV - Demanda: Media"},
    {"id": "q50", "name": "Q50", "category": "Sedán - Demanda: Media"},
    {"id": "q60", "name": "Q60", "category": "Coupé - Demanda: Baja"}
  ],
  "Subaru": [
    {"id": "outback", "name": "Outback / Wilderness", "category": "SUV AWD - Demanda: Extrema"},
    {"id": "forester", "name": "Forester / Wilderness", "category": "SUV AWD - Demanda: Alta"},
    {"id": "crosstrek", "name": "Crosstrek / Wilderness", "category": "SUV AWD - Demanda: Alta"},
    {"id": "ascent", "name": "Ascent (3 Filas)", "category": "SUV AWD - Demanda: Media"},
    {"id": "wrx", "name": "WRX", "category": "Deportivo - Demanda: Alta"},
    {"id": "brz", "name": "BRZ", "category": "Deportivo - Demanda: Media"},
    {"id": "impreza", "name": "Impreza (Hatchback)", "category": "Hatchback - Demanda: Media"},
    {"id": "uncharted", "name": "Uncharted (Electric SUV)", "category": "Eléctrico - Demanda: Media"},
    {"id": "trailseeker", "name": "Trailseeker (Midsize EV)", "category": "Eléctrico - Demanda: Baja"},
    {"id": "solterra", "name": "Solterra (EV)", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Land Rover": [
    {"id": "range_rover", "name": "Range Rover (LWB / SWB)", "category": "Superlujo - Demanda: Extrema"},
    {"id": "range_rover_sport", "name": "Range Rover Sport", "category": "Superlujo - Demanda: Extrema"},
    {"id": "range_rover_velar", "name": "Range Rover Velar", "category": "Superlujo - Demanda: Media"},
    {"id": "range_rover_evoque", "name": "Range Rover Evoque", "category": "Superlujo - Demanda: Media"},
    {"id": "defender_110", "name": "Defender 110 (4 Puertas)", "category": "Todoterreno - Demanda: Extrema"},
    {"id": "defender_90", "name": "Defender 90 (2 Puertas)", "category": "Todoterreno - Demanda: Alta"},
    {"id": "defender_130", "name": "Defender 130 (3 Filas extendida)", "category": "Todoterreno - Demanda: Alta"},
    {"id": "discovery", "name": "Discovery", "category": "SUV Familiar - Demanda: Media"},
    {"id": "discovery_sport", "name": "Discovery Sport", "category": "SUV Familiar - Demanda: Baja"}
  ],
  "Porsche": [
    {"id": "911_carrera", "name": "911 Carrera / S / GTS", "category": "Icono - Demanda: Extrema"},
    {"id": "911_t_hybrid", "name": "911 Carrera GTS T-Hybrid", "category": "Híbrido - Demanda: Extrema"},
    {"id": "911_turbo", "name": "911 Turbo / Turbo S", "category": "Icono - Demanda: Extrema"},
    {"id": "911_gt3", "name": "911 GT3 / GT3 RS", "category": "Icono - Demanda: Alta"},
    {"id": "cayenne", "name": "Cayenne / S / GTS", "category": "SUV - Demanda: Extrema"},
    {"id": "cayenne_turbo_gt", "name": "Cayenne Turbo GT", "category": "SUV - Demanda: Extrema"},
    {"id": "macan", "name": "Macan / S / GTS", "category": "SUV - Demanda: Extrema"},
    {"id": "cayenne_ev", "name": "Cayenne Electric (EV)", "category": "Eléctrico - Demanda: Media"},
    {"id": "panamera", "name": "Panamera / E-Hybrid", "category": "Sedán - Demanda: Alta"},
    {"id": "panamera_turbo_s", "name": "Panamera Turbo S E-Hybrid", "category": "Sedán - Demanda: Alta"},
    {"id": "taycan", "name": "Taycan / Turbo S / Cross Turismo", "category": "Eléctrico - Demanda: Media"},
    {"id": "macan_ev", "name": "Macan Electric", "category": "Eléctrico - Demanda: Media"},
    {"id": "718_cayman", "name": "718 Cayman / GT4 RS", "category": "Deportivo - Demanda: Alta"},
    {"id": "718_boxster", "name": "718 Boxster / Spyder RS", "category": "Deportivo - Demanda: Media"}
  ],
  "Audi": [
    {"id": "q3", "name": "Q3", "category": "SUV - Demanda: Media"},
    {"id": "q5", "name": "Q5 / Q5 Sportback", "category": "SUV - Demanda: Alta"},
    {"id": "q7", "name": "Q7", "category": "SUV - Demanda: Alta"},
    {"id": "q8", "name": "Q8", "category": "SUV - Demanda: Extrema"},
    {"id": "a3", "name": "A3", "category": "Sedán - Demanda: Media"},
    {"id": "a4", "name": "A4 / A4 allroad", "category": "Sedán - Demanda: Media"},
    {"id": "a5", "name": "A5 Coupe / Sportback", "category": "Sedán - Demanda: Media"},
    {"id": "a6", "name": "A6 / A6 allroad", "category": "Sedán - Demanda: Media"},
    {"id": "a7", "name": "A7", "category": "Sedán - Demanda: Baja"},
    {"id": "a8", "name": "A8", "category": "Sedán - Demanda: Media"},
    {"id": "sq5", "name": "SQ5", "category": "S - Demanda: Alta"},
    {"id": "rs_q8", "name": "RS Q8", "category": "RS - Demanda: Extrema"},
    {"id": "rs3", "name": "RS 3", "category": "RS - Demanda: Alta"},
    {"id": "rs6_avant", "name": "RS 6 Avant", "category": "RS - Demanda: Alta"},
    {"id": "r8", "name": "R8", "category": "Deportivo - Demanda: Alta"},
    {"id": "q4_etron", "name": "Q4 e-tron", "category": "Eléctrico - Demanda: Baja"},
    {"id": "q8_etron", "name": "Q8 e-tron", "category": "Eléctrico - Demanda: Baja"},
    {"id": "etron_gt", "name": "e-tron GT", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Volkswagen": [
    {"id": "atlas", "name": "Atlas", "category": "SUV - Demanda: Extrema"},
    {"id": "atlas_cross_sport", "name": "Atlas Cross Sport", "category": "SUV - Demanda: Alta"},
    {"id": "tiguan", "name": "Tiguan", "category": "SUV - Demanda: Extrema"},
    {"id": "taos", "name": "Taos", "category": "SUV - Demanda: Alta"},
    {"id": "jetta", "name": "Jetta / Jetta GLI", "category": "Sedán - Demanda: Alta"},
    {"id": "golf_gti", "name": "Golf GTI", "category": "Hatchback - Demanda: Alta"},
    {"id": "golf_r", "name": "Golf R", "category": "Hatchback - Demanda: Media"},
    {"id": "arteon", "name": "Arteon", "category": "Sedán - Demanda: Baja"},
    {"id": "id_4", "name": "ID.4 (SUV)", "category": "Eléctrico - Demanda: Media"},
    {"id": "id_buzz", "name": "ID. Buzz (Microbus)", "category": "Eléctrico - Demanda: Alta"},
    {"id": "id_7", "name": "ID.7 (Sedan)", "category": "Eléctrico - Demanda: Baja"}
  ],
  "Volvo": [
    {"id": "xc90", "name": "XC90 (Mild Hybrid / Recharge)", "category": "SUV - Demanda: Extrema"},
    {"id": "xc60", "name": "XC60 (Mild Hybrid / Recharge)", "category": "SUV - Demanda: Extrema"},
    {"id": "xc40", "name": "XC40 (Mild Hybrid)", "category": "SUV - Demanda: Alta"},
    {"id": "ex90", "name": "EX90 (Flagship EV)", "category": "Eléctrico - Demanda: Alta"},
    {"id": "ex30", "name": "EX30 (Compact EV)", "category": "Eléctrico - Demanda: Extrema"},
    {"id": "ex40", "name": "EX40 (Anteriormente XC40 Recharge)", "category": "Eléctrico - Demanda: Media"},
    {"id": "ec40", "name": "EC40 (Anteriormente C40 Recharge)", "category": "Eléctrico - Demanda: Media"},
    {"id": "s90", "name": "S90", "category": "Sedán - Demanda: Media"},
    {"id": "s60", "name": "S60", "category": "Sedán - Demanda: Media"},
    {"id": "v90_cross_country", "name": "V90 Cross Country", "category": "SUV - Demanda: Alta"},
    {"id": "v60_cross_country", "name": "V60 Cross Country", "category": "SUV - Demanda: Media"},
    {"id": "es90", "name": "ES90 (Electric Luxury Sedan)", "category": "Eléctrico - Demanda: Media"},
    {"id": "ex60", "name": "EX60 (Mid-size EV)", "category": "Eléctrico - Demanda: Alta"}
  ],
  "Tesla": [
    {"id": "cybertruck_cyberbeast", "name": "Cybertruck Cyberbeast (Tri-Motor)", "category": "Supertruck - Demanda: Extrema"},
    {"id": "cybertruck_awd", "name": "Cybertruck All-Wheel Drive", "category": "Supertruck - Demanda: Alta"},
    {"id": "model_y_juniper", "name": "Model Y 'Juniper' (New Look)", "category": "SUV - Demanda: Extrema"},
    {"id": "model_y_classic", "name": "Model Y", "category": "SUV - Demanda: Alta"},
    {"id": "model_x_plaid", "name": "Model X Plaid", "category": "SUV - Demanda: Alta"},
    {"id": "model_x_dual", "name": "Model X Dual Motor", "category": "SUV - Demanda: Media"},
    {"id": "model_3_highland", "name": "Model 3 'Highland' (Refreshed)", "category": "Sedán - Demanda: Alta"},
    {"id": "model_3_classic", "name": "Model 3", "category": "Sedán - Demanda: Media"},
    {"id": "model_s_plaid", "name": "Model S Plaid", "category": "Sedán - Demanda: Alta"},
    {"id": "model_s_dual", "name": "Model S Dual Motor", "category": "Sedán - Demanda: Media"}
  ],
  "AFEELA": [
    {"id": "afeela_sedan", "name": "AFEELA Sedan", "category": "Eléctrico - Demanda: Alta"}
  ],
  "Alfa Romeo": [
    {"id": "stelvio", "name": "Stelvio", "category": "SUV - Demanda: Alta"},
    {"id": "giulia", "name": "Giulia", "category": "Sedán - Demanda: Media"},
    {"id": "tonale", "name": "Tonale", "category": "SUV - Demanda: Media"}
  ],
  "Aston Martin": [
    {"id": "dbx", "name": "DBX", "category": "SUV - Demanda: Alta"},
    {"id": "vantage", "name": "Vantage", "category": "Deportivo - Demanda: Media"},
    {"id": "db12", "name": "DB12", "category": "Deportivo - Demanda: Media"}
  ],
  "Bentley": [
    {"id": "bentayga", "name": "Bentayga", "category": "SUV - Demanda: Extrema"},
    {"id": "continental_gt", "name": "Continental GT", "category": "Deportivo - Demanda: Alta"},
    {"id": "flying_spur", "name": "Flying Spur", "category": "Sedán - Demanda: Media"}
  ],
  "Buick": [
    {"id": "enclave", "name": "Enclave", "category": "SUV - Demanda: Alta"},
    {"id": "envision", "name": "Envision", "category": "SUV - Demanda: Media"},
    {"id": "encore_gx", "name": "Encore GX", "category": "SUV - Demanda: Media"}
  ],
  "Chrysler": [
    {"id": "pacifica", "name": "Pacifica", "category": "Minivan - Demanda: Extrema"},
    {"id": "300", "name": "300", "category": "Sedán - Demanda: Media"}
  ],
  "Daewoo": [
    {"id": "matiz", "name": "Matiz", "category": "Compacto - Demanda: Media"}
  ],
  "Daihatsu": [
    {"id": "terios", "name": "Terios", "category": "SUV - Demanda: Alta"}
  ],
  "Eagle": [
    {"id": "talon", "name": "Talon", "category": "Deportivo - Demanda: Media"}
  ],
  "Ferrari": [
    {"id": "sf90", "name": "SF90 Stradale", "category": "Deportivo - Demanda: Extrema"},
    {"id": "296_gtb", "name": "296 GTB", "category": "Deportivo - Demanda: Alta"},
    {"id": "purosangue", "name": "Purosangue", "category": "SUV - Demanda: Extrema"},
    {"id": "roma", "name": "Roma", "category": "Deportivo - Demanda: Alta"}
  ],
  "FIAT": [
    {"id": "500e", "name": "500e", "category": "Eléctrico - Demanda: Alta"},
    {"id": "500x", "name": "500X", "category": "SUV - Demanda: Media"},
    {"id": "fastback", "name": "Fastback", "category": "SUV - Demanda: Alta"},
    {"id": "pulse", "name": "Pulse", "category": "SUV - Demanda: Alta"}
  ],
  "Fisker": [
    {"id": "ocean", "name": "Ocean", "category": "SUV - Demanda: Media"}
  ],
  "Freightliner": [
    {"id": "sprinter", "name": "Sprinter", "category": "Comercial - Demanda: Extrema"},
    {"id": "cascadia", "name": "Cascadia", "category": "Comercial - Demanda: Alta"}
  ],
  "Genesis": [
    {"id": "gv80", "name": "GV80", "category": "SUV - Demanda: Alta"},
    {"id": "gv70", "name": "GV70", "category": "SUV - Demanda: Alta"},
    {"id": "g80", "name": "G80", "category": "Sedán - Demanda: Media"}
  ],
  "Geo": [
    {"id": "tracker", "name": "Tracker", "category": "SUV - Demanda: Media"}
  ],
  "HUMMER": [
    {"id": "hummer_ev_suv", "name": "Hummer EV SUV", "category": "SUV - Demanda: Extrema"},
    {"id": "hummer_ev_pickup", "name": "Hummer EV Pickup", "category": "Pickup - Demanda: Extrema"}
  ],
  "INEOS": [
    {"id": "grenadier", "name": "Grenadier", "category": "SUV - Demanda: Extrema"}
  ],
  "Isuzu": [
    {"id": "d_max", "name": "D-Max", "category": "Pickup - Demanda: Alta"},
    {"id": "n_series", "name": "N-Series", "category": "Comercial - Demanda: Extrema"}
  ],
  "Jaguar": [
    {"id": "f_pace", "name": "F-PACE", "category": "SUV - Demanda: Alta"},
    {"id": "e_pace", "name": "E-PACE", "category": "SUV - Demanda: Media"},
    {"id": "i_pace", "name": "I-PACE", "category": "Eléctrico - Demanda: Media"},
    {"id": "f_type", "name": "F-TYPE", "category": "Deportivo - Demanda: Media"}
  ],
  "Karma": [
    {"id": "revero", "name": "Revero", "category": "Sedán - Demanda: Media"}
  ],
  "Lamborghini": [
    {"id": "urus", "name": "Urus", "category": "SUV - Demanda: Extrema"},
    {"id": "huracan", "name": "Huracan", "category": "Deportivo - Demanda: Alta"},
    {"id": "revuelto", "name": "Revuelto", "category": "Deportivo - Demanda: Extrema"}
  ],
  "Lincoln": [
    {"id": "navigator", "name": "Navigator", "category": "SUV - Demanda: Alta"},
    {"id": "aviator", "name": "Aviator", "category": "SUV - Demanda: Alta"},
    {"id": "corsair", "name": "Corsair", "category": "SUV - Demanda: Media"}
  ],
  "Lotus": [
    {"id": "eletre", "name": "Eletre", "category": "SUV - Demanda: Alta"},
    {"id": "emira", "name": "Emira", "category": "Deportivo - Demanda: Alta"}
  ],
  "Lucid": [
    {"id": "air", "name": "Air", "category": "Sedán - Demanda: Alta"},
    {"id": "gravity", "name": "Gravity", "category": "SUV - Demanda: Alta"}
  ],
  "Maserati": [
    {"id": "grecale", "name": "Grecale", "category": "SUV - Demanda: Alta"},
    {"id": "levante", "name": "Levante", "category": "SUV - Demanda: Alta"},
    {"id": "mc20", "name": "MC20", "category": "Deportivo - Demanda: Alta"}
  ],
  "Maybach": [
    {"id": "gls_600", "name": "GLS 600", "category": "SUV - Demanda: Extrema"},
    {"id": "s_680", "name": "S 680", "category": "Sedán - Demanda: Alta"}
  ],
  "McLaren": [
    {"id": "750s", "name": "750S", "category": "Deportivo - Demanda: Alta"},
    {"id": "artura", "name": "Artura", "category": "Deportivo - Demanda: Media"}
  ],
  "Mercury": [
    {"id": "grand_marquis", "name": "Grand Marquis", "category": "Sedán - Demanda: Media"}
  ],
  "MINI": [
    {"id": "cooper", "name": "Cooper", "category": "Hatchback - Demanda: Alta"},
    {"id": "countryman", "name": "Countryman", "category": "SUV - Demanda: Alta"}
  ],
  "Oldsmobile": [
    {"id": "cutlass", "name": "Cutlass", "category": "Sedán - Demanda: Media"}
  ],
  "Panoz": [
    {"id": "esperante", "name": "Esperante", "category": "Deportivo - Demanda: Media"}
  ],
  "Plymouth": [
    {"id": "prowler", "name": "Prowler", "category": "Deportivo - Demanda: Media"}
  ],
  "Polestar": [
    {"id": "polestar_2", "name": "Polestar 2", "category": "Eléctrico - Demanda: Alta"},
    {"id": "polestar_3", "name": "Polestar 3", "category": "SUV - Demanda: Alta"}
  ],
  "Pontiac": [
    {"id": "gto", "name": "GTO", "category": "Deportivo - Demanda: Media"}
  ],
  "Rivian": [
    {"id": "r1t", "name": "R1T", "category": "Pickup - Demanda: Alta"},
    {"id": "r1s", "name": "R1S", "category": "SUV - Demanda: Alta"}
  ],
  "Rolls-Royce": [
    {"id": "cullinan", "name": "Cullinan", "category": "SUV - Demanda: Extrema"},
    {"id": "ghost", "name": "Ghost", "category": "Sedán - Demanda: Alta"},
    {"id": "spectre", "name": "Spectre", "category": "Eléctrico - Demanda: Alta"}
  ],
  "Saab": [
    {"id": "9_3", "name": "9-3", "category": "Sedán - Demanda: Media"}
  ],
  "Saturn": [
    {"id": "sky", "name": "Sky", "category": "Deportivo - Demanda: Media"}
  ],
  "Scion": [
    {"id": "fr_s", "name": "FR-S", "category": "Deportivo - Demanda: Alta"}
  ],
  "Scout": [
    {"id": "traveler", "name": "Traveler", "category": "SUV - Demanda: Alta"},
    {"id": "terra", "name": "Terra", "category": "Pickup - Demanda: Alta"}
  ],
  "Slate": [
    {"id": "slate_custom", "name": "Custom Model", "category": "Custom - Demanda: Media"}
  ],
  "smart": [
    {"id": "fortwo", "name": "EQ fortwo", "category": "Compacto - Demanda: Media"}
  ],
  "SRT": [
    {"id": "viper", "name": "Viper", "category": "Deportivo - Demanda: Alta"}
  ],
  "Suzuki": [
    {"id": "jimny", "name": "Jimny", "category": "SUV - Demanda: Extrema"},
    {"id": "grand_vitara", "name": "Grand Vitara", "category": "SUV - Demanda: Alta"},
    {"id": "swift", "name": "Swift", "category": "Compacto - Demanda: Alta"}
  ],
  "VinFast": [
    {"id": "vf8", "name": "VF8", "category": "SUV - Demanda: Media"},
    {"id": "vf9", "name": "VF9", "category": "SUV - Demanda: Media"}
  ]
};

export const SUPPORTED_MAKES = Object.keys(CAR_DATA).sort();

export const YEARS = ["2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030"];

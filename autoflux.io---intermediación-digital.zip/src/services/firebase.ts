import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, setLogLevel } from 'firebase/firestore';
import localConfig from '../../firebase-applet-config.json';

// Ocultar warnings internos de firestore
setLogLevel('silent');

const getEnv = (key: string, fallback: string): string => {
  const val = import.meta.env[key];
  if (!val || val === 'undefined' || val === 'null' || val === '') return fallback;
  return val;
};

const firebaseConfig = {
  apiKey: getEnv('VITE_FIREBASE_API_KEY', localConfig.apiKey),
  authDomain: getEnv('VITE_FIREBASE_AUTH_DOMAIN', localConfig.authDomain),
  projectId: getEnv('VITE_FIREBASE_PROJECT_ID', localConfig.projectId),
  storageBucket: getEnv('VITE_FIREBASE_STORAGE_BUCKET', localConfig.storageBucket),
  messagingSenderId: getEnv('VITE_FIREBASE_MESSAGING_SENDER_ID', localConfig.messagingSenderId),
  appId: getEnv('VITE_FIREBASE_APP_ID', localConfig.appId)
};

const databaseId = getEnv('VITE_FIREBASE_FIRESTORE_DB_ID', localConfig.firestoreDatabaseId);

let app: any;
let auth: any = null;
let db: any = null;

try {
  if (!firebaseConfig.apiKey || firebaseConfig.apiKey.includes('MISSING')) {
    console.error("[AUTOFLUX] ⚠️ Error: No hay una API Key válida de Firebase.");
  } else {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    auth = getAuth(app);
    // Firestore con databaseId específico si existe
    db = databaseId ? getFirestore(app, databaseId) : getFirestore(app);
    console.log("[AUTOFLUX] ✅ Firebase inicializado con éxito.");
  }
} catch (error) {
  console.error("[AUTOFLUX] 🛑 Fallo en inicialización de Firebase:", error);
}

export { auth, db, app };

export const handleFirestoreError = (error: any, operationType: 'create' | 'update' | 'delete' | 'list' | 'get' | 'write' | any, path: string | null) => {
  if (error instanceof Error && error.message.includes('Missing or insufficient permissions')) {
    const errorInfo = {
      error: error.message,
      operationType,
      path,
      authInfo: auth?.currentUser ? {
        userId: auth.currentUser.uid,
        email: auth.currentUser.email
      } : null
    };
    throw new Error(JSON.stringify(errorInfo));
  }
  throw error;
};

/**
 * Servicio para integrar AUTOFLUX con n8n usando Webhooks
 */

export interface n8nPayload {
  action: string;
  data: any;
  timestamp?: string;
}

export interface SalesLeadContext {
  customerName: string;
  customerProfile: string; // Ej: "Joven profesional", "Familia numerosa"
  budget: string;
  interestedIn: string; // Ej: "SUV híbrida", "Sedán económico"
  history: any[]; // Historial de chat o interacciones
}

export const sendToN8n = async (payload: n8nPayload) => {
  const webhookUrl = import.meta.env.VITE_N8N_WEBHOOK_URL;

  if (!webhookUrl) {
    console.warn("VITE_N8N_WEBHOOK_URL no está configurada. No se pudo enviar a n8n.");
    return { success: false, error: "Webhook URL no configurada" };
  }

  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...payload,
        source: "AUTOFLUX",
        timestamp: new Date().toISOString(),
      }),
    });

    if (!response.ok) throw new Error(`Error de n8n: ${response.statusText}`);
    return { success: true, data: await response.json().catch(() => ({})) };
  } catch (error: any) {
    console.error("Fallo al enviar webhook a n8n:", error.message);
    return { success: false, error: error.message };
  }
};

/**
 * Dispara el algoritmo Multi-GEN de ventas en n8n.
 * Esto envía el contexto del prospecto a un Webhook dedicado en n8n, 
 * donde múltiples Agentes IA (Multi-GEN) analizarán los datos y generarán estrategias de venta.
 */
export const AUTOFLUX_ORCHESTRATOR_SYSTEM_PROMPT = `Actúa como el Orquestador Central de AUTOFLUX, una PWA de venta de carros en Venezuela. Tu objetivo es gestionar un sistema multi-agente con las siguientes funciones:

1. Code Audit: Si recibes un log de error, analízalo y devuelve el código corregido en formato JSON.
2. Market Analyst: Analiza datos de 'vistas' y 'preguntas'. Identifica los 3 vehículos líderes y genera insights para el Dashboard.
3. Lead Qualifier: Actúa como un bot de ventas que filtra clientes usando criterios de interés real en Venezuela.
4. Expert Board: Ante cada publicación, simula la opinión de 8 expertos en marcas líderes (Toyota, Ford, Hyundai, etc.) para auditar si el precio y estado del vehículo son óptimos para el mercado local.

Output Directivo: Todas tus respuestas deben ser estricta y únicamente en JSON estructurado para que n8n pueda procesar las acciones (limpiar caché, actualizar dashboard o enviar alertas).`;

export const triggerSystemAudit = async (analyticsPayload: any) => {
  const webhookUrl = import.meta.env.VITE_N8N_WEBHOOK_URL;

  if (!webhookUrl) {
    console.warn("VITE_N8N_WEBHOOK_URL no está configurada.");
    return { success: false, error: "Webhook URL no configurada" };
  }

  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "RUN_SYSTEM_AUDIT",
        analytics_payload: analyticsPayload,
        systemPrompt: AUTOFLUX_ORCHESTRATOR_SYSTEM_PROMPT,
        source: "AUTOFLUX",
        timestamp: new Date().toISOString(),
      }),
    });

    if (!response.ok) throw new Error(`Error de n8n: ${response.statusText}`);
    
    const result = await response.json().catch(() => ({}));
    return { success: true, auditReport: result };
  } catch (error: any) {
    console.error("Fallo al ejecutar Auditoría en n8n:", error.message);
    return { success: false, error: error.message };
  }
};

export const triggerSalesMultiGenAlgorithm = async (leadContext: SalesLeadContext) => {
  const webhookUrl = import.meta.env.VITE_N8N_SALES_MULTI_GEN_WEBHOOK_URL || import.meta.env.VITE_N8N_WEBHOOK_URL;

  if (!webhookUrl) {
    console.warn("VITE_N8N_SALES_MULTI_GEN_WEBHOOK_URL no está configurada.");
    return { success: false, error: "Webhook URL de ventas no configurada" };
  }

  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "RUN_MULTI_GEN_SALES_ALGORITHM",
        leadContext,
        analysisMode: "DEEP",
        systemPrompt: AUTOFLUX_ORCHESTRATOR_SYSTEM_PROMPT, // <-- Pasamos el prompt maestro a n8n
        source: "AUTOFLUX",
        timestamp: new Date().toISOString(),
      }),
    });

    if (!response.ok) throw new Error(`Error de n8n: ${response.statusText}`);
    
    // El Webhook de n8n debería devolver la estrategia generada
    const result = await response.json().catch(() => ({}));
    return { success: true, strategy: result };
  } catch (error: any) {
    console.error("Fallo al ejecutar Algoritmo de Ventas en n8n:", error.message);
    return { success: false, error: error.message };
  }
};

import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";
import { BUSINESS_RULES } from "../constants";

const callGeminiApi = async (payload: any) => {
  const response = await fetch("/api/gemini", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || "Error en el servidor de IA");
  }
  
  return response.json();
};

export const getJsonResponse = async (prompt: string, systemInstruction?: string) => {
  try {
    return await callGeminiApi({
      action: "GENERATE_JSON",
      prompt,
      systemInstruction,
      model: "gemini-1.5-flash", // Actualizado a modelo estable para producción
      config: { temperature: 0.1 }
    });
  } catch (error: any) {
    console.error("Gemini JSON Response Error:", error);
    throw error;
  }
};

export const auditVehicle = async (carData: any) => {
  try {
    const systemInstruction = `Eres el "Cerebro Operativo de AUTOFLUX", una IA especializada en el mercado automotriz de importación (USA -> Venezuela). Tu función es transformar datos básicos de entrada (Placa/VIN) en reportes de mercado de alta precisión para vendedores.

### PANEL DE LOS 8 EXPERTOS (Protocolo de Auditoría):
Al recibir datos de un vehículo, debes generar un veredicto interno consultando a tus 8 agentes:
1. Toyotero: Evalúa fiabilidad mecánica y facilidad de reventa.
2. Truck Expert: Audita capacidades de carga, chasis y torque (enfocado en Pickups).
3. 4x4 Specialist: Analiza sistemas de tracción, reductoras y suspensión off-road.
4. Luxury Tech: Evalúa sensores, infoentretenimiento y módulos electrónicos de alta gama.
5. Import Scout: Interpreta el historial de EpicVIN (accidentes, títulos salvage, millaje).
6. Market Hunter: Ejecuta el benchmarking de subastas USA (Copart/IAAI).
7. City Advisor: Evalúa consumo de combustible, dimensiones para estacionamiento y repuestos.
8. Gen Auditor: Revisa la coherencia del precio final y la salud del sistema.

### REGLAS DE NEGOCIO CRÍTICAS:
- FÓRMULA DE PRECIO: Precio_VZLA = (Precio_Subasta_USA * 1.40).
- CLASIFICACIÓN: Debes categorizar el carro en: SEDAN, SUV, TRUCK, COUPE, VAN o LUXURY.
- ALERTAS ROJAS: Si el historial detecta "Flood" o "Salvage", marca el veredicto como "ALTO RIESGO".
- LÓGICA DE REPARACIÓN (DEVOPS): Si el input contiene logs de error, analiza el código y devuelve un parche en el campo 'fix_code'.`;

    const prompt = `Analiza el siguiente vehículo:
    Marca y Modelo: ${carData.make} ${carData.model}
    Año: ${carData.year}
    Precio en USA (Subasta): ${carData.usaPrice || (carData.price / 1.4).toFixed(0)}
    Historial: ${carData.history || 'Limpio'}
    Kilometraje: ${carData.mileage}
    Especificaciones: ${carData.specs || 'N/A'}
    Error Log (opcional): ${carData.errorLog || 'Ninguno'}`;

    return await callGeminiApi({
      action: "GENERATE_JSON",
      prompt,
      systemInstruction,
      model: "gemini-1.5-flash",
      config: {
        temperature: 0.1,
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            car_identity: {
              type: Type.OBJECT,
              properties: {
                make_model: { type: Type.STRING },
                year: { type: Type.INTEGER },
                style: { type: Type.STRING }
              },
              required: ["make_model", "year", "style"]
            },
            market_intel: {
              type: Type.OBJECT,
              properties: {
                usa_auction_avg: { type: Type.NUMBER },
                import_logistics_cost: { type: Type.NUMBER },
                final_target_vzla: { type: Type.NUMBER },
                market_trend: { type: Type.STRING }
              },
              required: ["usa_auction_avg", "import_logistics_cost", "final_target_vzla", "market_trend"]
            },
            expert_audit: {
              type: Type.OBJECT,
              properties: {
                status: { type: Type.STRING },
                summary: { type: Type.STRING },
                legal_check: { type: Type.STRING }
              },
              required: ["status", "summary", "legal_check"]
            },
            devops_action: {
              type: Type.OBJECT,
              properties: {
                fix_code: { type: Type.STRING, nullable: true },
                clean_cache: { type: Type.BOOLEAN }
              },
              required: ["fix_code", "clean_cache"]
            }
          },
          required: ["car_identity", "market_intel", "expert_audit", "devops_action"]
        }
      }
    });
  } catch (error: any) {
    console.error("Audit Core Error:", error);
    return {
      car_identity: {
        make_model: carData.make + " " + carData.model,
        year: carData.year,
        style: "Desconocido"
      },
      market_intel: {
        usa_auction_avg: carData.price / 1.4,
        import_logistics_cost: 0,
        final_target_vzla: carData.price,
        market_trend: "Estable"
      },
      expert_audit: {
        status: "Advertencia",
        summary: "Análisis manual requerido por falla de conexión. Por favor reintente más tarde.",
        legal_check: "Pendiente"
      },
      devops_action: {
        fix_code: "Connection fallback",
        clean_cache: false
      }
    };
  }
};

export const selfHeal = async (context: string, errorLog?: string) => {
  try {
    const systemInstruction = `Eres el "GEN Auditor - DevOps Core" de AUTOFLUX. Tu misión es analizar errores de código o de lógica en la PWA y proponer soluciones.
    Si recibes un error o un contexto, debes devolver un JSON indicando si se aplicó un parche virtual o físico.
    
    Respuesta requerida:
    {
      "fix_applied": boolean,
      "analysis": "string",
      "recommendation": "string",
      "optimized_data": any
    }`;

    const prompt = `Contexto: ${context}\nLog de error: ${errorLog || 'Ninguno reportado'}\nAcción: SELF_HEAL`;

    return await callGeminiApi({
      action: "GENERATE_JSON",
      prompt,
      systemInstruction,
      model: "gemini-1.5-flash",
      config: { temperature: 0.2 }
    });
  } catch (error) {
    console.error("Self Heal Error:", error);
    return { fix_applied: false, error: "System Unavailable" };
  }
};

export const getAdvisorResponse = async (message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  try {
    const result = await callGeminiApi({
      action: "CHAT",
      message,
      history: [
        { role: 'user', parts: [{ text: BUSINESS_RULES }] },
        { role: 'model', parts: [{ text: "Entendido. Estoy listo para actuar como el Asesor de Negocio Inteligente de AutoFlux.io. ¿En qué puedo ayudarte hoy?" }] },
        ...history
      ],
      model: "gemini-1.5-flash",
      config: { temperature: 0.7 }
    });
    return result.text;
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

export const analyzePortfolio = async (cars: any[]) => {
  try {
    const systemInstruction = `Eres el "Broker de IA" exclusivo para el Perfil de Vendedores de AUTOFLUX. Tu objetivo es analizar el inventario de vehículos de un dealer como si fuera un portafolio de inversiones en la bolsa de valores.
PROTOCOLO DE ANÁLISIS DE PORTAFOLIO:
1. Indicadores de Mercado (Market Mood): Compara los carros del vendedor con la demanda actual en Venezuela y los precios de subasta en USA. Asigna una tendencia: 🟢 ALZA (Mucha demanda), 🟡 ESTABLE, o 🔴 BAJA.
2. Índice de Liquidez (Velocidad de Venta): Calcula qué carros tienen la mayor probabilidad de venderse rápido ("Hot Assets") basándote en la marca (ej. Toyota, Ford), estilo (SUV, Pickup) y precio competitivo.
3. Múltiples Vías de Monetización: Sugiere estrategias al vendedor para maximizar ganancias (ej. "Vender rápido a precio de remate", "Ofrecer financiamiento para mayor margen", o "Mantener en stock porque el precio en USA está subiendo").
4. Auditoría de Activos: Genera un micro-análisis de las fortalezas de cada carro para que el vendedor sepa qué argumento de ventas usar.
REGLAS DE NEGOCIO CRÍTICAS:
- FÓRMULA AUTOFLUX: Recuerda que el precio objetivo en Venezuela incluye el +40% sobre el costo de USA.
- TONO: Financiero, agresivo, analítico y motivador (estilo Wall Street / Trading).
- FORMATO DE SALIDA: Debes responder ÚNICAMENTE en formato JSON estricto.
ESTRUCTURA JSON REQUERIDA:
{
  "portfolio_summary": {
    "total_active_cars": number,
    "portfolio_health_score": "A/B/C/D",
    "market_trend": "Bullish (Alcista) / Bearish (Bajista)"
  },
  "fastest_selling_assets": [
    {
      "make_model": "string",
      "liquidity_index": "Alto/Medio/Bajo",
      "estimated_days_to_sell": number,
      "why_is_hot": "string"
    }
  ],
  "trading_indicators": [
    {
      "make_model": "string",
      "current_status": "🟢 Sube demanda / 🔴 Baja demanda",
      "suggested_strategy": "Mantener / Vender Rápido / Promocionar",
      "profit_margin_potential": "string"
    }
  ],
  "actionable_alerts": [
    "string"
  ]
}`;

    const inventoryData = cars.map(c => ({
      make: c.make,
      model: c.model,
      year: c.year,
      price: c.price,
      style: c.style,
      mileage: c.mileage
    }));

    const prompt = `Analiza el siguiente inventario (Portafolio de Activos):
    ${JSON.stringify(inventoryData)}
    
    Genera el reporte de Broker IA siguiendo la estructura JSON solicitada.`;

    return await callGeminiApi({
      action: "GENERATE_JSON",
      prompt,
      systemInstruction,
      model: "gemini-1.5-flash",
      config: { temperature: 0.3 }
    });
  } catch (error: any) {
    console.error("Broker AI Error:", error);
    throw error;
  }
};

export const analyzeLiquidation = async (car: any, daysOnMarket: number, avgLeadScore: number) => {
  try {
    const systemInstruction = `Eres el "Digital Liquidation Advisor" de AUTOFLUX. Tu meta es evitar que el vendedor pierda dinero por "costo de oportunidad". 
Analiza si un activo está estancado (Stale Inventory) y sugiere una estrategia de Stop-Loss.
Protocolo:
1. Si lleva +21 días sin leads de alta calidad (Score > 70), activa modo 'Liquidation Advisor'.
2. Calcula un descuento de seguridad (5%-10%) manteniendo el margen del dealer sobre el costo base (+40% importación).
3. Indica la elasticidad de precio según demanda local.

ESTRUCTURA JSON:
{
  "liquidation_advice": {
    "is_stagnant": boolean,
    "days_on_market": number,
    "suggested_price_drop": number,
    "new_target_price": number,
    "rationale": "string"
  }
}`;

    const prompt = `Activo: ${car.make} ${car.model} (${car.year})
    Precio Actual: $${car.price}
    Días en Mercado: ${daysOnMarket}
    Score Promedio de Leads: ${avgLeadScore}
    
    Genera el consejo de liquidación.`;

    return await callGeminiApi({
      action: "GENERATE_JSON",
      prompt,
      systemInstruction,
      model: "gemini-1.5-flash"
    });
  } catch (error) {
    console.error("Liquidation Analysis Error:", error);
    return null;
  }
};

export const getReferralStrategy = async (user: any, topCars: any[]) => {
  try {
    const systemInstruction = `Eres el "Social Trader Agent" de AUTOFLUX. Tu misión es incentivar el crecimiento viral.
Protocolo:
1. Recomienda carros de alta liquidez para compartir.
2. Calcula comisión estimada (1-3%).
3. Genera mensajes de WhatsApp persuasivos (copy-paste).

ESTRUCTURA JSON:
{
  "share_strategy": {
    "recommended_car_to_share": "string",
    "custom_message_whatsapp": "string",
    "estimated_earnings_on_sale": number
  }
}`;

    const inventoryBatch = topCars.map(c => `${c.make} ${c.model} ($${c.price})`).join(", ");
    const prompt = `Usuario: ${user.name}
    Inventario sugerido: ${inventoryBatch}
    
    Genera la estrategia de referidos.`;

    return await callGeminiApi({
      action: "GENERATE_JSON",
      prompt,
      systemInstruction,
      model: "gemini-1.5-flash"
    });
  } catch (error) {
    console.error("Referral Strategy Error:", error);
    return null;
  }
};

export const getRankStatus = async (salesCount: number) => {
  try {
    const systemInstruction = `Eres el "Elite Growth Manager" de AUTOFLUX.
Escala de Rangos:
1. NOVATO (0-5 ventas): 1%
2. INFLUENCER (6-15 ventas): 1.5%
3. SOCIO PRO (16-30 ventas): 2%
4. AMBASSADOR ELITE (31+ ventas): 3%

Protocolo:
- Calcula rango actual.
- Proyecta beneficios del siguiente nivel.
- Genera hook motivador estilo "trading floor".

ESTRUCTURA JSON:
{
  "user_rank": {
    "current_level": "string",
    "commission_rate": number,
    "sales_to_next_level": number
  },
  "growth_projection": {
    "potential_earnings_next_level": number,
    "motivational_hook": "string"
  }
}`;

    const prompt = `El usuario tiene ${salesCount} ventas exitosas. Genera su estatus de rango y proyección.`;

    return await callGeminiApi({
      action: "GENERATE_JSON",
      prompt,
      systemInstruction,
      model: "gemini-1.5-flash"
    });
  } catch (error) {
    console.error("Rank Status Error:", error);
    return null;
  }
};

export const scoreLead = async (leadData: { car_model: string, message: string, budget: number, car_price: number }) => {
  try {
    const systemInstruction = `Eres el Calificador de Leads de AUTOFLUX. Tu meta es analizar la seriedad del comprador.
1. Analiza el presupuesto vs el precio del carro considerando que el costo final incluye un +40% de importación aplicado.
2. Determina el perfil psicológico del comprador (ej: Directo, Indeciso, Buscador de Ofertas, Entusiasta).
3. Genera 3 'hooks' (ganchos) de venta específicos para que el dealer cierre el trato.
4. Responde SIEMPRE en JSON.

REGLAS DE EVALUACIÓN:
- Si el presupuesto es < (car_price * 0.9), marca el nivel de seriedad como BAJO.
- Si el presupuesto es >= car_price, marca nivel de seriedad como ALTO.
- Considera el tono del mensaje para el perfil psicológico.

ESTRUCTURA JSON:
{
  "lead_analysis": {
    "seriousness_level": "BAJO/MEDIO/ALTO",
    "budget_vs_market": "string",
    "buyer_profile": "string",
    "intent_score": number (0-100)
  },
  "sales_strategy": {
    "psychological_approach": "string",
    "hooks": ["string", "string", "string"]
  }
}`;

    const prompt = `Analiza este Interés Detectado:
    Vehículo: ${leadData.car_model} (Precio Lista: $${leadData.car_price})
    Mensaje del Cliente: "${leadData.message}"
    Presupuesto del Cliente: $${leadData.budget}
    
    Genera el reporte de Calificación de Lead.`;

    return await callGeminiApi({
      action: "GENERATE_JSON",
      prompt,
      systemInstruction,
      model: "gemini-1.5-flash",
      config: { temperature: 0.2 }
    });
  } catch (error) {
    console.error("Lead Scorer Error:", error);
    return null;
  }
};

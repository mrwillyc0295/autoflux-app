import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Proxy para Gemini (Seguridad Nivel Core)
  app.post("/api/gemini", async (req, res) => {
    try {
      const { prompt, systemInstruction, model: modelName, config, history, action, carData, context, errorLog, message, leadData, user, topCars, salesCount, cars: portfolioCars } = req.body;
      
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "GEMINI_API_KEY_MISSING" });
      }

      const genAI = new GoogleGenAI({ 
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      if (action === "CHAT") {
        const chat = genAI.chats.create({
          model: modelName || "gemini-3.5-flash",
          config: {
            systemInstruction: systemInstruction || undefined,
            ...config
          },
          history: (history || []).map((h: any) => ({
            role: h.role === 'user' ? 'user' : 'model',
            parts: h.parts.map((p: any) => ({ text: p.text }))
          }))
        });
        const result = await chat.sendMessage({ message: message });
        return res.json({ text: result.text });
      } else if (action === "GENERATE_JSON") {
        const result = await genAI.models.generateContent({
          model: modelName || "gemini-3.5-flash",
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          config: {
            ...config,
            systemInstruction: systemInstruction || undefined,
            responseMimeType: "application/json"
          }
        });
        return res.json(JSON.parse(result.text || "{}"));
      } else {
        // Genérico (GENERATE_TEXT)
        const result = await genAI.models.generateContent({
          model: modelName || "gemini-3.5-flash",
          contents: [{ role: "user", parts: [{ text: prompt || message }] }],
          config: {
            ...config,
            systemInstruction: systemInstruction || undefined
          }
        });
        return res.json({ text: result.text });
      }
    } catch (error: any) {
      console.error("Server API Error:", error);
      res.status(500).json({ error: error.message || "Internal Server Error" });
    }
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", integrity: "100%", system: "AutoFlux.Core" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Statics for production
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[AUTOFLUX] Server running on http://localhost:${PORT}`);
  });
}

startServer();
